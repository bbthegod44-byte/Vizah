/* Vizah AI chat (added). DEV ACCOUNTS ONLY. Self-contained: builds its own DOM and CSS, only talks to /chatbot/*,
   and does nothing at all (no button, no DOM) unless the server says this account is allowed. */
(function () {
  "use strict";
  if (window.__vizahChat) return;
  window.__vizahChat = true;

  var css = [
    ".cb-launch{position:fixed;left:0;bottom:200px;z-index:45;display:flex;align-items:center;gap:8px;padding:16px 20px 16px 16px;border:1px solid var(--glass-border,rgba(255,255,255,.12));border-left:0;border-radius:0 22px 22px 0;background:rgba(16,12,18,.72);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);color:var(--text,#f8f9ff);cursor:pointer;font:600 .8rem var(--small-font,system-ui,sans-serif);box-shadow:0 8px 24px rgba(0,0,0,.35);transition:transform .25s ease,opacity .25s ease}",
    ".cb-launch:hover{transform:translateX(3px)}",
    ".cb-launch.cb-away{transform:translateX(-110%);pointer-events:none;opacity:0}",
    ".cb-launch.cb-fade{pointer-events:none;opacity:0}",
    ".cb-launch{padding:16px 18px 16px 16px}",
    ".cb-launch .cb-ico{font-size:1.5rem;line-height:1}",
    ".cb-panel{position:fixed;inset:0;z-index:90;display:flex;justify-content:center;align-items:stretch;background:rgba(6,4,10,.62);-webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);opacity:0;visibility:hidden;transition:opacity .25s ease,visibility .25s}",
    ".cb-panel.cb-open{opacity:1;visibility:visible}",
    ".cb-card{width:min(760px,100%);height:100%;height:100dvh;display:flex;flex-direction:column;overflow:hidden;background:rgba(14,11,20,.94);color:var(--text,#f8f9ff);font-family:var(--small-font,system-ui,sans-serif);padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}",
    "@media(min-width:800px){.cb-card{height:min(900px,94vh);margin:3vh 0;border-radius:22px;border:1px solid var(--glass-border,rgba(255,255,255,.12));box-shadow:0 24px 70px rgba(0,0,0,.55)}}",
    ".cb-head{display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid rgba(255,255,255,.08);min-height:58px}",
    ".cb-title{flex:1;min-width:0;font-weight:700;font-size:1rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    ".cb-sub{font-weight:500;font-size:.72rem;color:var(--muted,rgba(248,249,255,.65));display:block;overflow:hidden;text-overflow:ellipsis}",
    ".cb-ib{width:38px;height:38px;flex:0 0 auto;display:grid;place-items:center;border:0;border-radius:50%;background:rgba(255,255,255,.07);color:inherit;cursor:pointer;font-size:1.05rem}",
    ".cb-ib:hover{background:rgba(255,255,255,.15)}",
    ".cb-body{flex:1;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:14px}",
    ".cb-hero{padding:18px;border-radius:18px;background:linear-gradient(135deg,rgba(255,122,89,.22),rgba(121,231,255,.12));border:1px solid rgba(255,255,255,.1);margin-bottom:14px}",
    ".cb-hero h2{margin:0 0 6px;font-size:1.15rem}",
    ".cb-hero p{margin:0;font-size:.85rem;line-height:1.5;color:var(--muted,rgba(248,249,255,.78))}",
    ".cb-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:11px 16px;border:0;border-radius:14px;background:var(--accent1,#ff7a59);color:#1a1016;font:700 .85rem var(--small-font,system-ui,sans-serif);cursor:pointer}",
    ".cb-btn.ghost{background:rgba(255,255,255,.09);color:var(--text,#f8f9ff)}",
    ".cb-btn.danger{background:rgba(255,80,80,.18);color:#ff9d9d}",
    ".cb-btn:disabled{opacity:.5;cursor:default}",
    ".cb-row{display:flex;align-items:center;gap:12px;width:100%;padding:11px 12px;margin-bottom:8px;border:1px solid rgba(255,255,255,.08);border-radius:14px;background:rgba(255,255,255,.04);color:inherit;text-align:left;cursor:pointer;font:inherit}",
    ".cb-row:hover{background:rgba(255,255,255,.08)}",
    ".cb-rmain{flex:1;min-width:0}",
    ".cb-rname{font-weight:600;font-size:.9rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    ".cb-rsub{margin-top:2px;font-size:.74rem;color:var(--muted,rgba(248,249,255,.65));white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    ".cb-av{width:40px;height:40px;flex:0 0 auto;border-radius:50%;display:grid;place-items:center;font-size:1.25rem;border:2px solid rgba(255,255,255,.14)}",
    ".cb-av.sm{width:32px;height:32px;font-size:1rem}",
    ".cb-tag{display:inline-block;padding:1px 7px;border-radius:8px;font-size:.62rem;font-weight:700;letter-spacing:.03em;background:rgba(255,255,255,.1);color:var(--muted,rgba(248,249,255,.8));margin-left:6px;vertical-align:middle}",
    ".cb-tag.adult{background:rgba(255,122,89,.22);color:#ffb59f}",
    ".cb-tag.nsfw{background:rgba(255,60,90,.28);color:#ff9fb2}",
    ".cb-sec{margin:16px 2px 8px;font-size:.72rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--muted,rgba(248,249,255,.6))}",
    ".cb-pick{border-color:rgba(255,255,255,.08)}",
    ".cb-pick.on{border-color:var(--accent3,#79e7ff);background:rgba(121,231,255,.1)}",
    ".cb-check{width:22px;height:22px;flex:0 0 auto;border-radius:7px;border:2px solid rgba(255,255,255,.25);display:grid;place-items:center;font-size:.8rem}",
    ".cb-pick.on .cb-check{background:var(--accent3,#79e7ff);border-color:transparent;color:#0d1b2a}",
    ".cb-field{display:block;margin:0 0 12px}",
    ".cb-field>span{display:block;margin:0 0 5px;font-size:.74rem;font-weight:600;color:var(--muted,rgba(248,249,255,.72))}",
    ".cb-in{width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid rgba(255,255,255,.12);border-radius:12px;background:rgba(255,255,255,.06);color:inherit;font:.88rem var(--small-font,system-ui,sans-serif);outline:none}",
    ".cb-in:focus{border-color:var(--accent3,#79e7ff)}",
    "textarea.cb-in{resize:vertical;min-height:70px}",
    ".cb-note{font-size:.76rem;line-height:1.5;color:var(--muted,rgba(248,249,255,.68));margin:6px 0 12px}",
    ".cb-grid2{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px}",
    ".cb-msgs{display:flex;flex-direction:column;gap:10px}",
    ".cb-msg{display:flex;gap:9px;align-items:flex-start}",
    ".cb-msg.me{flex-direction:row-reverse}",
    ".cb-bub{max-width:min(84%,560px);padding:9px 12px;border-radius:16px;background:rgba(255,255,255,.07);font-size:.9rem;line-height:1.5;word-wrap:break-word;overflow-wrap:anywhere}",
    ".cb-msg.me .cb-bub{background:rgba(121,231,255,.16)}",
    ".cb-who{display:block;margin-bottom:2px;font-size:.7rem;font-weight:700;letter-spacing:.02em}",
    ".cb-bub em{color:var(--muted,rgba(248,249,255,.78))}",
    ".cb-narr .cb-bub{background:transparent;border:1px dashed rgba(255,255,255,.14);font-size:.84rem}",
    ".cb-grp{display:flex;flex-direction:column;gap:8px;min-width:0;flex:1}",
    ".cb-blk{display:flex;gap:9px;align-items:flex-start}",
    ".cb-acts{display:flex;align-items:center;gap:6px;margin:4px 0 0 41px;flex-wrap:wrap}",
    ".cb-act{padding:4px 9px;border:0;border-radius:9px;background:rgba(255,255,255,.07);color:inherit;font:600 .72rem var(--small-font,system-ui,sans-serif);cursor:pointer}",
    ".cb-act:hover{background:rgba(255,255,255,.15)}",
    ".cb-dots span{display:inline-block;width:6px;height:6px;margin:0 2px;border-radius:50%;background:currentColor;opacity:.4;animation:cbd 1s infinite}",
    ".cb-dots span:nth-child(2){animation-delay:.15s}.cb-dots span:nth-child(3){animation-delay:.3s}",
    "@keyframes cbd{50%{opacity:1;transform:translateY(-3px)}}",
    ".cb-comp{display:flex;align-items:flex-end;gap:8px;padding:10px 12px;border-top:1px solid rgba(255,255,255,.08);background:rgba(10,8,16,.6)}",
    ".cb-comp textarea{flex:1;min-height:42px;max-height:140px;resize:none}",
    ".cb-who-sel{max-width:112px;padding:10px 8px}",
    ".cb-err{margin:8px 12px 0;padding:9px 12px;border-radius:12px;background:rgba(255,80,80,.14);color:#ffb0b0;font-size:.8rem;display:flex;gap:10px;align-items:center}",
    ".cb-err span{flex:1}",
    ".cb-sw{font-size:.72rem;color:var(--muted,rgba(248,249,255,.7));min-width:34px;text-align:center}",
    "@media(prefers-reduced-motion:reduce){.cb-panel,.cb-launch{transition:none}.cb-dots span{animation:none}}",
    /* ---- polish pass (additive: delete these lines to restore the previous look) ---- */
    /* 1. dropdowns: the native list was light text on a white popup */
    "select.cb-in{color-scheme:dark;background-color:#1b1624;color:#f8f9ff}",
    "select.cb-in option,select.cb-in optgroup{background-color:#1b1624;color:#f8f9ff}",
    /* 2. more room between characters / messages */
    ".cb-msgs{gap:24px}",
    ".cb-grp{gap:16px}",
    ".cb-bub{padding:11px 14px;line-height:1.62}",
    ".cb-who{margin-bottom:4px}",
    ".cb-acts{margin-top:8px}",
    /* 3. up-next / toast notifications stay visible above the chat (top of the screen, clear of the composer) */
    "body.cb-chat-open .nextup-toast,body.cb-chat-open .vz-toast{z-index:120}",
    "body.cb-chat-open .nextup-toast{bottom:auto;top:max(14px,env(safe-area-inset-top,0px));transform:translate3d(-50%,-24px,0)}",
    "body.cb-chat-open .nextup-toast.show{transform:translate3d(-50%,0,0)}",
    /* 4. let the animated background show through the chat */
    ".cb-panel{background:rgba(6,4,10,.22);-webkit-backdrop-filter:blur(14px) saturate(1.25);backdrop-filter:blur(14px) saturate(1.25)}",
    ".cb-card{background:rgba(14,11,20,.46)}",
    ".cb-head{background:rgba(10,8,16,.38)}",
    ".cb-comp{background:rgba(10,8,16,.42)}",
    ".cb-bub{background:rgba(16,12,24,.52);border:1px solid rgba(255,255,255,.07);text-shadow:0 1px 2px rgba(0,0,0,.4)}",
    ".cb-msg.me .cb-bub{background:rgba(60,150,175,.42)}",
    ".cb-narr .cb-bub{background:rgba(10,8,16,.32)}",
    ".cb-row{background:rgba(16,12,24,.5)}",
    ".cb-row:hover{background:rgba(255,255,255,.1)}",
    ".cb-in{background:rgba(10,8,16,.5)}",
    "html.lite .cb-panel{-webkit-backdrop-filter:none;backdrop-filter:none;background:rgba(6,4,10,.5)}",
    "html.lite .cb-card{background:rgba(14,11,20,.9)}",
    /* ---- scrollbar + turn separation (additive) ---- */
    ".cb-body,.cb-msgs,.cb-comp textarea,textarea.cb-in{scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.3) transparent}",
    ".cb-body::-webkit-scrollbar,.cb-msgs::-webkit-scrollbar,textarea.cb-in::-webkit-scrollbar{width:9px;height:9px}",
    ".cb-body::-webkit-scrollbar-track,.cb-msgs::-webkit-scrollbar-track,textarea.cb-in::-webkit-scrollbar-track{background:transparent}",
    ".cb-body::-webkit-scrollbar-thumb,.cb-msgs::-webkit-scrollbar-thumb,textarea.cb-in::-webkit-scrollbar-thumb{background:rgba(255,255,255,.26);border-radius:9px;border:2px solid transparent;background-clip:padding-box}",
    ".cb-body::-webkit-scrollbar-thumb:hover,.cb-msgs::-webkit-scrollbar-thumb:hover{background:rgba(255,255,255,.45);background-clip:padding-box;border:2px solid transparent}",
    ".cb-panel,.cb-body,.cb-msgs{overscroll-behavior:contain}",
    ".cb-msgs{position:relative}",
    ".cb-sep{display:flex;align-items:center;gap:12px;margin:-4px 0;color:var(--muted,rgba(248,249,255,.6));font-size:.68rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase}",
    ".cb-sep:before,.cb-sep:after{content:\"\";flex:1;height:1px;background:linear-gradient(90deg,transparent,rgba(255,255,255,.22),transparent)}",
    ".cb-grp.cb-latest{border-left:3px solid var(--accent1,#ff7a59);padding-left:12px;border-radius:2px;animation:cbnew 1.8s ease-out}",
    ".cb-latest-tag{align-self:flex-start;margin-bottom:-6px;padding:2px 9px;border-radius:9px;background:var(--accent1,#ff7a59);color:#1a1016;font-size:.62rem;font-weight:800;letter-spacing:.08em}",
    "@keyframes cbnew{from{background:rgba(255,122,89,.2)}to{background:rgba(255,122,89,0)}}",
    "@media(prefers-reduced-motion:reduce){.cb-grp.cb-latest{animation:none}}",
    /* ---- themed sliders + softer speaker picker (additive: delete these lines to restore the previous look) ---- */
    ".cb-sl{margin:0 0 12px;padding:12px 14px 10px;border-radius:18px;background:linear-gradient(135deg,rgba(255,122,89,.10),rgba(121,231,255,.06));border:1px solid rgba(255,255,255,.09)}",
    ".cb-sl-top{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px}",
    ".cb-sl-name{font-size:.76rem;font-weight:700;letter-spacing:.04em;color:var(--text,#f8f9ff)}",
    ".cb-sl-val{padding:3px 11px;border-radius:999px;font-size:.72rem;font-weight:800;letter-spacing:.03em;color:#1a1016;background:linear-gradient(90deg,var(--accent1,#ff7a59),var(--accent3,#79e7ff));box-shadow:0 2px 10px rgba(255,122,89,.28)}",
    ".cb-sl-ends{display:flex;justify-content:space-between;margin-top:4px;font-size:.64rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--muted,rgba(248,249,255,.55))}",
    "input.cb-range{-webkit-appearance:none;appearance:none;display:block;width:100%;height:24px;margin:0;padding:0;background:transparent;cursor:pointer;outline:none;--p:50%}",
    "input.cb-range::-webkit-slider-runnable-track{height:6px;border-radius:999px;background:linear-gradient(90deg,var(--accent1,#ff7a59),var(--accent3,#79e7ff)) 0 0/var(--p) 100% no-repeat,rgba(255,255,255,.13)}",
    "input.cb-range::-moz-range-track{height:6px;border-radius:999px;background:rgba(255,255,255,.13)}",
    "input.cb-range::-moz-range-progress{height:6px;border-radius:999px;background:linear-gradient(90deg,var(--accent1,#ff7a59),var(--accent3,#79e7ff))}",
    "input.cb-range::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:20px;height:20px;margin-top:-7px;border-radius:50%;border:3px solid var(--accent3,#79e7ff);background:#14101c;box-shadow:0 0 0 3px rgba(121,231,255,.16),0 2px 10px rgba(0,0,0,.5);transition:transform .15s ease,box-shadow .15s ease}",
    "input.cb-range::-moz-range-thumb{width:14px;height:14px;border-radius:50%;border:3px solid var(--accent3,#79e7ff);background:#14101c;box-shadow:0 0 0 3px rgba(121,231,255,.16),0 2px 10px rgba(0,0,0,.5)}",
    "input.cb-range:hover::-webkit-slider-thumb{transform:scale(1.1)}",
    "input.cb-range:active::-webkit-slider-thumb{transform:scale(1.22);box-shadow:0 0 0 6px rgba(255,122,89,.22),0 2px 12px rgba(0,0,0,.5)}",
    "input.cb-range:focus-visible::-webkit-slider-thumb{box-shadow:0 0 0 5px rgba(255,122,89,.35)}",
    ".cb-who-wrap{position:relative;flex:0 0 auto;align-self:flex-end}",
    ".cb-who-pill{display:flex;align-items:center;gap:7px;height:42px;max-width:132px;padding:0 12px 0 6px;border:1px solid rgba(255,255,255,.13);border-radius:999px;background:rgba(10,8,16,.5);color:inherit;cursor:pointer;font:600 .8rem var(--small-font,system-ui,sans-serif);transition:background .2s ease,border-color .2s ease}",
    ".cb-who-pill:hover,.cb-who-pill.on{background:rgba(255,255,255,.1);border-color:var(--accent3,#79e7ff)}",
    ".cb-who-pill .cb-wn{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
    ".cb-who-pill .cb-chev{font-size:.6rem;opacity:.6;transition:transform .2s ease}",
    ".cb-who-pill.on .cb-chev{transform:rotate(180deg)}",
    ".cb-wav{width:30px;height:30px;flex:0 0 auto;border-radius:50%;display:grid;place-items:center;font-size:.95rem;background:rgba(255,255,255,.08);border:2px solid rgba(255,255,255,.18)}",
    ".cb-who-pop{position:absolute;left:0;bottom:calc(100% + 10px);z-index:5;min-width:190px;max-height:min(46vh,320px);overflow-y:auto;padding:6px;border-radius:20px;background:rgba(18,14,28,.94);-webkit-backdrop-filter:blur(16px);backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,.12);box-shadow:0 14px 40px rgba(0,0,0,.55);opacity:0;visibility:hidden;transform:translateY(8px) scale(.97);transform-origin:bottom left;transition:opacity .18s ease,transform .18s ease,visibility .18s}",
    ".cb-who-pop.open{opacity:1;visibility:visible;transform:none}",
    ".cb-who-opt{display:flex;align-items:center;gap:9px;width:100%;padding:7px 10px 7px 7px;border:0;border-radius:999px;background:transparent;color:inherit;cursor:pointer;text-align:left;font:600 .82rem var(--small-font,system-ui,sans-serif)}",
    ".cb-who-opt:hover{background:rgba(255,255,255,.09)}",
    ".cb-who-opt.sel{background:rgba(121,231,255,.14)}",
    ".cb-who-opt .cb-tick{margin-left:auto;font-size:.75rem;color:var(--accent3,#79e7ff)}",
    "@media(prefers-reduced-motion:reduce){.cb-who-pop,.cb-who-pill .cb-chev,input.cb-range::-webkit-slider-thumb{transition:none}}",
    /* ---- story moments: pop-up notifications, bell + tab (additive: delete these lines to remove the look) ---- */
    ".cb-toasts{position:fixed;left:50%;top:calc(env(safe-area-inset-top,0px) + 72px);transform:translateX(-50%);z-index:130;width:min(420px,calc(100vw - 24px));display:flex;flex-direction:column;gap:8px;pointer-events:none}",
    ".cb-mom{display:flex;align-items:center;gap:12px;padding:11px 14px;border-radius:16px;background:rgba(16,12,18,.86);border:1px solid rgba(255,255,255,.14);border-left:4px solid var(--mc,#ff7a59);box-shadow:0 14px 40px rgba(0,0,0,.45);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);color:var(--text,#f8f9ff);font-family:var(--small-font,system-ui,sans-serif);cursor:pointer;pointer-events:auto;opacity:0;transform:translate3d(0,-14px,0) scale(.97);transition:opacity .35s ease,transform .4s cubic-bezier(.2,.8,.2,1)}",
    ".cb-mom.show{opacity:1;transform:none}",
    ".cb-mom-eye{font-size:.62rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--mc,#ff7a59)}",
    ".cb-mom-line{margin-top:1px;font-size:.9rem;font-weight:700;line-height:1.35;overflow-wrap:anywhere}",
    "html.lite .cb-mom{-webkit-backdrop-filter:none;backdrop-filter:none;background:rgba(16,12,18,.95)}",
    ".cb-bell{position:relative}",
    ".cb-bdg{position:absolute;top:-3px;right:-3px;min-width:17px;height:17px;padding:0 4px;box-sizing:border-box;border-radius:9px;background:var(--accent1,#ff7a59);color:#1a1016;font:800 .62rem/17px var(--small-font,system-ui,sans-serif);text-align:center}",
    ".cb-row.cb-new{border-color:var(--mc,var(--accent1,#ff7a59))}",
    "@media(prefers-reduced-motion:reduce){.cb-mom{transition:none}}",
    /* ---- motion pass: tweens on everything in the chat (additive: delete these lines to go back to the static look) ---- */
    "@keyframes cbrise{from{opacity:0;transform:translate3d(var(--dx,0),12px,0)}}",
    "@keyframes cbfade{from{opacity:0;transform:translateY(-6px)}}",
    "@keyframes cbpopl{0%{opacity:0;transform:translate3d(-10px,14px,0) scale(.92)}60%{opacity:1;transform:translate3d(0,-2px,0) scale(1.02)}100%{transform:none}}",
    "@keyframes cbpopr{0%{opacity:0;transform:translate3d(10px,14px,0) scale(.92)}60%{opacity:1;transform:translate3d(0,-2px,0) scale(1.02)}100%{transform:none}}",
    "@keyframes cbtick{0%{transform:scale(.4)}60%{transform:scale(1.25)}100%{transform:scale(1)}}",
    "@keyframes cbbump{50%{transform:scale(1.2)}}",
    "@keyframes cbgrad{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}",
    "@keyframes cbfloat{50%{transform:translateY(-3px) rotate(-5deg)}}",
    "@keyframes cbbar{to{transform:scaleX(0)}}",
    "@keyframes cbbadge{0%{transform:scale(0)}60%{transform:scale(1.35)}100%{transform:scale(1)}}",
    "@keyframes cbring{0%,100%{transform:rotate(0)}15%{transform:rotate(18deg)}30%{transform:rotate(-16deg)}45%{transform:rotate(12deg)}60%{transform:rotate(-8deg)}75%{transform:rotate(4deg)}}",
    "@keyframes cbglow{0%{box-shadow:0 0 0 0 var(--mc)}30%{box-shadow:0 0 18px 2px var(--mc)}100%{box-shadow:0 0 0 0 transparent}}",
    "@keyframes cbavpop{0%{transform:scale(.3) rotate(-20deg)}60%{transform:scale(1.15) rotate(6deg)}100%{transform:none}}",
    /* panel: the card rises in and sinks out */
    ".cb-card{opacity:0;transform:translateY(26px) scale(.97);transition:transform .5s cubic-bezier(.2,.8,.2,1),opacity .35s ease}",
    ".cb-open .cb-card{opacity:1;transform:none}",
    /* launcher */
    ".cb-launch .cb-ico{display:inline-block;animation:cbfloat 3.4s ease-in-out infinite}",
    ".cb-launch:active{transform:scale(.94)}",
    /* every screen: header fades down, content rises in a stagger and slides in the direction you navigated */
    ".cb-head>*{animation:cbfade .35s ease backwards}",
    ".cb-head>*:nth-child(2){animation-delay:.05s}.cb-head>*:nth-child(3){animation-delay:.1s}.cb-head>*:nth-child(4){animation-delay:.15s}.cb-head>*:nth-child(5){animation-delay:.2s}",
    ".cb-vin>*:not(.cb-hero){animation:cbrise .45s cubic-bezier(.2,.8,.2,1) backwards;animation-delay:calc(var(--i,0)*45ms)}",
    ".cb-hero{background-size:220% 220%}",
    ".cb-vin>.cb-hero{animation:cbrise .5s cubic-bezier(.2,.8,.2,1) backwards,cbgrad 9s ease-in-out infinite}",
    ".cb-vin>.cb-new{animation:cbrise .45s cubic-bezier(.2,.8,.2,1) backwards,cbglow 1.8s ease-out .4s backwards;animation-delay:calc(var(--i,0)*45ms),.4s}",
    /* buttons, rows, pills: hover lift + press squish + tweened colours */
    ".cb-btn,.cb-ib,.cb-act,.cb-row,.cb-who-opt{transition:transform .18s cubic-bezier(.2,.8,.2,1),background .2s ease,border-color .2s ease,box-shadow .2s ease,opacity .2s ease}",
    ".cb-btn:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(255,122,89,.3)}",
    ".cb-ib:hover,.cb-act:hover{transform:scale(1.08)}",
    ".cb-row[role=button]:hover{transform:translateX(3px)}",
    ".cb-btn:active,.cb-ib:active,.cb-act:active,.cb-who-pill:active,.cb-row[role=button]:active,label.cb-row:active{transform:scale(.95)}",
    ".cb-in{transition:border-color .2s ease,box-shadow .2s ease,background .2s ease}",
    ".cb-in:focus{box-shadow:0 0 0 3px rgba(121,231,255,.16)}",
    ".cb-pick.on .cb-check{animation:cbtick .3s cubic-bezier(.2,1.4,.4,1)}",
    ".cb-check{transition:background .2s ease,border-color .2s ease}",
    ".cb-sl-val.bump{animation:cbbump .25s ease}",
    ".cb-who-pop.open .cb-who-opt{animation:cbrise .3s cubic-bezier(.2,.8,.2,1) backwards;animation-delay:calc(var(--i,0)*35ms)}",
    /* messages */
    ".cb-pop{animation:cbpopl .5s cubic-bezier(.2,.9,.3,1.2) backwards;animation-delay:var(--d,0ms)}",
    ".cb-pop-r{animation:cbpopr .45s cubic-bezier(.2,.9,.3,1.2) backwards}",
    ".cb-dots{animation:cbpopl .4s cubic-bezier(.2,.9,.3,1.2) backwards}",
    ".cb-rise{animation:cbrise .3s cubic-bezier(.2,.8,.2,1) backwards}",
    ".cb-comp,.cb-err{animation:cbrise .4s cubic-bezier(.2,.8,.2,1) backwards}",
    /* deleting: rows and messages slide out and collapse */
    ".cb-out{opacity:0!important;transform:translateX(34px)!important;max-height:0!important;margin-top:0!important;margin-bottom:0!important;padding-top:0!important;padding-bottom:0!important;border-width:0!important;transition:opacity .22s ease,transform .3s ease,max-height .3s ease .05s,margin .3s ease,padding .3s ease!important}",
    /* notifications: avatar pops, a timer bar drains, the bell rings and the badge bounces */
    ".cb-mom{position:relative;overflow:hidden}",
    ".cb-mom:after{content:\"\";position:absolute;left:0;right:0;bottom:0;height:2px;background:var(--mc,#ff7a59);transform-origin:left;animation:cbbar 6.5s linear forwards}",
    ".cb-mom .cb-av{animation:cbavpop .5s cubic-bezier(.2,1.4,.4,1) .15s backwards}",
    ".cb-bell.ring{animation:cbring .7s ease}",
    ".cb-bdg{animation:cbbadge .4s cubic-bezier(.2,1.4,.4,1) backwards}",
    "html.lite .cb-hero,html.lite .cb-launch .cb-ico{animation:none}",
    "html.lite .cb-vin>.cb-hero{animation:cbrise .5s cubic-bezier(.2,.8,.2,1) backwards}",
    "@media(prefers-reduced-motion:reduce){.cb-panel *,.cb-launch,.cb-launch *,.cb-toasts *,.cb-card{animation:none!important;transition:none!important}}",
    /* ---- icons + continue (additive: delete these lines to restore the previous look) ---- */
    ".cb-svg{width:1.15em;height:1.15em;flex:0 0 auto;display:block}",
    ".cb-ib .cb-svg{width:19px;height:19px}",
    ".cb-act-i{display:inline-flex;align-items:center;gap:5px}",
    ".cb-act-i .cb-svg{width:13px;height:13px}",
    ".cb-act.cb-go{background:var(--accent1,#ff7a59);color:#1a1016}",
    ".cb-act.cb-go:hover{background:var(--accent1,#ff7a59);filter:brightness(1.1)}",
    ".cb-comp textarea{min-width:0}",
    ".cb-comp textarea::placeholder{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    "@media(max-width:480px){.cb-comp{gap:6px;padding:10px 8px}.cb-who-pill{max-width:96px;padding:0 9px 0 5px;gap:5px}.cb-who-pill .cb-chev{display:none}.cb-comp .cb-ib{width:36px;height:36px}.cb-comp textarea{padding:10px}}"
  ].join("\n");
  var st = document.createElement("style");
  st.textContent = css;
  document.head.appendChild(st);

  function h(tag, attrs, kids) {
    var e = document.createElement(tag);
    if (attrs) for (var k in attrs) {
      var v = attrs[k];
      if (k === "class") e.className = v;
      else if (k === "text") e.textContent = v;
      else if (k === "style") e.style.cssText = v;
      else if (k.slice(0, 2) === "on") e.addEventListener(k.slice(2), v);
      else if (v !== false && v != null) e.setAttribute(k, v === true ? "" : v);
    }
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === "string" ? document.createTextNode(c) : c); });
    return e;
  }

  var S = { ready: false, allowed: false, loaded: false, open: false, view: "home", state: null, chat: null,
            busy: false, error: "", speaker: "", sel: "", editing: "", draft: null, mounted: false };
  var launch, panel, card, headEl, bodyEl;

  function api(body) {
    return fetch("/chatbot/api", { method: "POST", credentials: "same-origin",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: "Bad reply from the server" }; }); })
      .catch(function () { return { ok: false, error: "Can't reach the Vizah server" }; });
  }

  /* ---------- text formatting (safe: DOM nodes only, never innerHTML) ---------- */
  function fmt(text) {
    var frag = document.createDocumentFragment();
    String(text || "").split("\n").forEach(function (line, i) {
      if (i) frag.appendChild(document.createElement("br"));
      line.split(/(\*\*[^*\n]+\*\*|\*[^*\n]+\*|\*+[^\s*][^*\n]*$)/).forEach(function (part) {
        if (!part) return;
        if (/^\*\*[^*\n]+\*\*$/.test(part)) frag.appendChild(h("strong", { text: part.slice(2, -2) }));
        else if (/^\*[^*\n]+\*$/.test(part)) frag.appendChild(h("em", { text: part.slice(1, -1) }));
        else if (/^\*+[^\s*][^*\n]*$/.test(part)) frag.appendChild(h("em", { text: part.replace(/^\*+/, "") }));   /* reply cut off inside an *action* */
        else frag.appendChild(document.createTextNode(part));
      });
    });
    return frag;
  }
  function charMap() {
    var map = {};
    ((S.state && S.state.characters) || []).forEach(function (c) {
      map[c.name.toLowerCase()] = c; map[c.id] = c; map[c.name.split(" ")[0].toLowerCase()] = c;
    });
    return map;
  }
  function parseBlocks(text) {
    var map = charMap(), blocks = [], cur = null;
    String(text || "").split("\n").forEach(function (line) {
      var m = line.match(/^\s*\**([A-Za-z][A-Za-z .'\-]{0,30}?)\**\s*:\s*(.*)$/);
      var who = m ? m[1].trim().toLowerCase() : "";
      if (m && (who === "narrator" || map[who])) { cur = { who: who === "narrator" ? "Narrator" : map[who].name, c: map[who] || null, text: m[2] }; blocks.push(cur); }
      else if (cur) cur.text += "\n" + line;
      else { cur = { who: "Narrator", c: null, text: line }; blocks.push(cur); }
    });
    return blocks.filter(function (b) { return b.text.replace(/\s+/g, "") !== ""; });
  }
  function avatar(c, sm) {
    return h("div", { class: "cb-av" + (sm ? " sm" : ""), style: "background:" + ((c && c.color) || "#444") + "33;border-color:" + ((c && c.color) || "#666") + "88", text: (c && c.emoji) || "📖" });
  }
  function ago(ts) {
    var s = Math.max(0, Math.floor(Date.now() / 1000 - ts));
    if (s < 60) return "now"; if (s < 3600) return Math.floor(s / 60) + "m"; if (s < 86400) return Math.floor(s / 3600) + "h";
    return Math.floor(s / 86400) + "d";
  }
  function charById(id) { return ((S.state && S.state.characters) || []).filter(function (c) { return c.id === id; })[0]; }

  /* ---------- shell ---------- */
  function mount() {
    if (S.mounted) return;
    S.mounted = true;
    launch = h("button", { class: "cb-launch cb-away", type: "button", "aria-label": "Open the house chat", onclick: openPanel },
      [h("span", { class: "cb-ico", text: "🏚️" })]);
    launch.title = "House chat";
    /* fade away once the YouTube section scrolls into view */
    (function () {
      var yt = null, tick = 0;
      function check() {
        tick = 0; yt = yt || document.getElementById("youtube");
        if (yt) launch.classList.toggle("cb-fade", yt.getBoundingClientRect().top < window.innerHeight * 0.6);
      }
      function queue() { if (!tick) tick = requestAnimationFrame(check); }
      document.addEventListener("scroll", queue, true);
      window.addEventListener("resize", queue);
      queue();
    })();
    headEl = h("div", { class: "cb-head" });
    bodyEl = h("div", { class: "cb-body" });
    card = h("div", { class: "cb-card" }, [headEl, bodyEl]);
    panel = h("div", { class: "cb-panel", role: "dialog", "aria-modal": "true" }, [card]);
    panel.addEventListener("click", function (e) { if (e.target === panel) closePanel(); });
    document.body.appendChild(launch);
    document.body.appendChild(panel);
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && S.open) closePanel(); });
  }
  function openPanel() { S.open = true; document.body.classList.add("cb-chat-open"); panel.classList.add("cb-open"); launch.classList.add("cb-away"); go(S.view === "chat" && S.chat ? "chat" : "home"); }
  function closePanel() { S.open = false; document.body.classList.remove("cb-chat-open"); panel.classList.remove("cb-open"); if (S.ready) launch.classList.remove("cb-away"); }
  function setHead(title, sub, left, right) {
    headEl.textContent = "";
    if (left) headEl.appendChild(left);
    var t = h("div", { class: "cb-title" }, [title]);
    if (sub) t.appendChild(h("span", { class: "cb-sub", text: sub }));
    headEl.appendChild(t);
    (right || []).forEach(function (b) { headEl.appendChild(b); });
  }
  var ICONS = {
    back: '<polyline points="15 18 9 12 15 6"/>', close: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
    pencil: '<path d="M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    send: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
    next: '<polygon points="6 4 20 12 6 20 6 4"/>',
    regen: '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
    more: '<polyline points="15 10 20 15 15 20"/><path d="M4 4v7a4 4 0 0 0 4 4h12"/>'
  };
  var GLYPH = { "\u2039": "back", "\u2715": "close", "\u270e": "pencil", "\u2699": "gear" };
  function icon(name) {
    var n = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    n.setAttribute("viewBox", "0 0 24 24"); n.setAttribute("fill", "none"); n.setAttribute("stroke", "currentColor");
    n.setAttribute("stroke-width", "2"); n.setAttribute("stroke-linecap", "round"); n.setAttribute("stroke-linejoin", "round");
    n.setAttribute("class", "cb-svg"); n.setAttribute("aria-hidden", "true");
    n.innerHTML = ICONS[name];
    return n;
  }
  function ib(label, title, fn) {
    var b = h("button", { class: "cb-ib", type: "button", title: title, "aria-label": title, onclick: fn });
    if (GLYPH[label]) b.appendChild(icon(GLYPH[label])); else b.textContent = label;
    return b;
  }
  function act(name, label, fn, cls) {
    var b = h("button", { class: "cb-act cb-act-i" + (cls ? " " + cls : ""), type: "button", onclick: fn });
    b.appendChild(icon(name)); b.appendChild(document.createTextNode(label));
    return b;
  }
  /* did the reply stop mid-sentence / inside an *action* / inside "speech"? */
  function looksCut(text) {
    var t = String(text || "").replace(/\s+$/, "");
    if (!t) return false;
    if ((t.match(/\*/g) || []).length % 2) return true;
    if ((t.match(/"/g) || []).length % 2) return true;
    return !/[.!?\u2026~)\]*"\u201d\u2019'`]$/.test(t);
  }
  var VORDER = { home: 0, room: 1, settings: 1, chat: 1, moments: 2 };
  function reduced() { return !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches); }
  function animIn(dir) {
    bodyEl.style.setProperty("--dx", (dir < 0 ? -16 : 16) + "px");
    for (var i = 0; i < bodyEl.children.length; i++) bodyEl.children[i].style.setProperty("--i", Math.min(i, 14));
    void bodyEl.offsetWidth;
    bodyEl.classList.add("cb-vin");
  }
  /* slide a row/message out and collapse it, then run fn */
  function outThen(el, fn) {
    if (!el || reduced()) { fn(); return; }
    el.style.maxHeight = el.offsetHeight + "px"; el.style.overflow = "hidden";
    void el.offsetWidth;
    el.classList.add("cb-out");
    setTimeout(fn, 320);
  }
  function go(view) {
    var prev = S.view;
    S.view = view;
    bodyEl.style.cssText = "";
    bodyEl.classList.remove("cb-vin");
    ({ home: viewHome, room: viewRoom, chat: viewChat, settings: viewSettings, moments: viewMoments })[view]();
    if (view !== "chat") animIn((VORDER[view] || 0) < (VORDER[prev] || 0) ? -1 : 1);
  }

  /* ---------- home ---------- */
  function refreshState(cb) {
    fetch("/chatbot/state", { credentials: "same-origin" }).then(function (r) { return r.json(); })
      .then(function (d) { if (d && d.allowed) { S.state = d; } if (cb) cb(); }).catch(function () { if (cb) cb(); });
  }
  function viewHome() {
    setHead("House chat", "Chainsaw Man · the manor", ib("✕", "Close", closePanel), [ib("⚙", "Settings", function () { S.returnTo = "home"; go("settings"); })]);
    bodyEl.textContent = "";
    var sc = S.state.scenario;
    bodyEl.appendChild(h("div", { class: "cb-hero" }, [h("h2", { text: sc.title }),
      h("p", { text: "Public Safety HQ is under renovation, so Public Safety rented a manor for Division 4. It's your home and your base of operations until HQ reopens. Pick who's home and see what happens." })]));
    bodyEl.appendChild(h("button", { class: "cb-btn", type: "button", text: "＋ New chat", onclick: function () { S.draft = null; go("room"); } }));
    bodyEl.appendChild(h("div", { class: "cb-sec", text: "Your chats" }));
    var chats = S.state.chats || [];
    if (!chats.length) bodyEl.appendChild(h("div", { class: "cb-note", text: "Nothing yet. Start a new chat to move everybody in." }));
    chats.forEach(function (c) {
      var emo = c.cast.map(function (id) { var x = charById(id); return x ? x.emoji : ""; }).join(" ");
      var title = h("div", { class: "cb-rname" }, [c.title]);
      if (c.nsfw) title.appendChild(h("span", { class: "cb-tag nsfw", text: "18+" }));
      var row = h("div", { class: "cb-row", role: "button", tabindex: "0" }, [
        h("div", { class: "cb-rmain" }, [title, h("div", { class: "cb-rsub", text: emo + "  ·  " + c.count + " messages  ·  " + ago(c.updated) })]),
        h("button", { class: "cb-act", type: "button", text: "Delete", onclick: function (e) {
          e.stopPropagation();
          if (!confirm("Delete \"" + c.title + "\"?")) return;
          outThen(row, function () { api({ op: "delete", id: c.id }).then(function () { refreshState(function () { go("home"); }); }); });
        } })]);
      row.addEventListener("click", function () { openChat(c.id); });
      bodyEl.appendChild(row);
    });
  }
  function openChat(id) {
    api({ op: "get", id: id }).then(function (d) {
      if (!d.ok) { alert(d.error || "Couldn't open that chat"); return; }
      S.chat = d.chat; S.error = ""; S.speaker = ""; S.sel = ""; S.editing = ""; go("chat");
    });
  }

  /* ---------- room (new chat / edit who is home) ---------- */
  function viewRoom() {
    var editing = S.draft && S.draft.edit;
    if (!S.draft) S.draft = { cast: (S.state.default_cast || []).slice(), nsfw: false, title: "" };
    var D = S.draft, ok = !!S.state.settings.nsfw_ok;
    setHead(editing ? "Who's home" : "New chat", "Choose the housemates", ib("‹", "Back", function () { S.draft = null; go(editing ? "chat" : "home"); }));
    bodyEl.textContent = "";
    if (!editing) bodyEl.appendChild(h("label", { class: "cb-field" }, [h("span", { text: "Chat name (optional)" }),
      h("input", { class: "cb-in", type: "text", maxlength: "60", value: D.title || "", placeholder: "Manor chaos", oninput: function (e) { D.title = e.target.value; } })]));
    bodyEl.appendChild(h("div", { class: "cb-sec", text: "Housemates" }));
    S.state.characters.forEach(function (c) {
      var on = D.cast.indexOf(c.id) >= 0;
      var nm = h("div", { class: "cb-rname" }, [c.name, h("span", { class: "cb-tag" + (c.adult ? " adult" : ""), text: c.adult ? "ADULT" : "ALL-AGES ONLY" })]);
      var row = h("div", { class: "cb-row cb-pick" + (on ? " on" : ""), role: "button", tabindex: "0" }, [avatar(c),
        h("div", { class: "cb-rmain" }, [nm, h("div", { class: "cb-rsub", text: c.tagline })]), h("div", { class: "cb-check", text: on ? "✓" : "" })]);
      row.addEventListener("click", function () {
        var i = D.cast.indexOf(c.id);
        if (i >= 0) D.cast.splice(i, 1); else D.cast.push(c.id);
        row.classList.toggle("on", i < 0); row.querySelector(".cb-check").textContent = i < 0 ? "✓" : "";
      });
      bodyEl.appendChild(row);
    });
    bodyEl.appendChild(h("div", { class: "cb-sec", text: "Content" }));
    var cb = h("input", { type: "checkbox", disabled: !ok, onchange: function (e) { D.nsfw = e.target.checked; } });
    cb.checked = !!(D.nsfw && ok);
    bodyEl.appendChild(h("label", { class: "cb-row", style: "cursor:" + (ok ? "pointer" : "default") }, [cb,
      h("div", { class: "cb-rmain" }, [h("div", { class: "cb-rname", text: "Mature content (18+)" }),
        h("div", { class: "cb-rsub", style: "white-space:normal", text: ok ? "Allows sexual and graphic content between ADULT characters only." : "Turn this on in Settings first (needs the 18+ confirmation)." })])]));
    bodyEl.appendChild(h("div", { class: "cb-note", text: "Characters marked ALL-AGES ONLY (minors, or ages that aren't stated) never get sexual content, whatever this switch says." }));
    bodyEl.appendChild(h("button", { class: "cb-btn", type: "button", text: editing ? "Save" : "Start chat", onclick: function () {
      if (!D.cast.length) { alert("Pick at least one housemate."); return; }
      var req = editing ? { op: "setchat", id: S.chat.id, cast: D.cast, nsfw: !!D.nsfw }
                        : { op: "new", cast: D.cast, nsfw: !!D.nsfw, title: D.title || "" };
      api(req).then(function (d) {
        if (!d.ok) { alert(d.error || "Couldn't do that"); return; }
        S.chat = d.chat; S.draft = null; S.error = ""; S.speaker = "";
        refreshState(function () { go("chat"); });
      });
    } }));
  }

  /* ---------- story moments: pop-up, bell, tab ---------- */
  var MOM_LABEL = { remember: "Remembered", feel: "Feeling", bond: "Bond", hurt: "Hurt", annoyed: "Annoyed" };
  var momBox = null, momQ = [], momTimer = 0;
  function momToast(list) {
    (list || []).forEach(function (x) { momQ.push(x); });
    if (!momTimer) momPump();
  }
  function momPump() {
    var x = momQ.shift();
    if (!x) { momTimer = 0; return; }
    if (!momBox) { momBox = h("div", { class: "cb-toasts", "aria-live": "polite" }); document.body.appendChild(momBox); }
    var c = charById(x.cid);
    var t = h("div", { class: "cb-mom", role: "status", style: "--mc:" + ((c && c.color) || "#ff7a59") }, [avatar(c, true),
      h("div", { style: "min-width:0;flex:1" }, [h("div", { class: "cb-mom-eye", text: MOM_LABEL[x.kind] || "Moment" }), h("div", { class: "cb-mom-line", text: x.line })])]);
    function kill() { t.classList.remove("show"); setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 450); }
    t.addEventListener("click", kill);
    momBox.appendChild(t);
    requestAnimationFrame(function () { requestAnimationFrame(function () { t.classList.add("show"); }); });
    setTimeout(kill, 6500);
    momTimer = setTimeout(momPump, 1100);   /* a chain of reactions lands one after another */
  }
  function unreadMoments() { return ((S.chat && S.chat.moments) || []).filter(function (x) { return !x.seen; }).length; }
  function bellBtn() {
    var b = ib("🔔", "Story moments", function () { go("moments"); });
    b.classList.add("cb-bell");
    var n = unreadMoments();
    b.dataset.n = n;
    if (n) b.appendChild(h("span", { class: "cb-bdg", text: n > 9 ? "9+" : String(n) }));
    return b;
  }
  function updateBell() {
    var b = headEl && headEl.querySelector(".cb-bell");
    if (!b) return;
    var n = unreadMoments(), prev = +b.dataset.n || 0;
    if (n === prev) return;
    b.dataset.n = n;
    var o = b.querySelector(".cb-bdg"); if (o) b.removeChild(o);
    if (n) b.appendChild(h("span", { class: "cb-bdg", text: n > 9 ? "9+" : String(n) }));
    if (n > prev) { b.classList.remove("ring"); void b.offsetWidth; b.classList.add("ring"); }
  }
  function viewMoments() {
    var c = S.chat, list = (c.moments || []).slice().reverse();
    setHead("Story moments", list.length ? list.length + " saved to the cast's memory" : "Nothing yet", ib("‹", "Back", function () { go("chat"); }));
    bodyEl.textContent = "";
    bodyEl.appendChild(h("div", { class: "cb-note", text: "When someone takes something to heart it pops up as it happens, lands here, and is saved to their memory for the rest of this chat." }));
    if (!list.length) bodyEl.appendChild(h("div", { class: "cb-note", text: "No moments yet. Keep playing." }));
    list.forEach(function (x) {
      var ch = charById(x.cid), col = (ch && ch.color) || "#ff7a59";
      bodyEl.appendChild(h("div", { class: "cb-row" + (x.seen ? "" : " cb-new"), style: "--mc:" + col + ";cursor:default" }, [avatar(ch),
        h("div", { class: "cb-rmain" }, [
          h("div", { class: "cb-mom-eye", style: "--mc:" + col, text: (MOM_LABEL[x.kind] || "Moment") + "  ·  " + ago(x.ts) }),
          h("div", { class: "cb-rname", style: "white-space:normal", text: x.line }),
          x.note && x.note !== x.line ? h("div", { class: "cb-rsub", style: "white-space:normal", text: x.note }) : null])]));
    });
    if (list.some(function (x) { return !x.seen; })) {
      (c.moments || []).forEach(function (x) { x.seen = true; });
      api({ op: "momseen", id: c.id });
    }
  }

  /* ---------- chat ---------- */
  var msgsEl, compEl, errEl, taEl, selEl, animLen = 0, animSw = {};
  function viewChat() {
    var c = S.chat;
    var sub = c.cast.map(function (id) { var x = charById(id); return x ? x.emoji : ""; }).join(" ");
    setHead(c.title, sub + (c.nsfw ? "  ·  18+" : ""), ib("‹", "Back", function () { refreshState(function () { go("home"); }); }),
      [bellBtn(), ib("👥", "Who's home / content", function () { S.draft = { edit: true, cast: c.cast.slice(), nsfw: !!c.nsfw }; go("room"); }),
       ib("✎", "Rename", function () { var t = prompt("Chat name", c.title); if (t && t.trim()) api({ op: "rename", id: c.id, title: t }).then(function (d) { if (d.ok) { S.chat = d.chat; viewChat(); } }); })]);
    bodyEl.textContent = "";
    bodyEl.style.cssText = "display:flex;flex-direction:column;padding:0;overflow:hidden";
    msgsEl = h("div", { class: "cb-body cb-msgs", style: "flex:1;padding:14px" });
    errEl = h("div");
    selEl = h("select", { class: "cb-in cb-who-sel", title: "Who answers", "aria-label": "Who answers", onchange: function (e) { S.speaker = e.target.value; } },
      [h("option", { value: "", text: "Anyone" })].concat(c.cast.map(function (id) { var x = charById(id); return x ? h("option", { value: id, text: x.name.split(" ")[0] }) : null; })));
    selEl.value = S.speaker;
    var whoWrap = buildWhoPicker(c);
    taEl = h("textarea", { class: "cb-in", rows: "1", placeholder: "Say or do something\u2026", title: "Put *actions* between asterisks", maxlength: "6000" });
    taEl.addEventListener("input", function () { taEl.style.height = "auto"; taEl.style.height = Math.min(140, taEl.scrollHeight) + "px"; });
    taEl.addEventListener("keydown", function (e) { if (e.key === "Enter" && !e.shiftKey && !e.isComposing && window.innerWidth > 800) { e.preventDefault(); send(); } });
    compEl = h("div", { class: "cb-comp" }, [whoWrap, taEl,
      (function () { var b = ib("", "Next beat: let the scene move on", function () { gen("continue"); }); b.appendChild(icon("next")); return b; })(),
      (function () { var b = ib("", "Send", send); b.style.cssText = "background:var(--accent1,#ff7a59);color:#1a1016"; b.appendChild(icon("send")); return b; })()]);
    bodyEl.appendChild(msgsEl); bodyEl.appendChild(errEl); bodyEl.appendChild(compEl);
    animLen = c.messages.length; animSw = {}; c.messages.forEach(function (x) { animSw[x.id] = x.sw; });
    renderMsgs(true); renderErr();
  }
  /* softer "who answers" picker: a rounded pill + popover. Writes through to the hidden select and S.speaker, so sending is unchanged. */
  function buildWhoPicker(c) {
    var opts = [{ id: "", name: "Anyone", emoji: "✦", color: "" }];
    c.cast.forEach(function (id) { var x = charById(id); if (x) opts.push({ id: id, name: x.name.split(" ")[0], emoji: x.emoji, color: x.color || "" }); });
    var pill = h("button", { class: "cb-who-pill", type: "button", title: "Who answers", "aria-label": "Who answers", "aria-haspopup": "listbox" });
    var pop = h("div", { class: "cb-who-pop", role: "listbox" });
    var wrap = h("div", { class: "cb-who-wrap" }, [pop, pill]);
    function cur() { for (var i = 0; i < opts.length; i++) if (opts[i].id === S.speaker) return opts[i]; return opts[0]; }
    function av(o) { return h("span", { class: "cb-wav", text: o.emoji || "•", style: o.color ? "border-color:" + o.color : "" }); }
    function paint() {
      var o = cur();
      pill.textContent = "";
      pill.appendChild(av(o)); pill.appendChild(h("span", { class: "cb-wn", text: o.name })); pill.appendChild(h("span", { class: "cb-chev", text: "▲" }));
      pop.textContent = "";
      opts.forEach(function (x, xi) {
        var b = h("button", { style: "--i:" + xi, class: "cb-who-opt" + (x.id === S.speaker ? " sel" : ""), type: "button", role: "option", onclick: function () {
          S.speaker = x.id; selEl.value = x.id; close(); paint();
        } }, [av(x), h("span", { text: x.name })]);
        if (x.id === S.speaker) b.appendChild(h("span", { class: "cb-tick", text: "✓" }));
        pop.appendChild(b);
      });
    }
    function close() { pop.classList.remove("open"); pill.classList.remove("on"); }
    pill.addEventListener("click", function (e) { e.stopPropagation(); var o = !pop.classList.contains("open"); pop.classList.toggle("open", o); pill.classList.toggle("on", o); });
    function away(e) { if (!wrap.isConnected) { document.removeEventListener("click", away); document.removeEventListener("keydown", esc); return; } if (!wrap.contains(e.target)) close(); }
    function esc(e) { if (e.key === "Escape") close(); }
    document.addEventListener("click", away); document.addEventListener("keydown", esc);
    paint();
    return wrap;
  }
  function slider(label, el, ends, fmt) {
    var val = h("span", { class: "cb-sl-val" });
    function sync() {
      var min = +el.min, max = +el.max, v = +el.value;
      el.style.setProperty("--p", (max > min ? ((v - min) / (max - min)) * 100 : 0) + "%");
      val.textContent = fmt(v);
    }
    el.addEventListener("input", function () { sync(); val.classList.remove("bump"); void val.offsetWidth; val.classList.add("bump"); }); sync();
    return h("div", { class: "cb-sl" }, [h("div", { class: "cb-sl-top" }, [h("span", { class: "cb-sl-name", text: label }), val]), el,
      h("div", { class: "cb-sl-ends" }, [h("span", { text: ends[0] }), h("span", { text: ends[1] })])]);
  }
  function renderErr() {
    if (!errEl) return;
    errEl.textContent = "";
    if (!S.error) return;
    errEl.appendChild(h("div", { class: "cb-err" }, [h("span", { text: S.error }),
      h("button", { class: "cb-act", type: "button", text: "Retry", onclick: function () { S.error = ""; renderErr(); gen("continue"); } }),
      h("button", { class: "cb-act", type: "button", text: "Settings", onclick: function () { S.returnTo = "chat"; go("settings"); } })]));
  }
  function lastAssistantId() {
    var m = S.chat.messages; for (var i = m.length - 1; i >= 0; i--) if (m[i].role === "assistant") return m[i].id; return "";
  }
  function stamp(ts) {
    if (!ts) return "";
    var d = new Date(ts * 1000), now = new Date();
    var t = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    return d.toDateString() === now.toDateString() ? t : d.toLocaleDateString([], { month: "short", day: "numeric" }) + " \u00b7 " + t;
  }
  function renderMsgs(stick) {
    var lastWrap = null, keepTop = msgsEl.scrollTop, anyFresh = false;
    var c = S.chat, last = lastAssistantId(), me = (S.state && S.state.settings.persona_name) || (S.state && S.state.me) || "You";
    msgsEl.textContent = "";
    c.messages.forEach(function (m, idx) {
      var text = m.swipes[m.sw] || "", wrap = h("div");
      var fresh = idx >= animLen || (m.role === "assistant" && animSw[m.id] !== undefined && animSw[m.id] !== m.sw);
      if (fresh) anyFresh = true;
      if (m.role === "user" && idx > 0) msgsEl.appendChild(h("div", { class: "cb-sep" }, [h("span", { text: stamp(m.ts) })]));
      if (S.editing === m.id) {
        var ta = h("textarea", { class: "cb-in", rows: "5", maxlength: "6000" }); ta.value = text;
        wrap.appendChild(ta);
        wrap.appendChild(h("div", { class: "cb-acts", style: "margin-left:0" }, [
          h("button", { class: "cb-act", type: "button", text: "Save", onclick: function () { api({ op: "edit", id: c.id, mid: m.id, text: ta.value }).then(function (d) { S.editing = ""; if (d.ok) S.chat = d.chat; else S.error = d.error || ""; renderMsgs(false); renderErr(); }); } }),
          h("button", { class: "cb-act", type: "button", text: "Cancel", onclick: function () { S.editing = ""; renderMsgs(false); } })]));
        msgsEl.appendChild(wrap); return;
      }
      if (m.role === "user") {
        wrap.appendChild(h("div", { class: "cb-msg me" + (fresh ? " cb-pop-r" : "") }, [h("div", { class: "cb-bub" }, [h("span", { class: "cb-who", text: me }), fmt(text)])]));
      } else {
        var isLatest = m.id === last && c.messages.length > 1;
        var grp = h("div", { class: "cb-grp" + (isLatest ? " cb-latest" : "") });
        if (isLatest) grp.appendChild(h("div", { class: "cb-latest-tag", text: "LATEST" }));
        parseBlocks(text).forEach(function (b, bi) {
          var bub = h("div", { class: "cb-bub" }, [h("span", { class: "cb-who", style: "color:" + ((b.c && b.c.color) || "inherit"), text: b.who }), fmt(b.text.trim())]);
          grp.appendChild(h("div", { class: "cb-blk" + (b.c ? "" : " cb-narr") + (fresh ? " cb-pop" : ""), style: fresh ? "--d:" + (bi * 170) + "ms" : "" }, [b.c ? avatar(b.c, true) : h("div", { class: "cb-av sm", text: "📖", style: "background:rgba(255,255,255,.06)" }), bub]));
        });
        wrap.appendChild(grp);
      }
      var acts = h("div", { class: "cb-acts" + (S.sel === m.id ? " cb-rise" : ""), style: m.role === "user" ? "justify-content:flex-end;margin-right:4px" : "" });
      var show = S.sel === m.id || m.id === last;
      if (show) {
        if (m.id === last) {
          if (m.swipes.length > 1) {
            acts.appendChild(h("button", { class: "cb-act", type: "button", text: "‹", onclick: function () { swipe(m.id, -1); } }));
            acts.appendChild(h("span", { class: "cb-sw", text: (m.sw + 1) + " / " + m.swipes.length }));
            acts.appendChild(h("button", { class: "cb-act", type: "button", text: "›", onclick: function () { swipe(m.id, 1); } }));
          }
          if (c.messages[c.messages.length - 1].id === m.id)
            acts.appendChild(act("more", "Continue", function () { gen("extend"); }, looksCut(text) ? "cb-go" : ""));
          acts.appendChild(act("regen", "Regenerate", function () { gen("regen"); }));
        }
        acts.appendChild(h("button", { class: "cb-act", type: "button", text: "Edit", onclick: function () { S.editing = m.id; renderMsgs(false); } }));
        acts.appendChild(h("button", { class: "cb-act", type: "button", text: "Delete", onclick: function () {
          if (!confirm("Delete this message?")) return;
          outThen(wrap, function () { api({ op: "delmsg", id: c.id, mid: m.id }).then(function (d) { if (d.ok) { S.chat = d.chat; S.sel = ""; renderMsgs(false); } }); });
        } }));
        wrap.appendChild(acts);
      } else if (idx >= 0) {
        wrap.firstChild.addEventListener("click", function () { S.sel = m.id; renderMsgs(false); });
      }
      if (m.id === last) lastWrap = wrap;
      msgsEl.appendChild(wrap);
    });
    if (S.busy) msgsEl.appendChild(h("div", { class: "cb-msg" }, [h("div", { class: "cb-bub cb-dots" }, [h("span"), h("span"), h("span")])]));
    updateBell();
    if (stick !== false) {
      msgsEl.scrollTop = msgsEl.scrollHeight;
      /* a long new reply opens at its beginning instead of its end */
      if (!S.busy && lastWrap && c.messages.length > 1 && c.messages[c.messages.length - 1].id === last &&
          lastWrap.offsetHeight > msgsEl.clientHeight - 90) msgsEl.scrollTop = Math.max(0, lastWrap.offsetTop - 12);
    }
    /* new messages: glide the scroll instead of jumping */
    if (stick !== false && anyFresh) {
      var tgt = msgsEl.scrollTop;
      if (Math.abs(tgt - keepTop) > 4) { msgsEl.scrollTop = keepTop; msgsEl.scrollTo({ top: tgt, behavior: reduced() ? "auto" : "smooth" }); }
    }
    animLen = c.messages.length; animSw = {}; c.messages.forEach(function (x) { animSw[x.id] = x.sw; });
  }
  function swipe(mid, dir) {
    api({ op: "swipe", id: S.chat.id, mid: mid, dir: dir }).then(function (d) { if (d.ok) { S.chat = d.chat; renderMsgs(false); } });
  }
  function setBusy(on) {
    S.busy = on;
    if (compEl) Array.prototype.forEach.call(compEl.querySelectorAll("button,textarea,select"), function (el) { el.disabled = on; });
    renderMsgs(true);
  }
  function send() {
    var text = taEl.value.trim();
    if (!text || S.busy) return;
    taEl.value = ""; taEl.style.height = "auto";
    S.error = ""; renderErr(); S.pending = text;
    S.chat.messages.push({ id: "tmp" + Date.now(), role: "user", swipes: [text], sw: 0, ts: Math.floor(Date.now() / 1000) });
    setBusy(true);
    api({ op: "send", id: S.chat.id, text: text, speaker: S.speaker }).then(done);
  }
  function gen(mode) {
    if (S.busy) return;
    S.pending = "";
    S.error = ""; renderErr(); setBusy(true);
    api({ op: mode, id: S.chat.id, speaker: S.speaker }).then(done);
  }
  function done(d) {
    S.busy = false;
    if (d && d.chat) S.chat = d.chat;
    else if (S.pending) {                       // the server refused before saving it: take the message back
      S.chat.messages = S.chat.messages.filter(function (m) { return m.id.indexOf("tmp") !== 0; });
      if (taEl && !taEl.value) taEl.value = S.pending;
    }
    S.pending = "";
    if (d && d.new_moments && d.new_moments.length) momToast(d.new_moments);
    S.error = d && !d.ok ? (d.error || "Something went wrong") : "";
    if (compEl) Array.prototype.forEach.call(compEl.querySelectorAll("button,textarea,select"), function (el) { el.disabled = false; });
    renderMsgs(true); renderErr();
    if (taEl && !S.error) taEl.focus();
  }

  /* ---------- settings ---------- */
  var PRESETS = [
    ["Pick a preset...", ""],
    ["Ollama (this phone / PC)", "http://127.0.0.1:11434/v1"],
    ["LM Studio", "http://127.0.0.1:1234/v1"],
    ["KoboldCpp", "http://127.0.0.1:5001/v1"],
    ["OpenRouter", "https://openrouter.ai/api/v1"],
    ["OpenAI", "https://api.openai.com/v1"]
  ];
  function viewSettings() {
    var s = S.state.settings;
    setHead("Chat settings", "Model, persona and content", ib("‹", "Back", function () { go(S.returnTo === "chat" && S.chat ? "chat" : "home"); }));
    bodyEl.textContent = "";
    var f = {};
    function field(label, el) { return h("label", { class: "cb-field" }, [h("span", { text: label }), el]); }
    f.url = h("input", { class: "cb-in", type: "text", value: s.base_url || "", placeholder: "https://.../v1", autocomplete: "off", autocapitalize: "off" });
    f.preset = h("select", { class: "cb-in", onchange: function (e) { if (e.target.value) f.url.value = e.target.value; } }, PRESETS.map(function (p) { return h("option", { value: p[1], text: p[0] }); }));
    f.model = h("input", { class: "cb-in", type: "text", value: s.model || "", placeholder: "e.g. llama3.1:8b or a model id", autocomplete: "off", autocapitalize: "off" });
    f.key = h("input", { class: "cb-in", type: "password", placeholder: s.has_key ? "Saved. Type to replace" : "Optional for local models", autocomplete: "new-password" });
    f.clear = h("input", { type: "checkbox" });
    f.temp = h("input", { class: "cb-range", type: "range", step: "0.05", min: "0", max: "2", value: s.temperature });
    f.max = h("input", { class: "cb-range", type: "range", step: "50", min: "50", max: "3000", value: s.max_tokens });
    f.ctx = h("input", { class: "cb-range", type: "range", step: "1000", min: "4000", max: "80000", value: s.context_chars });
    f.pname = h("input", { class: "cb-in", type: "text", maxlength: "40", value: s.persona_name || "", placeholder: "Defaults to your Vizah name" });
    f.pdesc = h("textarea", { class: "cb-in", maxlength: "1200", placeholder: "Who are you at the manor? (a new Division 4 recruit, Makima's nephew, a Public Safety inspector ... )" });
    f.pdesc.value = s.persona_desc || "";
    f.nsfw = h("input", { type: "checkbox" }); f.nsfw.checked = !!s.nsfw_ok;
    bodyEl.appendChild(h("div", { class: "cb-sec", text: "Model" }));
    bodyEl.appendChild(h("div", { class: "cb-note", text: "Vizah doesn't ship a model. Point this at any OpenAI-compatible endpoint: Ollama or LM Studio running on your own machine, or a hosted one (OpenRouter, OpenAI). For mature roleplay, pick a model that allows it." }));
    bodyEl.appendChild(field("Preset", f.preset)); bodyEl.appendChild(field("Endpoint", f.url)); bodyEl.appendChild(field("Model", f.model));
    bodyEl.appendChild(field("API key", f.key));
    if (s.has_key) bodyEl.appendChild(h("label", { class: "cb-note", style: "display:flex;gap:8px;align-items:center" }, [f.clear, "Remove the saved key"]));
    bodyEl.appendChild(slider("Creativity", f.temp, ["Steady", "Wild"], function (v) { return v.toFixed(2); }));
    bodyEl.appendChild(slider("Reply length", f.max, ["Short", "Long"], function (v) { return v + " tokens"; }));
    bodyEl.appendChild(slider("Memory", f.ctx, ["Short-term", "Long-term"], function (v) { return Math.round(v / 1000) + "k chars"; }));
    bodyEl.appendChild(h("div", { class: "cb-sec", text: "You in the story" }));
    bodyEl.appendChild(field("Your name", f.pname)); bodyEl.appendChild(field("About your character", f.pdesc));
    bodyEl.appendChild(h("div", { class: "cb-sec", text: "Mature content" }));
    bodyEl.appendChild(h("label", { class: "cb-row", style: "cursor:pointer" }, [f.nsfw, h("div", { class: "cb-rmain" }, [
      h("div", { class: "cb-rname", text: "I'm 18 or older and want 18+ chats available" }),
      h("div", { class: "cb-rsub", style: "white-space:normal", text: "Lets you switch a chat to mature mode. Applies to ADULT characters only. Minors and characters with no stated age never get sexual content." })])]));
    var msg = h("div", { class: "cb-note" });
    bodyEl.appendChild(h("div", { style: "display:flex;gap:10px;align-items:center;margin-top:6px" }, [
      h("button", { class: "cb-btn", type: "button", text: "Save", onclick: function () {
        api({ op: "settings", base_url: f.url.value, model: f.model.value, api_key: f.key.value, clear_key: f.clear.checked,
              temperature: f.temp.value, max_tokens: f.max.value, context_chars: f.ctx.value,
              persona_name: f.pname.value, persona_desc: f.pdesc.value, nsfw_ok: f.nsfw.checked }).then(function (d) {
          if (d.ok) { S.state.settings = d.settings; msg.textContent = "Saved."; f.key.value = ""; } else msg.textContent = d.error || "Couldn't save";
        });
      } }), msg]));
  }

  /* ---------- login follow (same trick as dm.js: #appRoot loses .pre once you're logged in) ---------- */
  function setReady(on) {
    if (on === S.ready) return;
    S.ready = on;
    if (on && !S.loaded) {
      S.loaded = true;
      fetch("/chatbot/state", { credentials: "same-origin" }).then(function (r) { return r.json(); }).then(function (d) {
        if (!d || !d.allowed) return;            // not a dev account: nothing is ever added to the page
        S.allowed = true; S.state = d; mount();
        if (S.ready && !S.open) launch.classList.remove("cb-away");
      }).catch(function () { S.loaded = false; });
    } else if (S.mounted) {
      if (on) { if (!S.open) launch.classList.remove("cb-away"); }
      else { closePanel(); launch.classList.add("cb-away"); }
    }
  }
  function sync() {
    var root = document.getElementById("appRoot");
    setReady(!!root && !root.classList.contains("pre"));
  }
  var root = document.getElementById("appRoot");
  if (root) new MutationObserver(sync).observe(root, { attributes: true, attributeFilter: ["class"] });
  sync();
})();
