/* Vizah DMs + friend profiles (added). Friends only. Self-contained: builds its own DOM and CSS, only talks to /social/*,
   and does nothing until the existing app has logged you in. */
(function () {
  "use strict";
  if (window.__vizahDM) return;
  window.__vizahDM = true;

  var css = [
    ".dm-launch{position:fixed;right:0;bottom:200px;z-index:45;display:flex;align-items:center;gap:10px;padding:20px 20px 20px 24px;border:1px solid var(--glass-border,rgba(255,255,255,.12));border-right:0;border-radius:22px 0 0 22px;background:rgba(16,12,18,.72);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);color:var(--text,#f8f9ff);cursor:pointer;font:600 .8rem var(--small-font,system-ui,sans-serif);box-shadow:0 8px 24px rgba(0,0,0,.35);transition:transform .25s ease,opacity .25s ease}",
    ".dm-launch:hover{transform:translateX(-3px)}",
    ".dm-launch svg{width:32px;height:32px;display:block}",
    ".dm-launch .dm-badge{min-width:24px;height:24px;border-radius:12px;font-size:.8rem;line-height:24px}",
    ".dm-launch.dm-away{transform:translateX(110%);pointer-events:none;opacity:0}",
    ".dm-launch.dm-fade{pointer-events:none;opacity:0}",
    ".dm-badge{min-width:18px;height:18px;padding:0 5px;border-radius:9px;background:var(--accent1,#ff7a59);color:#1a1016;font:700 .68rem/18px var(--small-font,system-ui,sans-serif);text-align:center}",
    ".dm-panel{position:fixed;top:auto;right:12px;bottom:12px;z-index:46;width:min(318px,calc(100vw - 24px));height:min(520px,calc(100vh - 24px));display:flex;flex-direction:column;overflow:hidden;border:1px solid var(--glass-border,rgba(255,255,255,.12));border-radius:20px;background:rgba(14,11,20,.86);-webkit-backdrop-filter:blur(22px);backdrop-filter:blur(22px);color:var(--text,#f8f9ff);font-family:var(--small-font,system-ui,sans-serif);box-shadow:0 20px 60px rgba(0,0,0,.5);transform:translateX(calc(100% + 24px));transition:transform .3s cubic-bezier(.2,.8,.2,1);visibility:hidden}",
    ".dm-panel.dm-open{transform:none;visibility:visible}",
    ".dm-head{display:flex;align-items:center;gap:10px;padding:12px 12px 10px 14px;border-bottom:1px solid rgba(255,255,255,.08);min-height:56px}",
    ".dm-title{flex:1;min-width:0;font-weight:700;font-size:.98rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    ".dm-ib{width:34px;height:34px;flex:0 0 auto;display:grid;place-items:center;border:0;border-radius:50%;background:rgba(255,255,255,.07);color:inherit;cursor:pointer;font-size:1.1rem}",
    ".dm-ib:hover{background:rgba(255,255,255,.14)}",
    ".dm-tabs{display:flex;gap:6px;padding:10px 12px 0}",
    ".dm-tab{flex:1;padding:8px;border:0;border-radius:10px;background:transparent;color:var(--muted,rgba(248,249,255,.72));font:600 .78rem var(--small-font,system-ui,sans-serif);cursor:pointer}",
    ".dm-tab.on{background:rgba(255,255,255,.1);color:var(--text,#f8f9ff)}",
    ".dm-search{margin:10px 12px 4px;padding:9px 12px;border:1px solid rgba(255,255,255,.1);border-radius:12px;background:rgba(255,255,255,.05);color:inherit;font:.85rem var(--small-font,system-ui,sans-serif);outline:none}",
    ".dm-search:focus{border-color:var(--accent3,#79e7ff)}",
    ".dm-list{flex:1;overflow-y:auto;padding:6px 6px 10px}",
    ".dm-row{display:flex;align-items:center;gap:11px;width:100%;padding:9px 10px;border:0;border-radius:12px;background:transparent;color:inherit;text-align:left;cursor:pointer;font:inherit}",
    ".dm-row:hover{background:rgba(255,255,255,.07)}",
    ".dm-rmain{flex:1;min-width:0}",
    ".dm-rname{font-weight:600;font-size:.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    ".dm-rsub{margin-top:2px;font-size:.76rem;color:var(--muted,rgba(248,249,255,.72));white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    ".dm-row.unread .dm-rsub{color:var(--text,#f8f9ff);font-weight:600}",
    ".dm-empty{padding:28px 18px;text-align:center;color:var(--muted,rgba(248,249,255,.72));font-size:.84rem;line-height:1.5}",
    ".dm-av{position:relative;flex:0 0 auto;width:40px;height:40px;border-radius:50%;overflow:hidden;display:grid;place-items:center;background:linear-gradient(135deg,var(--accent1,#ff7a59),var(--accent3,#79e7ff));color:#1a1016;font-weight:800;text-transform:uppercase}",
    ".dm-av img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transform-origin:center center}",
    ".dm-av.sm{width:32px;height:32px;font-size:.8rem}.dm-av.xl{width:96px;height:96px;font-size:2.2rem;border:3px solid rgba(255,255,255,.2)}",
    ".dm-msgs{flex:1;overflow-y:auto;padding:12px 12px 6px;display:flex;flex-direction:column;gap:4px}",
    ".dm-b{max-width:80%;padding:8px 12px;border-radius:16px;font-size:.88rem;line-height:1.38;white-space:pre-wrap;overflow-wrap:anywhere;background:rgba(255,255,255,.1)}",
    ".dm-b.me{align-self:flex-end;background:linear-gradient(135deg,var(--accent1,#ff7a59),var(--accent2,#ffd166));color:#1a1016;border-bottom-right-radius:5px}",
    ".dm-b.them{align-self:flex-start;border-bottom-left-radius:5px}",
    ".dm-time{align-self:center;margin:8px 0 2px;font-size:.68rem;color:var(--muted,rgba(248,249,255,.72));opacity:.8}",
    ".dm-compose{display:flex;gap:8px;align-items:flex-end;padding:10px 12px 12px;border-top:1px solid rgba(255,255,255,.08)}",
    ".dm-input{flex:1;max-height:110px;min-height:38px;resize:none;padding:9px 12px;border:1px solid rgba(255,255,255,.1);border-radius:14px;background:rgba(255,255,255,.06);color:inherit;font:.88rem var(--small-font,system-ui,sans-serif);outline:none}",
    ".dm-input:focus{border-color:var(--accent3,#79e7ff)}",
    ".dm-send{flex:0 0 auto;height:38px;padding:0 16px;border:0;border-radius:14px;background:var(--accent3,#79e7ff);color:#10161c;font:700 .8rem var(--small-font,system-ui,sans-serif);cursor:pointer}",
    ".dm-send:disabled{opacity:.45;cursor:default}",
    ".dm-err{padding:6px 14px;color:#ff9d9d;font-size:.76rem}",
    ".dm-prof{flex:1;overflow-y:auto}",
    ".dm-cover{height:92px}",
    ".dm-pbody{margin-top:-48px;padding:0 20px 24px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:6px}",
    ".dm-pname{font-size:1.25rem;font-weight:800;margin-top:6px}",
    ".dm-pmeta{font-size:.8rem;color:var(--muted,rgba(248,249,255,.72))}",
    ".dm-on{display:inline-block;width:8px;height:8px;margin-right:6px;border-radius:50%;background:#58d68d}",
    ".dm-off{background:rgba(255,255,255,.3)}",
    ".dm-chip{display:inline-flex;align-items:center;gap:6px;margin-top:6px;padding:7px 12px;border-radius:999px;background:rgba(255,255,255,.08);color:inherit;text-decoration:none;font-size:.8rem}",
    ".dm-chip:hover{background:rgba(255,255,255,.15)}",
    ".dm-socials{display:flex;flex-wrap:wrap;justify-content:center;gap:0 8px;max-width:320px}",
    ".dm-ico{display:inline-flex;flex:none;font-style:normal}.dm-ico:empty{display:none}",
    ".dm-chip b{font-weight:700}.dm-chip span{opacity:.8;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
    ".dm-sw{display:flex;gap:6px;margin-top:10px}.dm-sw i{width:22px;height:22px;border-radius:50%;border:2px solid rgba(255,255,255,.2)}",
    ".dm-bio{margin-top:8px;max-width:280px;font-size:.88rem;line-height:1.4;white-space:pre-wrap;overflow-wrap:anywhere}",
    ".dm-listen{display:flex;align-items:center;gap:8px;max-width:300px;margin-top:10px;padding:8px 14px;border-radius:14px;background:rgba(255,255,255,.07);font-size:.82rem;line-height:1.3;text-align:left}",
    ".dm-listen b{display:block;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
    ".dm-listen small{display:block;color:var(--muted,rgba(248,249,255,.72));overflow:hidden;text-overflow:ellipsis;white-space:nowrap}",
    ".dm-eq{flex:0 0 auto;display:inline-flex;align-items:flex-end;gap:2px;height:14px}.dm-eq i{width:3px;background:var(--accent3,#79e7ff);border-radius:1px;animation:dmeq .9s ease-in-out infinite}.dm-eq i:nth-child(2){animation-delay:.2s}.dm-eq i:nth-child(3){animation-delay:.4s}",
    "@keyframes dmeq{0%,100%{height:4px}50%{height:14px}}",
    ".dm-sec{margin:10px 10px 4px;font-size:.66rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--muted,rgba(248,249,255,.72))}",
    ".dm-avw{position:relative;flex:0 0 auto}",
    ".dm-dot{position:absolute;right:-1px;bottom:-1px;width:12px;height:12px;border-radius:50%;background:#3ddc84;border:2px solid #0e0b14;box-sizing:border-box}",
    ".dm-dot[hidden]{display:none}",
    ".dm-rlisten{font-size:.72rem;opacity:.85}.dm-rlisten[hidden]{display:none}",
    ".dm-rnote{display:inline-block;margin-right:9px;font-size:.9em;color:var(--accent3,#79e7ff)}",
    ".dm-row.unread .dm-rlisten{font-weight:400;color:var(--muted,rgba(248,249,255,.72))}",
    ".dm-row.dm-offrow .dm-rname{opacity:.65}",
    ".dm-tw{flex:1;min-width:0}.dm-tw .dm-title{flex:none}",
    ".dm-hsub{margin-top:1px;font-size:.72rem;color:var(--muted,rgba(248,249,255,.72));white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    ".dm-cta{margin-top:16px;padding:11px 26px;border:0;border-radius:14px;background:var(--accent3,#79e7ff);color:#10161c;font:700 .86rem var(--small-font,system-ui,sans-serif);cursor:pointer}",
    ".dm-art{flex:0 0 auto;width:64px;height:64px;border-radius:12px;object-fit:cover;background:rgba(255,255,255,.1);box-shadow:0 6px 18px rgba(0,0,0,.35)}",
    ".dm-art.dm-ph{display:grid;place-items:center;font-size:1.6rem;color:var(--muted,rgba(248,249,255,.72));box-shadow:none}",
    ".dm-listen{gap:12px;padding:10px 16px 10px 10px}",
    ".dm-listen .dm-txt{min-width:0;flex:1}",
    ".dm-listen .dm-txt b{font-size:.92rem}",
    ".dm-listen .dm-subl{display:flex;align-items:center;gap:12px;margin-top:8px}",
    ".dm-vzbtn{margin-top:10px;padding:9px 20px;border:0;border-radius:999px;background:linear-gradient(135deg,var(--accent1,#ff7a59),var(--accent2,#ffd166));color:#1a1016;font:700 .82rem var(--small-font,system-ui,sans-serif);cursor:pointer}",
    ".dm-vzbtn:disabled{opacity:.6;cursor:default}",
    ".dm-vznote{margin-top:6px;font-size:.74rem;color:var(--muted,rgba(248,249,255,.72))}",
    ".dm-vznote.err{color:#ff9d9d}",
    ".dm-vz{display:flex;flex-direction:column;gap:10px;width:86%;box-sizing:border-box;padding:10px;border-radius:16px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.1)}",
    ".dm-vz.me{align-self:flex-end;border-bottom-right-radius:5px}",
    ".dm-vz.them{align-self:flex-start;border-bottom-left-radius:5px}",
    ".dm-vzh{font-size:.64rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--accent3,#79e7ff)}",
    ".dm-vzr{display:flex;gap:10px;align-items:center}",
    ".dm-vzr .dm-art{width:52px;height:52px;border-radius:10px;box-shadow:none}",
    ".dm-vzt{min-width:0;flex:1}",
    ".dm-vzt b{display:block;font-size:.86rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    ".dm-vzt small{display:block;font-size:.76rem;color:var(--muted,rgba(248,249,255,.72));white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    ".dm-vzs{font-size:.76rem;color:var(--muted,rgba(248,249,255,.72))}",
    ".dm-vzs.err{color:#ff9d9d}",
    ".dm-vza{display:flex;gap:8px}",
    ".dm-vza button{flex:1;padding:8px 10px;border:0;border-radius:10px;background:rgba(255,255,255,.12);color:inherit;font:700 .78rem var(--small-font,system-ui,sans-serif);cursor:pointer}",
    ".dm-vza button.main{background:var(--accent3,#79e7ff);color:#10161c}",
    ".dm-vza button:disabled{opacity:.55;cursor:default}",
    ".dm-notif{position:fixed;left:50%;bottom:max(18px,env(safe-area-inset-bottom));z-index:70;width:min(360px,calc(100vw - 28px));display:flex;align-items:center;gap:12px;padding:10px 12px;background:rgba(16,12,18,.82);border:1px solid rgba(255,255,255,.14);border-radius:16px;box-shadow:0 14px 40px rgba(0,0,0,.4);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);color:var(--text,#f8f9ff);font-family:var(--small-font,system-ui,sans-serif);cursor:pointer;opacity:0;transform:translate3d(-50%,24px,0);pointer-events:none;transition:opacity .35s ease,transform .35s cubic-bezier(.2,.8,.2,1),bottom .25s ease}",
    ".dm-notif.on{opacity:1;transform:translate3d(-50%,0,0);pointer-events:auto}",
    ".dm-notif.dm-stack{bottom:calc(max(18px,env(safe-area-inset-bottom)) + 76px)}",
    "html.lite .dm-notif{-webkit-backdrop-filter:none;backdrop-filter:none;background:rgba(16,12,18,.94)}",
    ".dm-n-art{flex:none;width:44px;height:44px;border-radius:10px;object-fit:cover;background:rgba(255,255,255,.08);display:grid;place-items:center;color:var(--muted,rgba(248,249,255,.72));font-size:1.1rem}",
    ".dm-notif .dm-av{width:44px;height:44px;font-size:1rem}",
    ".dm-n-body{flex:1;min-width:0}",
    ".dm-n-eyebrow{font-size:.7rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--accent2,#ffd166)}",
    ".dm-n-title,.dm-n-sub{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}",
    ".dm-n-title{font-size:.9rem;font-weight:800}",
    ".dm-n-sub{font-size:.78rem;color:var(--muted,rgba(248,249,255,.72))}",
    ".dm-n-act{margin-top:4px;padding:0;border:0;background:none;color:var(--accent3,#79e7ff);font:700 .78rem var(--small-font,system-ui,sans-serif);cursor:pointer}",
    ".dm-n-act:disabled{opacity:.6;cursor:default}",
    ".dm-n-x{flex:none;background:none;border:0;color:var(--muted,rgba(248,249,255,.72));font-size:1.25rem;line-height:1;cursor:pointer;padding:4px 8px}",
    ".dm-list,.dm-msgs,.dm-prof{scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.18) transparent;overscroll-behavior:contain}",
    ".dm-list::-webkit-scrollbar,.dm-msgs::-webkit-scrollbar,.dm-prof::-webkit-scrollbar{width:6px}",
    ".dm-list::-webkit-scrollbar-track,.dm-msgs::-webkit-scrollbar-track,.dm-prof::-webkit-scrollbar-track{background:transparent}",
    ".dm-list::-webkit-scrollbar-thumb,.dm-msgs::-webkit-scrollbar-thumb,.dm-prof::-webkit-scrollbar-thumb{background:rgba(255,255,255,.18);border-radius:999px}",
    "@media (max-width:520px){.dm-panel{right:8px;bottom:8px;width:calc(100vw - 16px);height:min(76vh,560px);border-radius:20px}}"
  ].join("\n");
  var st = document.createElement("style");
  st.id = "dm-style";
  st.textContent = css;
  document.head.appendChild(st);

  /* ---------- tiny helpers ---------- */
  function h(tag, attrs) {
    var el = document.createElement(tag);
    if (attrs) for (var k in attrs) {
      if (k === "class") el.className = attrs[k];
      else if (k === "text") el.textContent = attrs[k];
      else if (k.slice(0, 2) === "on") el.addEventListener(k.slice(2), attrs[k]);
      else el.setAttribute(k, attrs[k]);
    }
    for (var i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (c == null) continue;
      el.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    }
    return el;
  }
  function api(path, body) {
    var opt = body === undefined ? { cache: "no-store" } : {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
    };
    return fetch(path, opt).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) { d._status = r.status; return d; });
    }).catch(function () { return { ok: false, _status: 0, error: "Can't reach the server" }; });
  }
  function avatar(user, size) {
    var el = h("div", { class: "dm-av" + (size ? " " + size : "") }, (user.name || "?").charAt(0));
    if (user.hasAvatar) {
      var img = h("img", { alt: "", decoding: "async", src: "/social/avatar/" + encodeURIComponent(user.name) });
      var m = /^(\d+(?:\.\d+)?),(\d+(?:\.\d+)?),(\d(?:\.\d+)?)$/.exec(user.avatarCrop || "");
      if (m) {
        var cx = +m[1], cy = +m[2], cz = +m[3];
        var place = function () {
          var w = img.naturalWidth, hh = img.naturalHeight;
          if (!w || !hh) return;
          var mm = Math.min(w, hh), W = mm / cz;
          cx = Math.min(100 - (W / 2) / w * 100, Math.max((W / 2) / w * 100, cx));
          cy = Math.min(100 - (W / 2) / hh * 100, Math.max((W / 2) / hh * 100, cy));
          img.style.objectPosition = "50% 50%";
          img.style.transform = "translate(" + ((0.5 - cx / 100) * (w / mm) * cz * 100) + "%," +
            ((0.5 - cy / 100) * (hh / mm) * cz * 100) + "%) scale(" + cz + ")";
        };
        if (img.complete && img.naturalWidth) place(); else img.addEventListener("load", place, { once: true });
      }
      img.onerror = function () { img.remove(); };
      el.appendChild(img);
    }
    return el;
  }
  function clock(ts) {
    var d = new Date(ts * 1000), now = new Date();
    var t = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    if (d.toDateString() === now.toDateString()) return t;
    return d.toLocaleDateString([], { month: "short", day: "numeric" }) + ", " + t;
  }
  function short(ts) {
    var d = new Date(ts * 1000), now = new Date();
    return d.toDateString() === now.toDateString()
      ? d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })
      : d.toLocaleDateString([], { month: "short", day: "numeric" });
  }

  function ago(ts) {
    var m = Math.max(0, Math.floor((Date.now() / 1000 - ts) / 60));
    if (m < 1) return "just now";
    if (m < 60) return m + " min ago";
    if (m < 1440) return Math.floor(m / 60) + " hr ago";
    return Math.floor(m / 1440) + " d ago";
  }
  // "Listening to ..." line; returns {main, sub, live} or null when there is nothing to show
  function listenInfo(st) {
    if (!st || (st.state !== "playing" && st.state !== "recent") || !st.track) return null;
    var what = st.track + (st.artist ? " \u2014 " + st.artist : "");
    var more = { track: st.track, artist: st.artist || "", art: st.art || "" };
    if (st.state === "playing") return { main: what, sub: "Listening now", live: true, track: more.track, artist: more.artist, art: more.art };
    return { main: what, sub: "Last played" + (st.ts ? " " + ago(st.ts) : ""), live: false, track: more.track, artist: more.artist, art: more.art };
  }

  // one line for a friend: "♪ Song - Artist" while playing, otherwise "Last played 2 hr ago · Song - Artist"; "Online" if idle
  function statusText(info, on) {
    if (info) return info.live ? "\u266a " + info.main : info.sub + " \u00b7 " + info.main;
    return on ? "Online" : "";
  }
  function fillStatus(root, r) {
    if (!r || !r.status) return;
    root.querySelectorAll(".dm-rlisten").forEach(function (el) {
      var k = el.getAttribute("data-u");
      var on = el.hasAttribute("data-on") ? el.getAttribute("data-on") === "1" : !!(r.online && r.online[k]);
      var info = listenInfo(r.status[k]);
      var txt = statusText(info, on);
      el.textContent = "";
      if (info && info.live) {
        el.appendChild(h("span", { class: "dm-rnote", text: "\u266a" }));
        el.appendChild(document.createTextNode(info.main));
      } else el.textContent = txt;
      el.hidden = !txt;
    });
    root.querySelectorAll(".dm-dot[data-u]").forEach(function (d) { d.hidden = !(r.online && r.online[d.getAttribute("data-u")]); });
  }
  // shows cached statuses right away, then refreshes them at most every 15s
  function applyStatus(root) {
    if (S.stat) fillStatus(root, S.stat);
    if (Date.now() - S.statT > 15000) {
      S.statT = Date.now();
      api("/social/listening").then(function (r) { if (r.ok) { S.stat = r; fillStatus(root, r); } });
    }
  }

  // cover art tile; a note placeholder shows when there is no cover (or it fails to load)
  // Last.fm has no cover for some songs (the player gets it from YouTube Music instead): on your own profile,
  // borrow the cover the main player is showing, but only while it is the same song.
  function ownCover(track) {
    try {
      var t = document.getElementById("trackTitle"), c = document.getElementById("coverArt");
      if (!t || !c || c.style.display === "none") return "";
      var src = c.currentSrc || c.src || "";
      if (!/^(https?:|data:image\/|blob:)/i.test(src)) return "";
      return String(t.textContent).trim().toLowerCase() === String(track || "").trim().toLowerCase() ? src : "";
    } catch (e) { return ""; }
  }
  function artEl(url) {
    var ph = function () { return h("div", { class: "dm-art dm-ph", text: "\u266a" }); };
    if (!url) return ph();
    var img = h("img", { class: "dm-art", alt: "", loading: "lazy", referrerpolicy: "no-referrer", src: url });
    img.addEventListener("error", function () { img.replaceWith(ph()); });
    return img;
  }
  /* ---------- notifications: same look + behaviour as the "Up next" toast (bottom-centre, auto-hides after 8s) ---------- */
  var nEl = null, nT = 0, nNext = 0, nQueue = [], nShowing = false;
  function nArt(url) {
    var ph = function () { return h("div", { class: "dm-n-art", text: "\u266a" }); };
    if (!url) return ph();
    var img = h("img", { class: "dm-n-art", alt: "", decoding: "async", referrerpolicy: "no-referrer", src: url });
    img.addEventListener("error", function () { img.replaceWith(ph()); });
    return img;
  }
  function nHide() {
    clearTimeout(nT);
    if (nEl) nEl.classList.remove("on");
    nShowing = false;
    clearTimeout(nNext);
    nNext = setTimeout(nShowNext, 450);
  }
  function nShowNext() {
    if (nShowing || !nQueue.length) return;
    if (document.hidden) { nNext = setTimeout(nShowNext, 1500); return; }
    var o = nQueue.shift();
    if (!nEl) { nEl = h("div", { class: "dm-notif", role: "status", "aria-live": "polite" }); document.body.appendChild(nEl); }
    nEl.textContent = "";
    var act = null;
    if (o.action) {
      act = h("button", { class: "dm-n-act", type: "button", text: o.action.label });
      act.addEventListener("click", function (e) {
        e.stopPropagation();
        act.disabled = true;
        Promise.resolve(o.action.fn(act)).then(function (keep) { if (keep !== "stay") nHide(); }, nHide);
      });
    }
    var x = h("button", { class: "dm-n-x", type: "button", "aria-label": "Dismiss", text: "\u00d7" });
    x.addEventListener("click", function (e) { e.stopPropagation(); nHide(); });
    nEl.appendChild(o.art || nArt(""));
    nEl.appendChild(h("div", { class: "dm-n-body" },
      h("div", { class: "dm-n-eyebrow", text: o.eyebrow || "" }),
      h("div", { class: "dm-n-title", text: o.title || "" }),
      o.sub ? h("div", { class: "dm-n-sub", text: o.sub }) : null,
      act));
    nEl.appendChild(x);
    nEl.onclick = function () { nHide(); if (o.onclick) o.onclick(); };
    nEl.onmouseenter = function () { clearTimeout(nT); };
    nEl.onmouseleave = function () { clearTimeout(nT); nT = setTimeout(nHide, 3000); };
    // sit above the "Up next" toast if that one is showing at the same moment
    nEl.classList.toggle("dm-stack", !!document.querySelector(".nextup-toast.show"));
    nShowing = true;
    void nEl.offsetWidth;
    nEl.classList.add("on");
    clearTimeout(nT);
    nT = setTimeout(nHide, 8000);
  }
  // o: { key, eyebrow, title, sub, art (element), onclick, action: { label, fn } }
  function notify(o) {
    if (o.key) {
      for (var i = 0; i < nQueue.length; i++) if (nQueue[i].key === o.key) return;
    }
    nQueue.push(o);
    if (nQueue.length > 4) nQueue.shift();
    nShowNext();
  }
  function songLine(track, artist) { return (track || "") + (artist ? " \u2014 " + artist : ""); }
  // Vizah plays / results use the same toast
  function toast(song, line, action) {
    notify({ eyebrow: "Vizah", title: line, sub: songLine(song.track, song.artist), art: nArt(song.art), action: action });
  }
  // plays a Vizah in whichever service is active (YouTube Music over adb, or Spotify)
  function vizService(song) {
    if (song && typeof song.id === "string" && song.id.indexOf("sp_") === 0) return "Spotify";
    return window.__vizProvider === "spotify" ? "Spotify" : "YouTube Music";
  }
  function playSong(song, auto) {
    if (!song.id) return;
    // hand the artwork we already have to the player panel
    if (window.vizRememberArt) window.vizRememberArt(song.track, song.artist, song.art);
    // /music/play picks the right service for this song (Spotify ids start with "sp_")
    fetch("/music/play", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: song.id, track: song.track || "", artist: song.artist || "" })
    })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d && d.ok) toast(song, auto ? song.from + " sent you a Vizah" : "Playing your Vizah", null);
        else toast(song, "Couldn't start it in " + vizService(song), { label: "Try again", fn: function () { playSong(song, auto); } });
      })
      .catch(function () { toast(song, "Couldn't reach the server", null); });
  }

  // the asker's page claims a sent Vizah (the server lets exactly one tab do it, once), then plays it
  function claimAndPlay(id) {
    if (S.handled[id]) return;
    S.handled[id] = 1;
    api("/social/vizah/claim", { id: id }).then(function (d) {
      if (d.ok && d.song) playSong(d.song, true);
    });
  }

  /* ---------- DOM ---------- */
  var chatIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/></svg>';
  var badge = h("span", { class: "dm-badge", hidden: "" });
  var launch = h("button", { class: "dm-launch dm-away", type: "button", "aria-label": "Open messages", title: "Messages" }, badge);
  launch.insertAdjacentHTML("afterbegin", chatIcon);
  var head = h("div", { class: "dm-head" });
  var body = h("div", { style: "display:flex;flex-direction:column;flex:1;min-height:0" });
  var panel = h("aside", { class: "dm-panel", "aria-label": "Messages", role: "complementary" }, head, body);
  document.body.appendChild(launch);
  document.body.appendChild(panel);

  /* fade the DM button away once the YouTube section scrolls into view */
  (function () {
    var yt = null, tick = 0;
    function check() {
      tick = 0;
      yt = yt || document.getElementById("youtube");
      if (!yt) return;
      launch.classList.toggle("dm-fade", yt.getBoundingClientRect().top < window.innerHeight * 0.6);
    }
    function queue() { if (!tick) tick = requestAnimationFrame(check); }
    document.addEventListener("scroll", queue, true);
    window.addEventListener("resize", queue);
    queue();
  })();

  var S = { stat: null, statT: 0, ticks: 0, open: false, view: "list", tab: "chats", me: "", with: null, lastId: 0, convos: [], users: [], q: "", ready: false, timer: 0, pollGen: 0, vt: 0, handled: {} };

  function setBadge(n) {
    badge.hidden = !n;
    badge.textContent = n > 99 ? "99+" : String(n || "");
  }

  /* ---------- views ---------- */
  function headBar(title, opts) {
    opts = opts || {};
    head.textContent = "";
    if (opts.back) head.appendChild(h("button", { class: "dm-ib", type: "button", "aria-label": "Back", text: "\u2190", onclick: opts.back }));
    if (opts.avatar) head.appendChild(opts.avatar);
    if (opts.sub) head.appendChild(h("div", { class: "dm-tw" }, h("div", { class: "dm-title", text: title }), h("div", { class: "dm-hsub", hidden: "" })));
    else head.appendChild(h("div", { class: "dm-title", text: title }));
    head.appendChild(h("button", { class: "dm-ib", type: "button", "aria-label": "Close messages", text: "\u00d7", onclick: closePanel }));
  }

  function showList() {
    S.view = "list"; S.with = null;
    headBar("Messages");
    body.textContent = "";
    var tabs = h("div", { class: "dm-tabs" },
      h("button", { class: "dm-tab" + (S.tab === "chats" ? " on" : ""), type: "button", text: "Chats", onclick: function () { S.tab = "chats"; showList(); } }),
      h("button", { class: "dm-tab" + (S.tab === "people" ? " on" : ""), type: "button", text: "Friends", onclick: function () { S.tab = "people"; showList(); } }));
    body.appendChild(tabs);
    var list = h("div", { class: "dm-list" });
    if (S.tab === "people") {
      var s = h("input", { class: "dm-search", type: "search", placeholder: "Search friends", value: S.q, autocomplete: "off" });
      s.addEventListener("input", function () { S.q = s.value; loadUsers(list); });
      body.appendChild(s);
    }
    body.appendChild(list);
    if (S.tab === "chats") renderChats(list), refreshInbox(function () { if (S.view === "list" && S.tab === "chats") renderChats(list); });
    else loadUsers(list);
  }

  function renderChats(list) {
    list.textContent = "";
    if (!S.convos.length) {
      list.appendChild(h("div", { class: "dm-empty" }, "No conversations yet.", h("br"), "Open the Friends tab to say hi."));
      return;
    }
    S.convos.forEach(function (c) {
      var sub = (c.last.mine ? "You: " : "") + c.last.text;
      var k = c.name.toLowerCase();
      var row = h("button", { class: "dm-row" + (c.unread ? " unread" : ""), type: "button", onclick: function () { openThread(c.name); } },
        h("div", { class: "dm-avw" }, avatar(c), h("span", { class: "dm-dot", "data-u": k, hidden: "" })),
        h("div", { class: "dm-rmain" }, h("div", { class: "dm-rname", text: c.name }), h("div", { class: "dm-rsub", text: sub }), h("div", { class: "dm-rsub dm-rlisten", "data-u": k, hidden: "" })),
        h("div", { class: "dm-rsub", text: short(c.last.ts) }));
      if (c.unread) row.appendChild(h("span", { class: "dm-badge", text: String(c.unread) }));
      list.appendChild(row);
    });
    applyStatus(list);
  }

  var userGen = 0;
  function loadUsers(list) {
    var gen = ++userGen;
    api("/social/users?q=" + encodeURIComponent(S.q)).then(function (d) {
      if (gen !== userGen || S.view !== "list" || S.tab !== "people") return;
      list.textContent = "";
      if (!d.ok) { list.appendChild(h("div", { class: "dm-empty", text: d.error || "Couldn't load friends" })); return; }
      S.me = d.me || S.me;
      S.users = d.users;
      if (!d.users.length) {
        list.appendChild(h("div", { class: "dm-empty", text: S.q ? "No friend matches that." : "No friends yet. Add someone with the friends icon at the top, then you can message them here." }));
        return;
      }
      function userRow(u) {
        var k = u.name.toLowerCase();
        return h("div", { class: "dm-row" + (u.online ? "" : " dm-offrow"), role: "button", tabindex: "0", onclick: function () { openProfile(u.name); },
          onkeydown: function (e) { if (e.key === "Enter") openProfile(u.name); } },
          h("div", { class: "dm-avw" }, avatar(u), u.online ? h("span", { class: "dm-dot" }) : null),
          h("div", { class: "dm-rmain" }, h("div", { class: "dm-rname", text: u.name }), h("div", { class: "dm-rsub dm-rlisten", "data-u": k, "data-on": u.online ? "1" : "0", hidden: "" })),
          h("button", { class: "dm-ib", type: "button", title: "Message " + u.name, "aria-label": "Message " + u.name, onclick: function (e) { e.stopPropagation(); openThread(u.name); } }, "\u2709"));
      }
      var on = d.users.filter(function (u) { return u.online; }), off = d.users.filter(function (u) { return !u.online; });
      if (on.length) { list.appendChild(h("div", { class: "dm-sec", text: "Online \u2014 " + on.length })); on.forEach(function (u) { list.appendChild(userRow(u)); }); }
      if (off.length) { list.appendChild(h("div", { class: "dm-sec", text: "Offline \u2014 " + off.length })); off.forEach(function (u) { list.appendChild(userRow(u)); }); }
      applyStatus(list);
    });
  }

  function openProfile(name, backTo) {
    S.view = "profile"; S.with = null;
    headBar("Profile", { back: backTo || showList });
    body.textContent = "";
    var wrap = h("div", { class: "dm-prof" }, h("div", { class: "dm-empty", text: "Loading\u2026" }));
    body.appendChild(wrap);
    renderProfile(wrap, name, {});
  }

  // Draws a profile into `wrap`. opts.preview = "how others see it" (no buttons, and the listening box is
  // left out when you've turned sharing off); opts.alive() lets the caller drop a stale render.
  function renderProfile(wrap, name, opts) {
    opts = opts || {};
    var alive = opts.alive || function () { return S.view === "profile"; };
    api("/social/profile?u=" + encodeURIComponent(name)).then(function (d) {
      if (!alive()) return;
      wrap.textContent = "";
      if (!d.ok) { wrap.appendChild(h("div", { class: "dm-empty", text: d.error || "Couldn't load that profile" })); return; }
      var p = d.profile, c = p.colors || [];
      var cover = h("div", { class: "dm-cover" });
      cover.style.background = "linear-gradient(135deg," + (c[0] || "#ff7a59") + "," + (c[1] || "#ffd166") + "," + (c[2] || "#79e7ff") + ")";
      cover.style.opacity = ".85";
      var meta = [];
      var status = h("div", { class: "dm-pmeta" }, h("span", { class: "dm-on" + (p.online ? "" : " dm-off") }), p.online ? "Online" : "Offline");
      var pb = h("div", { class: "dm-pbody" }, avatar(p, "xl"), h("div", { class: "dm-pname", text: p.name }), status);
      if (p.joined) pb.appendChild(h("div", { class: "dm-pmeta", text: "Member since " + new Date(p.joined * 1000).toLocaleDateString([], { month: "long", year: "numeric" }) }));
      if (p.lastfm) pb.appendChild(h("a", { class: "dm-chip", href: "https://www.last.fm/user/" + encodeURIComponent(p.lastfm), target: "_blank", rel: "noopener noreferrer", text: "Last.fm \u00b7 " + p.lastfm }));
      if (p.socials && p.socials.length) {
        var soc = h("div", { class: "dm-socials" });
        p.socials.forEach(function (sl) {
          if (!sl || typeof sl.url !== "string" || !/^https?:\/\//i.test(sl.url)) return;   // only real web links
          var ic = h("i", { class: "dm-ico" });
          if (window.vizahSocialIcon) ic.innerHTML = window.vizahSocialIcon(sl.k, 16);   // fixed built-in logo per platform
          soc.appendChild(h("a", { class: "dm-chip dm-soc", href: sl.url, target: "_blank", rel: "noopener noreferrer nofollow", title: sl.label + " \u00b7 " + sl.name },
            ic, h("b", { text: sl.label }), h("span", { text: sl.name })));
        });
        if (soc.childNodes.length) pb.appendChild(soc);
      }
      if (p.bio) pb.appendChild(h("div", { class: "dm-bio", text: p.bio }));
      var lbox = h("div", { class: "dm-listen", hidden: "" });
      pb.appendChild(lbox);
      var vzWrap = h("div", { hidden: "", style: "display:flex;flex-direction:column;align-items:center" });
      pb.appendChild(vzWrap);
      api("/social/listening?u=" + encodeURIComponent(p.name)).then(function (r) {
        var info = r.ok && r.status ? listenInfo(r.status[p.name.toLowerCase()]) : null;
        if (!info || !alive()) return;
        if (opts.preview && p.showListening === false) return;   // others would not see it
        lbox.textContent = "";
        lbox.appendChild(artEl(info.art || (p.isMe ? ownCover(info.track) : "")));
        var sub = h("small", { class: "dm-subl" });
        if (info.live) sub.appendChild(h("span", { class: "dm-eq" }, h("i"), h("i"), h("i")));
        sub.appendChild(document.createTextNode(info.sub));
        lbox.appendChild(h("div", { class: "dm-txt" }, h("b", { text: info.track }), h("small", { text: info.artist }), sub));
        lbox.hidden = false;
        if (p.isMe) return;
        var note = h("div", { class: "dm-vznote", hidden: "" });
        var btn = h("button", { class: "dm-vzbtn", type: "button", text: "Ask for a Vizah" });
        btn.addEventListener("click", function () {
          btn.disabled = true; note.hidden = true;
          api("/social/vizah", { to: p.name }).then(function (d) {
            if (!d.ok) {
              btn.disabled = false;
              note.textContent = d.error || "Couldn't send that"; note.className = "dm-vznote err"; note.hidden = false;
              return;
            }
            btn.textContent = "Asked \u2713";
            note.textContent = "When " + p.name + " sends it, it plays in YouTube Music."; note.className = "dm-vznote"; note.hidden = false;
            refreshInbox();
          });
        });
        vzWrap.appendChild(btn); vzWrap.appendChild(note);
        vzWrap.hidden = false;
      });
      var sw = h("div", { class: "dm-sw", title: "Their theme" });
      c.forEach(function (col) { if (/^#[0-9a-f]{6}$/i.test(col)) { var i = h("i"); i.style.background = col; sw.appendChild(i); } });
      if (sw.childNodes.length) pb.appendChild(sw);
      if (opts.preview) {
        // preview inside Profile settings: just the profile, no buttons
      } else if (p.isMe) {
        pb.appendChild(h("div", { class: "dm-pmeta", style: "margin-top:14px", text: "This is how others see you." }));
        pb.appendChild(h("button", { class: "dm-cta", type: "button", text: "Edit profile", onclick: function () {
          closePanel();
          var b = document.getElementById("toggleSettings");
          if (b) b.click();
          if (window.vizahProfileEdit) window.vizahProfileEdit();   // straight into the editor
        } }));
      } else {
        pb.appendChild(h("button", { class: "dm-cta", type: "button", text: "Message", onclick: function () { openThread(p.name); } }));
      }
      wrap.appendChild(cover);
      wrap.appendChild(pb);
    });
  }

  var thread = { box: null, ta: null, send: null, err: null, lastDay: "", lastTs: 0 };

  function vizCard(m) {
    var vz = m.vz, who = S.with || "them";
    var el = h("div", { class: "dm-vz " + (m.mine ? "me" : "them"), "data-id": String(m.id) });
    var status = h("div", { class: "dm-vzs" });
    var title = vz.k === "share" ? (m.mine ? "You sent a song" : who + " sent you a song")
              : vz.k === "sent" ? (m.mine ? "You sent a Vizah" : who + " sent you a Vizah")
                                : (m.mine ? "You asked for a Vizah" : who + " wants a Vizah");
    el.appendChild(h("div", { class: "dm-vzh", text: title }));
    el.appendChild(h("div", { class: "dm-vzr" }, artEl(vz.art), h("div", { class: "dm-vzt" }, h("b", { text: vz.track || "" }), h("small", { text: vz.artist || "" }))));
    var song = { id: vz.vid || "", track: vz.track || "", artist: vz.artist || "", art: vz.art || "", from: who };
    function setState(st) {
      status.className = "dm-vzs"; status.textContent = "";
      var acts = el.querySelector(".dm-vza"); if (acts) acts.remove();
      if (vz.k === "sent" || vz.k === "share") {
        if (!m.mine) {
          var pb = h("button", { class: "main", type: "button", text: "\u25b6 Play", onclick: function () { playSong(song, false); } });
          el.appendChild(h("div", { class: "dm-vza" }, pb));
        }
        return;
      }
      if (st === "sent") status.textContent = m.mine ? who + " sent it \u2713" : "You sent it \u2713";
      else if (st === "declined") status.textContent = m.mine ? who + " passed" : "You passed";
      else if (m.mine) status.textContent = "Waiting for " + who + "\u2026";
      else {
        var send = h("button", { class: "main", type: "button", text: "Send it" });
        var no = h("button", { type: "button", text: "Not now" });
        var answer = function (action) {
          send.disabled = no.disabled = true;
          if (action === "send") send.textContent = "Finding it\u2026";
          api("/social/vizah/answer", { "with": who, id: m.id, action: action }).then(function (d) {
            if (d.ok) {
              vz.state = d.state; setState(d.state);
              if (d.message) { addBubble(d.message); thread.box.scrollTop = thread.box.scrollHeight; }
              refreshInbox();
            } else if (d.state) { vz.state = d.state; setState(d.state); }
            else { send.disabled = no.disabled = false; send.textContent = "Send it"; status.textContent = d.error || "Couldn't send it"; status.className = "dm-vzs err"; }
          });
        };
        send.addEventListener("click", function () { answer("send"); });
        no.addEventListener("click", function () { answer("decline"); });
        el.appendChild(h("div", { class: "dm-vza" }, send, no));
      }
    }
    el.appendChild(status);
    setState(vz.state);
    el.vzSet = setState;
    return el;
  }

  function addBubble(m) {
    if (!thread.box) return;
    if (!thread.lastTs || m.ts - thread.lastTs > 900) thread.box.appendChild(h("div", { class: "dm-time", text: clock(m.ts) }));
    thread.lastTs = m.ts;
    if (m.vz && (m.vz.k === "ask" || m.vz.k === "sent" || m.vz.k === "share")) thread.box.appendChild(vizCard(m));
    else thread.box.appendChild(h("div", { class: "dm-b " + (m.mine ? "me" : "them"), text: m.text }));
    // an answer (sent / passed) updates the matching request card that is already on screen
    if (m.vz && m.vz.ref) {
      var card = thread.box.querySelector('.dm-vz[data-id="' + m.vz.ref + '"]');
      if (card && card.vzSet) card.vzSet(m.vz.k === "sent" ? "sent" : "declined");
    }
    if (m.id > S.lastId) S.lastId = m.id;
  }
  function nearBottom() {
    var b = thread.box;
    return !b || b.scrollHeight - b.scrollTop - b.clientHeight < 80;
  }

  // "Online · ♪ Song - Artist" under the friend's name in a conversation
  function refreshHeadSub(name) {
    api("/social/listening?u=" + encodeURIComponent(name)).then(function (r) {
      if (!r.ok || S.view !== "thread" || !S.with || S.with.toLowerCase() !== name.toLowerCase()) return;
      var el = head.querySelector(".dm-hsub");
      if (!el) return;
      var k = name.toLowerCase(), on = !!(r.online && r.online[k]), info = listenInfo(r.status && r.status[k]);
      var txt = (on ? "Online" : "Offline") + (info ? " \u00b7 " + (info.live ? "\u266a " + info.main : info.sub) : "");
      el.textContent = txt; el.hidden = false;
    });
  }

  function openThread(name) {
    S.view = "thread"; S.with = name; S.lastId = 0;
    thread.lastTs = 0;
    var u = { name: name, hasAvatar: false };
    var known = S.convos.concat(S.users).filter(function (x) { return x.name.toLowerCase() === name.toLowerCase(); })[0];
    if (known) u = known;
    var av = avatar(u, "sm");
    av.style.cursor = "pointer";
    av.addEventListener("click", function () { openProfile(name, function () { openThread(name); }); });
    headBar(name, { back: showList, avatar: av, sub: true });
    refreshHeadSub(name);
    head.querySelector(".dm-title").style.cursor = "pointer";
    head.querySelector(".dm-title").addEventListener("click", function () { openProfile(name, function () { openThread(name); }); });
    body.textContent = "";
    thread.box = h("div", { class: "dm-msgs" });
    thread.err = h("div", { class: "dm-err", hidden: "" });
    thread.ta = h("textarea", { class: "dm-input", rows: "1", placeholder: "Message " + name, maxlength: "2000" });
    thread.send = h("button", { class: "dm-send", type: "button", text: "Send", onclick: sendMsg });
    thread.ta.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMsg(); }
    });
    thread.ta.addEventListener("input", function () {
      thread.ta.style.height = "auto";
      thread.ta.style.height = Math.min(110, thread.ta.scrollHeight) + "px";
    });
    body.appendChild(thread.box);
    body.appendChild(thread.err);
    body.appendChild(h("div", { class: "dm-compose" }, thread.ta, thread.send));
    pollThread(true);
    setTimeout(function () { thread.ta && thread.ta.focus(); }, 320);
  }

  function pollThread(first) {
    var who = S.with, gen = ++S.pollGen;
    if (!who || S.view !== "thread") return;
    api("/social/messages?with=" + encodeURIComponent(who) + "&after=" + S.lastId).then(function (d) {
      if (gen !== S.pollGen || S.with !== who || S.view !== "thread") return;
      if (d.ok && d.messages.length) {
        var stick = first || nearBottom();
        var incoming = false;
        d.messages.forEach(function (m) {
          addBubble(m); if (!m.mine) incoming = true;
          if (!first && !m.mine && m.vz && m.vz.k === "sent") claimAndPlay(m.id);
        });
        if (stick) thread.box.scrollTop = thread.box.scrollHeight;
        if (incoming) api("/social/read", { "with": who }).then(refreshInbox);
      } else if (first && d.ok) {
        thread.box.appendChild(h("div", { class: "dm-empty", text: "No messages yet. Say hi to " + who + "." }));
        thread.empty = true;
      }
      if (first && d.ok) api("/social/read", { "with": who }).then(refreshInbox);
    });
  }

  function sendMsg() {
    var text = thread.ta.value.trim();
    if (!text || !S.with) return;
    var to = S.with;
    thread.send.disabled = true;
    thread.err.hidden = true;
    api("/social/send", { to: to, text: text }).then(function (d) {
      thread.send.disabled = false;
      if (S.with !== to) return;
      if (!d.ok) { thread.err.textContent = d.error || "Couldn't send"; thread.err.hidden = false; return; }
      var empty = thread.box.querySelector(".dm-empty");
      if (empty) empty.remove();
      thread.ta.value = "";
      thread.ta.style.height = "auto";
      addBubble(d.message);
      thread.box.scrollTop = thread.box.scrollHeight;
      thread.ta.focus();
      refreshInbox();
    });
  }

  /* ---------- open / close / polling ---------- */
  function lc(x) { return String(x || "").toLowerCase(); }
  function openFriendsPanel() { var b = document.getElementById("frBtn"); if (b) b.click(); }
  function snapOf(d) {
    var s = { convos: {}, req: {}, out: {}, friends: {} };
    (d.conversations || []).forEach(function (c) { s.convos[lc(c.name)] = c.last ? c.last.id : 0; });
    (d.requests || []).forEach(function (n) { s.req[lc(n)] = 1; });
    (d.outgoing || []).forEach(function (n) { s.out[lc(n)] = 1; });
    (d.friends || []).forEach(function (n) { s.friends[lc(n)] = 1; });
    return s;
  }
  // compares this inbox with the last one and pops a notification for anything new (nothing on the very first load)
  function notifyChanges(d) {
    var prev = S.snap, cur = snapOf(d);
    S.snap = cur;
    if (!prev) return;
    var refreshFriends = false;

    (d.requests || []).forEach(function (name) {
      if (prev.req[lc(name)]) return;
      refreshFriends = true;
      notify({
        key: "fr:" + lc(name), eyebrow: "Friend request", title: name, sub: "wants to be your friend",
        art: avatar({ name: name }),
        onclick: openFriendsPanel,
        action: { label: "Accept", fn: function () {
          return api("/friends/accept", { username: name }).then(function (r) {
            if (r && r.ok) {
              if (window.__vizFriendsRefresh) window.__vizFriendsRefresh();
              refreshInbox();
              notify({ eyebrow: "Friends", title: "You and " + name + " are friends now", art: avatar({ name: name }), onclick: function () { window.vizahOpenDM(name); } });
            } else {
              notify({ eyebrow: "Friends", title: "Couldn't accept", sub: (r && r.error) || "Try again from the Friends panel", art: avatar({ name: name }), onclick: openFriendsPanel });
            }
          });
        } }
      });
    });

    (d.friends || []).forEach(function (name) {
      if (prev.friends[lc(name)] || !prev.out[lc(name)]) return;   // only people who accepted MY request
      refreshFriends = true;
      notify({ key: "fa:" + lc(name), eyebrow: "Friend request", title: name + " accepted", sub: "You're friends now — say hi",
               art: avatar({ name: name }), onclick: function () { window.vizahOpenDM(name); } });
    });

    (d.conversations || []).forEach(function (c) {
      var l = c.last, k = lc(c.name);
      if (!l || l.mine || l.id <= (prev.convos[k] || 0)) return;
      if (S.open && S.view === "thread" && lc(S.with) === k) return;        // you're reading it right now
      var open = function () { window.vizahOpenDM(c.name); };
      var song = songLine(l.track, l.artist);
      if (l.kind === "sent") return;                                          // auto-plays on its own, with its own toast
      if (l.kind === "ask") {
        notify({
          key: "m:" + l.id, eyebrow: "Vizah request", title: c.name + " wants your Vizah", sub: song,
          art: nArt(l.art), onclick: open,
          action: l.state === "open" ? { label: "Send it", fn: function () {
            return api("/social/vizah/answer", { "with": c.name, id: l.id, action: "send" }).then(function (r) {
              if (r && r.ok) { refreshInbox(); notify({ eyebrow: "Vizah", title: "Sent to " + c.name, sub: song, art: nArt(l.art) }); }
              else notify({ eyebrow: "Vizah", title: (r && r.error) || "Couldn't send it", art: nArt(l.art), onclick: open });
            });
          } } : null
        });
      } else if (l.kind === "declined") {
        notify({ key: "m:" + l.id, eyebrow: "Vizah", title: c.name + " passed on your Vizah", sub: song, art: nArt(l.art), onclick: open });
      } else if (l.kind === "share") {
        notify({
          key: "m:" + l.id, eyebrow: "Vizah", title: c.name + " sent you a song", sub: song, art: nArt(l.art), onclick: open,
          action: l.vid ? { label: "\u25b6 Play", fn: function () {
            playSong({ id: l.vid, track: l.track, artist: l.artist, art: l.art, from: c.name }, false);
          } } : null
        });
      } else {
        notify({
          key: "m:" + l.id, eyebrow: c.unread > 1 ? c.unread + " new messages" : "New message", title: c.name,
          sub: l.text, art: avatar(c), onclick: open
        });
      }
    });

    if (refreshFriends && window.__vizFriendsRefresh) window.__vizFriendsRefresh();   // update the Friends badge + lists right away
  }

  function refreshInbox(cb) {
    api("/social/inbox").then(function (d) {
      if (d._status === 401) { setReady(false); return; }
      if (d.ok) {
        S.convos = d.conversations; setBadge(d.unread);
        (d.vizahs || []).forEach(function (v) { claimAndPlay(v.id); });
        if (!document.hidden) notifyChanges(d);      // while the tab is hidden the snapshot stays put, so you get them when you're back
      }
      if (typeof cb === "function") cb();
    });
  }
  function openPanel() {
    if (!S.ready) return;
    S.open = true;
    panel.classList.add("dm-open");
    launch.classList.add("dm-away");
    if (S.view === "thread" && S.with) openThread(S.with); else showList();
  }
  function closePanel() {
    S.open = false;
    panel.classList.remove("dm-open");
    if (S.ready) launch.classList.remove("dm-away");
    S.pollGen++;
  }
  launch.addEventListener("click", openPanel);
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && S.open) closePanel(); });

  function tick() {
    if (!S.ready || document.hidden) return;
    if (S.open && S.view === "thread" && S.with && ++S.ticks % 6 === 0) refreshHeadSub(S.with);
    if (S.open && S.view === "thread") { pollThread(false); if (++S.vt % 3 === 0) refreshInbox(); }
    else refreshInbox(function () { if (S.open && S.view === "list" && S.tab === "chats") renderChats(body.querySelector(".dm-list")); });
  }
  /* presence: each open tab pings every 20s and says goodbye when it closes, so friends see you go offline at once */
  var TAB = Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  var pingTimer = null;
  function ping() { if (S.ready) api("/social/ping", { tab: TAB }); }
  function bye() {
    try { navigator.sendBeacon("/social/bye", new Blob([JSON.stringify({ tab: TAB })], { type: "application/json" })); } catch (e) {}
  }
  window.addEventListener("pagehide", bye);
  window.addEventListener("pageshow", function (e) { if (e.persisted) ping(); });
  document.addEventListener("visibilitychange", function () { if (!document.hidden) { ping(); if (S.ready) refreshInbox(); } });

  function setReady(on) {
    if (on === S.ready) return;
    S.ready = on;
    if (on) {
      launch.classList.toggle("dm-away", S.open);
      refreshInbox();
      S.timer = setInterval(tick, 3500);
      ping(); pingTimer = setInterval(ping, 20000);
    } else {
      clearInterval(pingTimer); bye();
      clearInterval(S.timer);
      closePanel();
      launch.classList.add("dm-away");
      S.convos = []; S.view = "list"; S.with = null; S.tab = "chats"; S.q = "";
      S.snap = null; nQueue = []; nHide();
      setBadge(0);
    }
  }

  /* add Message / Profile buttons to the rows of your existing Friends panel, without touching its code */
  function decorateFriends() {
    var body = document.getElementById("frBody");
    if (!body) return;
    var inFriends = false;
    Array.prototype.forEach.call(body.children, function (el) {
      if (el.classList.contains("fr-sec")) { inFriends = /^(Friends|Online|Offline)/.test(el.textContent); return; }
      if (!inFriends || !el.classList.contains("fr-row") || el.getAttribute("data-dm")) return;
      var nameEl = el.querySelector(".fr-name"), acts = el.querySelector(".fr-acts");
      if (!nameEl || !acts) return;
      el.setAttribute("data-dm", "1");
      var name = nameEl.textContent;
      var mkBtn = function (label, fn) {
        var b = h("button", { class: "fr-act main", type: "button", text: label });
        b.addEventListener("click", function (e) { e.preventDefault(); e.stopPropagation(); fn(); });
        return b;
      };
      acts.insertBefore(mkBtn("Message", function () { window.vizahOpenDM(name); }), acts.firstChild);
      // tapping the picture or the name opens their profile
      [el.querySelector(".fr-av"), nameEl].forEach(function (t) {
        if (!t) return;
        t.style.cursor = "pointer";
        t.title = "View " + name + "'s profile";
        t.addEventListener("click", function (e) { e.preventDefault(); e.stopPropagation(); window.vizahOpenProfile(name); });
      });
    });
  }
  var frBody = document.getElementById("frBody");
  if (frBody) new MutationObserver(decorateFriends).observe(frBody, { childList: true });
  decorateFriends();

  /* the page marks #appRoot with .pre until you're logged in; follow that */
  function sync() {
    var root = document.getElementById("appRoot");
    setReady(!!root && !root.classList.contains("pre"));
  }
  var root = document.getElementById("appRoot");
  if (root) new MutationObserver(sync).observe(root, { attributes: true, attributeFilter: ["class"] });
  sync();

  window.vizahRenderProfile = function (wrap, name, opts) { renderProfile(wrap, name, opts); };
  window.vizahOpenProfile = function (name) { if (!S.ready) return; openPanel(); openProfile(name); };
  window.vizahOpenDM = function (name) { if (!S.ready) return; openPanel(); openThread(name); };
})();
