# Vizah — nit picks

## 1. Album art in the player when a song starts from inside Vizah
- [x] Add an artwork-hint registry (`vizRememberArt` / `artHintFor`, 30 min TTL, 12 entries)
- [x] Paint the hint immediately if the player is showing the "no art" spinner
- [x] Use the hint in the track-change branch instead of the spinner
- [x] Let real Last.fm artwork upgrade a hint (`state.coverIsHint`)
- [x] Record hints from playlist rows (`play`)
- [x] Record hints from YouTube search (`playIndex`)
- [x] Record hints from YouTube Music search (`playSong`)
- [x] Record hints from the "up next" toast
- [x] Record hints from Vizah shares in `dm.js`

## 2. Spinning "no art" png showing over real covers
- [x] CSS override so `img.viz-fade` / `.viz-img-ready` can never force `#noArt` visible
- [x] `prepImg()` returns early for `.no-art`

## 3. Ship it
- [x] `node --check` all 20 inline scripts + `dm.js`
- [x] CSS brace balance on all 9 style blocks
- [x] Regenerate `install.sh` and verify all 13 embedded files round-trip byte-identical
- [x] Rebuild `vizah-spotify.zip`
- [x] Boot server, `/` 200, `/dm.js` 200, `/spotify/status` 401

## 4. More connections on profiles
- [x] `socials` list stored with the account (max 8, `social.clean_socials` validates; links are built server-side from fixed templates)
- [x] "Connections" editor in Profile settings (platform dropdown + username/link, autosaves via `/save-config` in `bio.js`)
- [x] `/social/profile` returns `socials` with ready-made links
- [x] Profile view in `dm.js` shows them as tappable chips (open in a new tab)
- [x] `/clear-config` keeps socials like bio; `install.sh` regenerated, 13 embedded files round-trip identical

## 5. Dev accounts
- [x] `ensure_dev_accounts()` runs on every start: creates `Umbrxs` and `Vizah` if missing (works even with `VIZAH_SIGNUP=0`), restores a lost password, never touches an existing account
- [x] `VIZAH_DEV_ACCOUNTS=0` turns it off

## 6. Connections tab
- [x] Settings panel split into **Profile** / **Connections** tabs (Spotify return opens Connections)
- [x] Music cards (Last.fm, YouTube, Spotify), Playback and Phone moved into Connections
- [x] 17 social cards in the same style: logo, status dot, Connect / Change / Disconnect, inline field with Save & connect
- [x] One connection per platform; server validates and reads back what it kept
- [x] Logos also shown on the chips of a profile (`window.vizahSocialIcon`)

## 7. Profile tab = preview, Edit button = editor
- [x] Profile tab opens on a live preview of your profile exactly as friends see it (`vizahRenderProfile` in `dm.js`, listening box hidden if sharing is off)
- [x] **Edit profile** opens the old editor (photo, bio, share switch, password, delete); **Done** saves and returns to the preview
- [x] "Edit profile" on your own profile in the DM panel opens the editor directly
- [x] Connections tab untouched except: connected social cards now sort to the top when the tab opens

## 8. Add to playlist (YouTube Music / Spotify)
- [x] `POST /playlist-add` (login + same-origin gated) -> `add_to_playlist()` in `server.py`; the playlist id decides the service (`sp_...` = Spotify, anything else = YouTube Music, `LM` = Liked Music)
- [x] A song that only has a name (the one playing on the phone) is looked up by title + artist on the target service first
- [x] Spotify: `spotify.add_to_playlist()` (new `/items` endpoint with `/tracks` fallback, Liked Songs via `/me/library`), skips songs already in the playlist
- [x] Spotify scopes now include `playlist-modify-*` + `user-library-modify` (existing logins keep working; Reconnect once to enable adding)
- [x] Buttons: main player (left of Previous) and a "+" on every row of the playlist menu. None in the YouTube section (that one is queue-only)
- [x] One shared sheet (`window.vizAddToPlaylist`) with search + toast

## 9. Custom YouTube queue (YouTube section only, not YT Music)
- [x] Queue button + counter next to Search; opens an inline panel under the player
- [x] Paste one or many links (watch, youtu.be, shorts, embed, live, music.youtube.com, bare id); titles via YouTube oEmbed
- [x] Queue button on every search result; reorder, remove, shuffle, repeat, clear; saved in this browser (`vizah.yt.queue`, cleared when the account changes)
- [x] Plays in the same player: next / previous / auto-advance follow the queue; videos that block embedding are skipped
- [x] Search results code only got three one-line hooks (`playIndex`, `step`, `onPlayError`)

## 10. Covers that still did not load in the main player
- [x] When Last.fm has no usable cover (none, a dead URL, or no album in `track.getInfo`) the player asks iTunes' public search and paints that cover (only fills a missing cover / hint, never replaces real art)
- [x] A second Last.fm "blank star" placeholder hash is treated as "no art"


## 11. Motion pass 3 (tweening gaps)
- [x] New additive `<style id="viz-motion3">` block at the end of `index.html` (pure CSS; delete it to restore the old behaviour). No existing rule or script edited
- [x] Settings tab panes, Discover panes, profile preview/editor swap, social inline form and YouTube steps fade + rise + de-blur when they open (were instant)
- [x] Cover art focus-pull (blur to sharp) on every song change, on top of the existing gloss
- [x] Lyrics depth blur: current line sharp, next line soft, previous line blurs out
- [x] Modal / sheet content de-blurs while the card springs up
- [x] Play / pause icon pop (main player + YouTube player)
- [x] Springy profile switch thumb that stretches while pressed
- [x] Blur skipped in lite mode, everything skipped for prefers-reduced-motion
- [x] `install.sh` regenerated, 14 embedded files round-trip identical

## 12. AI chat - House chat (dev accounts only)
- [x] New `chatbot.py` (self-contained, standard library only) + `chatbot.js` (own DOM + CSS); nothing existing was rewritten. Only additions: an `import chatbot` block and one `handle_get` / `handle_post` line each in `server.py`, and one `<script src="chatbot.js">` line in `index.html` (delete those lines to remove the feature)
- [x] Dev accounts only: `Umbrxs`, `Vizah` (+ anything in `VIZAH_CHATBOT_USERS=name1,name2`). Everyone else: no button, no DOM, server answers `allowed: false` / 403
- [x] Chainsaw Man renovation household: world + scenario prompt, 9 character cards (Denji, Power, Aki, Makima, Himeno, Kobeni, Kishibe, Angel Devil, Pochita)
- [x] Tavern-style: group chat with a cast picker, "reply as" selector, continue, regenerate with swipes, edit / delete messages, saved chats, your own persona
- [x] Any OpenAI-compatible endpoint (Ollama, LM Studio, KoboldCpp, OpenRouter, OpenAI); settings per account; key stored in `.vizah_chatbot.json` (mode 600, never served)
- [x] Mature mode: needs an 18+ confirmation in chat settings, then a per-chat switch. Applies to ADULT cards only; minors / unstated ages are SFW-only and the rule is in every prompt (not a setting)
- [x] Tested against a fake model server (all ops, error path, non-dev refused, cross-origin refused, static file 404) and in a headless browser (dev sees the button, normal account sees nothing, existing app and DM button untouched)
- [x] `install.sh` regenerated, 16 embedded files round-trip identical

## 13. House chat scenario fix (manor)
- [x] Scenario corrected: Public Safety HQ is under renovation, so Public Safety rented a manor for Division 4. The manor is their home and base of operations (library = briefing room, master suite = Makima)
- [x] Text only: scenario prompt, 9 character cards + greetings, opening narration, home-screen blurb, chat title defaults, persona placeholder. No logic, no other file touched (`server.py`, `index.html`, `dm.js` byte-identical)
- [x] Existing saved chats keep their history; they pick up the new scenario on the next reply (the prompt is rebuilt each time)
- [x] `install.sh` regenerated, chatbot.py / chatbot.js embeds round-trip identical

## 14. House chat polish
- [x] Dropdown lists readable (dark), toast shown above the chat (top of screen), chat is translucent so the animated background shows (lite mode stays opaque)
- [x] Chat data (API key, model, persona, chats) now stored in `~/.vizah_chatbot.json` like the other `~/.vizah_*` files, so upgrading / replacing the install folder no longer wipes it. An old `.vizah_chatbot.json` in the install folder is migrated on first start; a stale old file never overrides the new one; an unreadable file is kept as `.bad`
- [x] Scrollbar: one thin dark scrollbar (was a double / default bright one), no scroll leaking to the page behind
- [x] New exchanges are easy to spot: a time divider before each of your messages, the newest reply has a LATEST tag + accent bar, and a long new reply opens at its beginning instead of its end
- [x] `install.sh` regenerated, chatbot.py / chatbot.js embeds round-trip identical

## 9. AI chat: icons, text, Continue
- [x] Header / composer icons are inline SVG (the `⏵` glyph showed as an empty box on some phones)
- [x] Placeholder shortened to "Say or do something…" and no longer wraps; composer a little tighter on phones
- [x] A reply cut off inside `*an action*` now shows italic instead of a stray `*`
- [x] **Continue** button on the latest reply (highlighted when it looks cut off) -> new `extend` op appends to that same message; composer `next` button unchanged (`continue` = new beat)
- [x] `install.sh` regenerated, all embedded files round-trip identical
