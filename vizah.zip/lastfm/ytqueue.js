/* Vizah YT Music queue (added). Self-contained: builds its own DOM + CSS and only talks to the endpoints the page already
   uses (/ytm/search, /ytm/play-song/<id>). Nothing here changes existing code: if this file is missing, the page works as before.
   - a small menu button under the DM button opens the queue menu
   - "Add to playlist" gets a "Start a queue on YT Music" / "Add to YT Music queue" option (window.vizYtQueue.sheetOption)
   - while a queue is running, the next song is started on the phone when the current one ends */
(function () {
  "use strict";
  if (window.vizYtQueue) return;

  var KEY = "vizah.ytmq";
  var Q = { items: [], idx: -1, active: false, loop: false };
  var curDesc = "", lastStartAt = 0, lastLeft = Infinity, advancing = false, busy = false, sheet = null;

  /* ---------- tiny helpers ---------- */
  function mk(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
  function norm(x) { return String(x || "").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ""); }
  function toast(t) { try { if (window.vizToast) window.vizToast(t); } catch (e) {} }
  function ico(path) { var s = mk("span", "yq-ico"); s.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + path + "</svg>"; return s; }
  var P = {
    queue: '<path d="M3 6h12"/><path d="M3 12h9"/><path d="M3 18h7"/><path d="M16 14l5 3-5 3z" fill="currentColor"/>',
    up: '<path d="M6 15l6-6 6 6"/>', down: '<path d="M6 9l6 6 6-6"/>', x: '<path d="M6 6l12 12"/><path d="M18 6L6 18"/>',
    play: '<path d="M8 5v14l11-7z" fill="currentColor"/>', plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
    shuffle: '<path d="M16 3h5v5"/><path d="M4 20L21 3"/><path d="M21 16v5h-5"/><path d="M15 15l6 6"/><path d="M4 4l5 5"/>',
    loop: '<path d="M17 2l4 4-4 4"/><path d="M3 11V9a3 3 0 0 1 3-3h15"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v2a3 3 0 0 1-3 3H3"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/>'
  };
  function art(u) { return (u && typeof window.vizArt === "function") ? window.vizArt(u) : u; }

  /* ---------- storage (the running state is never restored after a reload) ---------- */
  function save() { try { localStorage.setItem(KEY, JSON.stringify({ items: Q.items.map(function (i) { return { id: i.id || "", title: i.title, artist: i.artist || "", thumb: i.thumb || "" }; }), idx: Q.idx, loop: Q.loop })); } catch (e) {} }
  (function load() {
    try {
      var o = JSON.parse(localStorage.getItem(KEY) || "{}");
      if (Array.isArray(o.items)) Q.items = o.items.filter(function (i) { return i && i.title; }).slice(0, 200);
      Q.idx = Math.min(Math.max(-1, +o.idx || -1), Q.items.length - 1);
      Q.loop = !!o.loop;
    } catch (e) {}
  })();

  /* ---------- css ---------- */
  var css = [
    ".yq-launch{position:fixed;right:0;bottom:142px;z-index:45;display:flex;align-items:center;justify-content:center;width:54px;height:46px;border:1px solid var(--glass-border,rgba(255,255,255,.12));border-right:0;border-radius:16px 0 0 16px;background:rgba(16,12,18,.72);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);color:var(--text,#f8f9ff);cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.35);transition:transform .25s ease,opacity .25s ease,background .2s ease}",
    ".yq-launch:hover{transform:translateX(-3px);background:rgba(34,26,40,.85)}",
    ".yq-launch.yq-away{transform:translateX(110%);pointer-events:none;opacity:0}",
    ".yq-launch.yq-fade{pointer-events:none;opacity:0}",
    ".yq-launch .yq-ico svg{width:24px;height:24px;display:block}",
    ".yq-launch.on{border-color:var(--accent3,#79e7ff)}",
    ".yq-launch.on .yq-ico{color:var(--accent3,#79e7ff)}",
    ".yq-badge{position:absolute;top:-7px;left:-7px;min-width:20px;height:20px;padding:0 5px;border-radius:10px;display:grid;place-items:center;font:800 .68rem var(--small-font,system-ui,sans-serif);background:var(--accent3,#79e7ff);color:#10161c;box-shadow:0 2px 8px rgba(0,0,0,.4)}",
    ".yq-badge[hidden]{display:none}",
    ".yq-ico{display:inline-grid;place-items:center}",
    ".yq-ico svg{width:17px;height:17px;display:block}",
    ".yq-opt{display:flex;align-items:center;gap:12px;width:100%;box-sizing:border-box;padding:11px 14px;border:1px solid rgba(121,231,255,.35);border-radius:16px;background:linear-gradient(135deg,rgba(121,231,255,.14),rgba(255,122,89,.10));color:var(--text,#f8f9ff);cursor:pointer;text-align:left;font:inherit;transition:transform .15s ease,background .2s ease}",
    ".yq-opt:hover{background:linear-gradient(135deg,rgba(121,231,255,.22),rgba(255,122,89,.16))}",
    ".yq-opt:active{transform:scale(.985)}",
    ".yq-opt .yq-ob{flex:none;width:36px;height:36px;border-radius:50%;display:grid;place-items:center;background:var(--accent3,#79e7ff);color:#10161c}",
    ".yq-opt .yq-ob svg{width:19px;height:19px}",
    ".yq-opt b{display:block;font-size:.9rem;font-weight:700}",
    ".yq-opt small{display:block;margin-top:2px;font:.74rem var(--small-font,system-ui,sans-serif);color:var(--muted,rgba(248,249,255,.65))}",
    ".yq-ctrls{display:flex;gap:8px;flex-wrap:wrap;align-items:center}",
    ".yq-chip{display:inline-flex;align-items:center;gap:6px;height:38px;padding:0 14px;border:1px solid rgba(255,255,255,.12);border-radius:999px;background:rgba(255,255,255,.06);color:var(--text,#f8f9ff);cursor:pointer;font:700 .78rem var(--small-font,system-ui,sans-serif);transition:background .15s ease,border-color .15s ease}",
    ".yq-chip:hover{background:rgba(255,255,255,.13)}",
    ".yq-chip.main{background:linear-gradient(90deg,var(--accent3,#79e7ff),var(--accent1,#ff7a59));color:#10161c;border-color:transparent}",
    ".yq-chip.on{border-color:var(--accent3,#79e7ff);color:var(--accent3,#79e7ff)}",
    ".yq-chip[disabled]{opacity:.35;pointer-events:none}",
    ".yq-add{display:flex;gap:8px}",
    ".yq-add input{flex:1;min-width:0;box-sizing:border-box;height:40px;padding:0 14px;border:1px solid rgba(255,255,255,.12);border-radius:999px;background:rgba(255,255,255,.05);color:var(--text,#f8f9ff);outline:none;font:16px var(--small-font,system-ui,sans-serif)}",
    ".yq-add input:focus{border-color:var(--accent3,#79e7ff)}",
    ".yq-sec{margin:4px 2px 0;font:700 .7rem var(--small-font,system-ui,sans-serif);letter-spacing:.07em;text-transform:uppercase;color:var(--muted,rgba(248,249,255,.6))}",
    ".yq-list{display:flex;flex-direction:column;min-height:0;overflow-y:auto;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.22) transparent}",
    ".yq-item{display:flex;align-items:center;gap:10px;padding:7px 6px;border-radius:14px;cursor:pointer;transition:background .15s ease}",
    ".yq-item:hover{background:rgba(255,255,255,.06)}",
    ".yq-item.cur{background:linear-gradient(90deg,rgba(121,231,255,.16),rgba(255,255,255,.03))}",
    ".yq-item.bad{opacity:.4}",
    ".yq-item .pm-art{width:42px;height:42px;flex:none}",
    ".yq-btns{flex:none;display:flex;align-items:center;gap:2px}",
    ".yq-ib{width:30px;height:30px;border:0;border-radius:50%;display:grid;place-items:center;background:none;color:var(--muted,rgba(248,249,255,.65));cursor:pointer}",
    ".yq-ib:hover,.yq-ib:focus-visible{background:rgba(255,255,255,.12);color:var(--text,#f8f9ff);outline:none}",
    ".yq-ib[disabled]{opacity:.25;pointer-events:none}",
    ".yq-ib svg{width:15px;height:15px}",
    ".yq-add-r{flex:none;color:var(--accent3,#79e7ff)}",
    ".yq-empty{margin:0;padding:18px 6px;text-align:center;color:var(--muted,rgba(248,249,255,.65));font:.84rem/1.5 var(--small-font,system-ui,sans-serif)}",
    ".yq-msg{margin:0;min-height:1.2em;font:.8rem var(--small-font,system-ui,sans-serif);color:var(--muted,rgba(248,249,255,.65))}",
    ".yq-msg.ok{color:#7be0a0}.yq-msg.err{color:#ff9a8a}",
    "@media(prefers-reduced-motion:reduce){.yq-launch,.yq-opt{transition:none}}"
  ].join("\n");
  var st = mk("style"); st.id = "yq-css"; st.textContent = css; document.head.appendChild(st);

  /* ---------- queue logic ---------- */
  function keyOf(s) { return s.id ? "id:" + s.id : "t:" + norm(s.title) + "|" + norm(s.artist); }
  function find(s) { var k = keyOf(s); for (var i = 0; i < Q.items.length; i++) if (keyOf(Q.items[i]) === k) return i; return -1; }
  function matches(desc, it) {
    if (!it) return false;
    var d = norm(desc), t = norm(it.title);
    if (!d || !t) return false;
    return d.indexOf(t) >= 0 || t.indexOf(d) >= 0 || (t.length >= 4 && d.indexOf(t.slice(0, 12)) >= 0);
  }
  function pollSoon() { [700, 1800].forEach(function (ms) { setTimeout(function () { try { if (window.__vizPollMedia) window.__vizPollMedia(); } catch (e) {} }, ms); }); }

  function add(song) {
    var s = { id: song.id || "", title: String(song.title || "").trim(), artist: String(song.artist || "").trim(), thumb: song.thumb || "" };
    if (!s.title) return -1;
    var i = find(s);
    if (i >= 0) return i;
    if (Q.items.length >= 200) { toast("The queue is full (200 songs)"); return -1; }
    Q.items.push(s); save(); paint();
    return Q.items.length - 1;
  }

  function resolveId(it) {
    if (it.id) return Promise.resolve(it.id);
    var q = (it.title + " " + it.artist).trim().slice(0, 100);
    return fetch("/ytm/search?q=" + encodeURIComponent(q), { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (d) {
      if (d && d.ok && d.results && d.results.length) { it.id = d.results[0].id; if (!it.thumb) it.thumb = d.results[0].thumb || ""; save(); return it.id; }
      throw new Error(d && d.ok ? "couldn't find it on YouTube Music" : ((d && d.error) || "search failed"));
    });
  }

  /* start song i on the phone; if it fails, mark it and move on (a few tries) */
  function playIdx(i, tries) {
    tries = tries || 0;
    if (i < 0 || i >= Q.items.length) return Promise.resolve(false);
    var it = Q.items[i];
    busy = true; paint();
    return resolveId(it).then(function (id) {
      return fetch("/ytm/play-song/" + encodeURIComponent(id), { method: "POST" }).then(function (r) { return r.json(); });
    }).then(function (d) {
      if (!d || !d.ok) throw new Error((d && d.error) || "couldn't start it");
      it.bad = false; Q.idx = i; Q.active = true; lastStartAt = Date.now(); lastLeft = Infinity; advancing = false;
      if (window.vizRememberArt && it.thumb) { try { window.vizRememberArt(it.title, it.artist, it.thumb); } catch (e) {} }
      busy = false; save(); paint(); pollSoon();
      return true;
    }).catch(function (e) {
      it.bad = true; busy = false; advancing = false; paint();
      var n = nextIdx(i, 1);
      if (n >= 0 && tries < 3) { toast("Skipped \u201c" + it.title + "\u201d: " + e.message); return playIdx(n, tries + 1); }
      Q.active = false; paint(); toast("Queue stopped: " + e.message);
      return false;
    });
  }
  function nextIdx(from, dir) {
    var n = Q.items.length;
    for (var k = 1; k <= n; k++) {
      var j = from + dir * k;
      if (j < 0 || j >= n) { if (!Q.loop) return -1; j = ((j % n) + n) % n; }
      if (!Q.items[j].bad) return j;
    }
    return -1;
  }
  function step(dir) {
    if (!Q.items.length) return;
    var n = nextIdx(Q.idx, dir);
    if (n < 0) { finish(); return; }
    playIdx(n);
  }
  function finish() { Q.active = false; advancing = false; paint(); toast("Queue finished"); }
  function stop() { Q.active = false; advancing = false; paint(); toast("Queue stopped"); }

  /* "Start a queue" from a song: a new queue that begins with it. A song without an id is the one already playing, so it isn't restarted. */
  function startWith(song, playing) {
    var s = { id: song.id || "", title: String(song.title || "").trim(), artist: String(song.artist || "").trim(), thumb: song.thumb || "" };
    if (!s.title) return;
    Q.items = [s]; Q.idx = 0; save();
    if (playing) { Q.active = true; lastStartAt = Date.now(); lastLeft = Infinity; advancing = false; paint(); }
    else playIdx(0);
  }

  /* ---------- watching the phone ---------- */
  window.addEventListener("viz:media", function (e) {
    var d = (e && e.detail) || {}, desc = d.connected ? String(d.desc || "") : "";
    if (!desc || desc === curDesc) return;
    var prev = curDesc; curDesc = desc;
    if (!Q.active || advancing || busy || !prev) { paint(); return; }
    if (matches(desc, Q.items[Q.idx])) { paint(); return; }
    if (Date.now() - lastStartAt < 8000) return;                 // our own start is still settling
    if (lastLeft < 12000) { advancing = true; step(1); }         // the song ended and YT Music moved on by itself: take over
    else { Q.active = false; paint(); toast("Queue paused: you changed the song"); }
  });
  setInterval(function () {
    if (!Q.active || busy) return;
    try {
      if (typeof state === "undefined" || !state.isPlaying || !(state.durationMs > 0)) return;
      var left = state.durationMs - (Date.now() - state.startedAt);
      lastLeft = left;
      if (advancing || Date.now() - lastStartAt < 10000) return;
      if (left <= 1500 && matches(curDesc, Q.items[Q.idx])) { advancing = true; step(1); }
    } catch (e) {}
  }, 1000);

  /* while a queue runs, the player's own skip buttons move through the queue */
  document.addEventListener("click", function (e) {
    var b = e.target && e.target.closest && e.target.closest("#nextBtn,#prevBtn");
    if (!b || !Q.active || !Q.items.length) return;
    e.stopImmediatePropagation(); e.preventDefault();
    if (busy) return;
    step(b.id === "nextBtn" ? 1 : -1);
  }, true);

  /* ---------- launcher (under the DM button) ---------- */
  var launch = mk("button", "yq-launch yq-away"); launch.type = "button";
  launch.setAttribute("aria-label", "Open the YT Music queue"); launch.title = "YT Music queue";
  /* fade away once the YouTube section scrolls into view */
  (function () {
    var yt = null, tick = 0;
    function check() {
      tick = 0; yt = yt || document.getElementById("youtube");
      if (yt) launch.classList.toggle("yq-fade", yt.getBoundingClientRect().top < window.innerHeight * 0.6);
    }
    function queue() { if (!tick) tick = requestAnimationFrame(check); }
    document.addEventListener("scroll", queue, true);
    window.addEventListener("resize", queue);
    queue();
  })();
  launch.appendChild(ico(P.queue));
  var badge = mk("span", "yq-badge"); badge.hidden = true; launch.appendChild(badge);
  document.body.appendChild(launch);
  launch.addEventListener("click", openSheet);

  var ready = false;
  function syncReady() {
    var root = document.getElementById("appRoot");
    ready = !!root && !root.classList.contains("pre");
    launch.classList.toggle("yq-away", !ready);
    if (!ready && sheet) closeSheet();
  }
  var rootEl = document.getElementById("appRoot");
  if (rootEl) new MutationObserver(syncReady).observe(rootEl, { attributes: true, attributeFilter: ["class"] });
  syncReady();

  /* ---------- the queue menu ---------- */
  var listEl = null, subEl = null, ctrlEl = null, msgEl = null;
  function closeSheet() {
    var m = sheet; sheet = null; listEl = subEl = ctrlEl = msgEl = null;
    document.removeEventListener("keydown", onKey);
    if (!m) return;
    m.classList.add("closing"); setTimeout(function () { m.remove(); }, 230);
  }
  function onKey(e) { if (e.key === "Escape") closeSheet(); }
  function say(t, kind) { if (msgEl) { msgEl.textContent = t || ""; msgEl.className = "yq-msg" + (kind ? " " + kind : ""); } }

  function openSheet() {
    if (sheet) return;
    var backdrop = mk("div", "pm-backdrop"), box = mk("div", "pm-sheet");
    box.setAttribute("role", "dialog"); box.setAttribute("aria-modal", "true"); box.setAttribute("aria-label", "YT Music queue");
    var head = mk("div", "pm-head"), x = mk("button", "pm-x", "\u00d7"); x.type = "button"; x.setAttribute("aria-label", "Close");
    var ttl = mk("div", "pm-title", "YT Music queue"); subEl = mk("small", "", ""); subEl.style.cssText = "margin-left:8px;font-weight:600;opacity:.65"; ttl.appendChild(subEl);
    head.append(ttl, x);
    ctrlEl = mk("div", "yq-ctrls");
    msgEl = mk("p", "yq-msg"); msgEl.setAttribute("aria-live", "polite");

    /* search + add */
    var addRow = mk("div", "yq-add"), inp = mk("input"); inp.type = "text"; inp.placeholder = "Search a song to add"; inp.autocomplete = "off"; inp.spellcheck = false;
    var addNow = mk("button", "yq-chip", "+ Playing now"); addNow.type = "button"; addNow.title = "Add the song that is playing right now";
    addRow.append(inp, addNow);
    var results = mk("div", "yq-list"); results.style.maxHeight = "200px"; results.hidden = true;
    listEl = mk("div", "yq-list"); listEl.style.flex = "1";

    box.append(head, ctrlEl, msgEl, addRow, results, mk("div", "yq-sec", "Up next"), listEl);
    backdrop.appendChild(box); document.body.appendChild(backdrop); sheet = backdrop;
    document.addEventListener("keydown", onKey);
    backdrop.addEventListener("click", function (e) { if (e.target === backdrop) closeSheet(); });
    x.addEventListener("click", closeSheet);

    addNow.addEventListener("click", function () {
      var g = function (id) { var n = document.getElementById(id); return n ? n.textContent.trim() : ""; };
      var title = g("trackTitle"), artist = g("artistName");
      if (!title || /^(Loading\.\.\.|Unknown Song)$/i.test(title)) { say("Play a song first.", "err"); return; }
      var img = document.getElementById("coverArt");
      var i = add({ title: title, artist: /^(Waiting for your music\.\.\.|Unknown Artist)$/i.test(artist) ? "" : artist, thumb: img && img.style.display !== "none" ? (img.getAttribute("src") || "") : "" });
      if (i >= 0) say("Added \u201c" + title + "\u201d.", "ok");
    });

    var seq = 0, timer = 0;
    inp.addEventListener("input", function () {
      clearTimeout(timer);
      var q = inp.value.trim();
      if (q.length < 2) { seq++; results.hidden = true; results.textContent = ""; return; }
      timer = setTimeout(function () {
        var my = ++seq; results.hidden = false; results.textContent = ""; results.appendChild(mk("p", "yq-empty", "Searching..."));
        fetch("/ytm/search?q=" + encodeURIComponent(q), { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (d) {
          if (my !== seq) return;
          results.textContent = "";
          if (!d || !d.ok) { results.appendChild(mk("p", "yq-empty", (d && d.error) || "Search isn't available right now.")); return; }
          if (!(d.results || []).length) { results.appendChild(mk("p", "yq-empty", "No songs found.")); return; }
          d.results.slice(0, 8).forEach(function (r) {
            var row = mk("div", "yq-item"), th = r.thumb ? mk("img", "pm-art") : mk("div", "pm-art");
            if (r.thumb) { th.alt = ""; th.referrerPolicy = "no-referrer"; th.src = art(r.thumb); }
            var t = mk("div", "pm-text"); t.append(mk("div", "pm-song", r.title), mk("div", "pm-by", r.artist || ""));
            var plus = mk("span", "yq-add-r"); plus.appendChild(ico(P.plus));
            row.append(th, t, plus);
            row.addEventListener("click", function () { if (add({ id: r.id, title: r.title, artist: r.artist, thumb: r.thumb }) >= 0) { say("Added \u201c" + r.title + "\u201d.", "ok"); } });
            results.appendChild(row);
          });
        }).catch(function () { if (my === seq) { results.textContent = ""; results.appendChild(mk("p", "yq-empty", "Couldn't reach the server.")); } });
      }, 350);
    });
    paint();
  }

  function chip(label, icon, cls, fn, disabled) {
    var b = mk("button", "yq-chip" + (cls ? " " + cls : "")); b.type = "button"; if (icon) b.appendChild(ico(icon)); b.appendChild(document.createTextNode(label)); if (disabled) b.disabled = true;
    b.addEventListener("click", fn); return b;
  }
  function ib(label, icon, fn, disabled) {
    var b = mk("button", "yq-ib"); b.type = "button"; b.title = label; b.setAttribute("aria-label", label); b.appendChild(ico(icon)); if (disabled) b.disabled = true;
    b.addEventListener("click", function (e) { e.stopPropagation(); fn(); }); return b;
  }
  function removeAt(i) {
    Q.items.splice(i, 1);
    if (i < Q.idx) Q.idx--; else if (i === Q.idx) { if (Q.active) { Q.active = false; toast("Queue stopped: removed the current song"); } Q.idx = Math.min(Q.idx, Q.items.length - 1); }
    save(); paint();
  }
  function moveAt(i, d) {
    var j = i + d; if (j < 0 || j >= Q.items.length) return;
    var t = Q.items[i]; Q.items[i] = Q.items[j]; Q.items[j] = t;
    if (Q.idx === i) Q.idx = j; else if (Q.idx === j) Q.idx = i;
    save(); paint();
  }
  function shuffle() {
    var from = Q.idx + 1, tail = Q.items.slice(from);
    for (var i = tail.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = tail[i]; tail[i] = tail[j]; tail[j] = t; }
    Q.items = Q.items.slice(0, from).concat(tail); save(); paint();
  }

  function paint() {
    var n = Q.items.length;
    badge.hidden = !n; badge.textContent = String(n);
    launch.classList.toggle("on", Q.active);
    try { window.dispatchEvent(new Event("viz:queue")); } catch (e) {}
    if (!sheet || !listEl) return;
    subEl.textContent = n ? n + (n === 1 ? " song" : " songs") + (Q.active ? " \u00b7 playing" : "") : "";
    ctrlEl.textContent = "";
    if (Q.active) ctrlEl.appendChild(chip("Stop queue", P.stop, "main", stop));
    else ctrlEl.appendChild(chip("Start queue", P.play, "main", function () { playIdx(Q.idx >= 0 && Q.idx < n ? Q.idx : 0); }, !n || busy));
    ctrlEl.appendChild(chip("Shuffle", P.shuffle, "", shuffle, n < 3));
    ctrlEl.appendChild(chip("Loop", P.loop, Q.loop ? "on" : "", function () { Q.loop = !Q.loop; save(); paint(); }));
    ctrlEl.appendChild(chip("Clear", P.x, "", function () { Q.items = []; Q.idx = -1; Q.active = false; save(); paint(); }, !n));
    listEl.textContent = "";
    if (!n) { listEl.appendChild(mk("p", "yq-empty", "Nothing queued yet. Search above, tap \u201c+ Playing now\u201d, or use the add-to-playlist button on the player to start a queue.")); return; }
    Q.items.forEach(function (it, i) {
      var cur = i === Q.idx;
      var row = mk("div", "yq-item" + (cur ? " cur" : "") + (it.bad ? " bad" : ""));
      var th = it.thumb ? mk("img", "pm-art") : mk("div", "pm-art");
      if (it.thumb) { th.alt = ""; th.loading = "lazy"; th.referrerPolicy = "no-referrer"; th.src = art(it.thumb); }
      var t = mk("div", "pm-text");
      t.append(mk("div", "pm-song", (cur && Q.active ? "\u25b6 " : "") + it.title), mk("div", "pm-by", (it.artist || "") + (it.bad ? " \u00b7 not found" : "")));
      var btns = mk("div", "yq-btns");
      btns.append(ib("Move up", P.up, function () { moveAt(i, -1); }, i === 0), ib("Move down", P.down, function () { moveAt(i, 1); }, i === n - 1), ib("Remove", P.x, function () { removeAt(i); }));
      row.append(th, t, btns);
      row.addEventListener("click", function () { if (!busy) playIdx(i); });
      listEl.appendChild(row);
    });
  }

  /* ---------- the option inside "Add to playlist" ---------- */
  function sheetOption(song, close) {
    var running = Q.active;
    var b = mk("button", "yq-opt"); b.type = "button";
    var ob = mk("span", "yq-ob"); ob.appendChild(ico(running ? P.plus : P.queue));
    var tx = mk("span", "");
    tx.append(mk("b", "", running ? "Add to YT Music queue" : "Start a queue on YT Music"),
              mk("small", "", running ? Q.items.length + (Q.items.length === 1 ? " song" : " songs") + " in the queue now" : "Plays songs on your phone one after another"));
    b.append(ob, tx);
    b.addEventListener("click", function () {
      var playing = !song.id;      // from the player's own button: this song is already playing
      if (Q.active) { if (add(song) >= 0) toast("Added to the YT Music queue"); else toast("Already in the queue"); }
      else { startWith(song, playing); toast(playing ? "Queue started with this song" : "Starting your queue\u2026"); }
      if (close) close();
    });
    return b;
  }

  window.vizYtQueue = { next: function () { if (!Q.active || Q.idx < 0) return null; var j = nextIdx(Q.idx, 1); return j >= 0 && j !== Q.idx ? Q.items[j] : null; }, add: add, open: openSheet, sheetOption: sheetOption, state: function () { return { items: Q.items.slice(), idx: Q.idx, active: Q.active }; } };
  paint();
})();
