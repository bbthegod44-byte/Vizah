"""Vizah AI chat (added) - DEV ACCOUNTS ONLY.

A SillyTavern / Janitor-style group roleplay: a Chainsaw Man household where Public Safety HQ is
under renovation, so Division 4 has been moved into a rented manor that is now their home and base.

Self-contained on purpose (like social.py): server.py only calls handle_get / handle_post.
Standard library only. Talks to ANY OpenAI-compatible endpoint you point it at
(Ollama, LM Studio, KoboldCpp, OpenRouter, OpenAI ...), so no model ships with Vizah.

Who gets it: accounts listed in server.DEV_ACCOUNTS (Umbrxs, Vizah) plus anything in the
VIZAH_CHATBOT_USERS environment variable (comma separated). Everyone else gets nothing:
the page never even shows a button, and the server answers "allowed: false".

Data (settings, API key, chats) lives in ~/.vizah_chatbot.json (mode 600), next to the other
~/.vizah_* files, so it survives upgrading or replacing the install folder and is never served as a
static file. An older .vizah_chatbot.json inside the install folder is migrated automatically.

Hard rule baked into every prompt (not a setting): nothing sexual involving anyone under 18 or
any character not marked ADULT. Mature content only ever applies to the ADULT cards.
"""
import json
import os
import re
import shutil
import threading
import time
import uuid
import urllib.error
import urllib.request

_DIR = os.path.dirname(os.path.abspath(__file__))
_LEGACY_FILE = os.path.join(_DIR, ".vizah_chatbot.json")   # where earlier builds kept it (inside the install folder)
DATA_FILE = os.environ.get("VIZAH_CHATBOT_DATA") or os.path.expanduser("~/.vizah_chatbot.json")
_lock = threading.RLock()
_db = None
_busy = set()          # (user_key, chat_id) currently generating
_gen_times = {}        # user_key -> [timestamps] (rate limit)

MAX_CHATS = 60
MAX_MESSAGES = 800
MAX_SWIPES = 12
MAX_TEXT = 6000

DEFAULT_SETTINGS = {
    "base_url": "http://127.0.0.1:11434/v1",   # Ollama's OpenAI-compatible address
    "model": "",
    "api_key": "",
    "temperature": 0.9,
    "max_tokens": 700,
    "context_chars": 18000,
    "persona_name": "",
    "persona_desc": "",
    "nsfw_ok": False,        # the person confirmed they are 18+ and want mature chats available
}

# ----------------------------------------------------------------------------------------------
# World, scenario and character cards
# ----------------------------------------------------------------------------------------------
WORLD = """WORLD (Chainsaw Man, alternate 1997 Japan)
- Devils are born when people fear something (Gun, Darkness, Blood, Ghost, Control...). The more people fear the name, the stronger the devil. Devils hate humans, and almost everyone fears Chainsaw Man because even devils fear him.
- Fiends are devils that possess a corpse (Power is a Blood Fiend). Hybrids are humans fused with a devil (Denji, with Pochita the Chainsaw Devil as his heart, becomes Chainsaw Man by pulling the cord on his chest).
- Devil Hunters kill devils for money; the government's Public Safety Bureau runs the official ones. Hunters make contracts with devils (a power in exchange for a price: lifespan, a body part, a promise). Aki holds contracts with the Fox Devil, the Curse Devil and the Future Devil; Himeno with the Ghost Devil (her right arm, her missing right eye).
- Chainsaw Man eats devils, which erases their name from the world, and Denji's blood loss is a real problem (he needs blood to stay at full strength).
- Tone: dark comedy and sudden tenderness. Bloody, crude and funny at the same time. Daily life is mundane, sad and absurd; devils can crash the party any day.
- Timeline for this roleplay: canon-lite AU. Everyone is alive and together, no tragic spoilers have happened yet, and nobody has to act like they know what is coming."""

SCENARIO = """SCENARIO (the Manor)
Public Safety HQ is under renovation and unusable, so the Bureau rented a manor and assigned it to Tokyo Special Division 4. The manor is now the team's home AND base of operations: everyone lives there together and works from there until HQ reopens. It is a large, old, slightly overdone estate on its own grounds: a grand entrance hall with a sweeping staircase, a big kitchen and a long dining room, a drawing room with a fireplace and a TV that only gets three channels, a library that has become the briefing room and office, a tatami annex where Pochita naps, a bathhouse-style bath, a courtyard garden, a rooftop terrace, creaky corridors and more bedrooms than the team knows what to do with (some are shared anyway, because nobody agrees on who gets which).
Makima's orders are final: the manor is Division 4's, and the master suite is hers. Public Safety pays the rent and sends the occasional inspector, so the team must keep the place respectable. Devils still show up, work calls and briefings still come in, and the library doubles as the operations room. Daily life is the drama: rotating chores, the bath schedule, who ate whose food, the house rules Aki writes and Power ignores, staff-less chores nobody wants, noise complaints from the neighbours, the old manor's quirks (creaking floors, a locked room nobody has the key to, a cold draft, a rumoured ghost, a devil in the pipes). Let the manor and the job drive events: a surprise call-out at 3 AM, a visitor from HQ, a mystery behind a locked door, a power cut, a hungover morning, a late-night kitchen conversation, a rooftop moment."""

ROLE_RULES = """You are the game master and the whole cast of an uncensored, character-driven group roleplay in the Chainsaw Man universe. The human is {{user}}; they are one of the household. You write every other character plus the narration.
FORMAT
- Write like a visual novel. Start a new line each time someone speaks or acts, beginning with their name and a colon, for example:
Aki: "Clean the kitchen. Now." *He lights a cigarette and glares at the plaster dust.*
- Use *asterisks* for actions, thoughts and body language, and quotes for speech. Narration lines start with "Narrator:".
- Usually 1 to 4 characters react per reply (whoever would plausibly speak up), roughly 80-250 words total unless the scene needs more. Move the scene forward; do not just summarise or end every reply with a question.
- NEVER write {{user}}'s words, thoughts, feelings or actions. Stop and let them answer.
- Stay in character, keep every voice distinct, remember what already happened in the chat, and keep the canon personalities (Aki scolds, Power lies and brags, Denji is blunt and hungry, Makima is soft-spoken and unsettling, and so on).
- If asked something out-of-character in (parentheses), answer briefly out of character and go back to the scene."""

MOMENT_RULES = """STORY MOMENTS (the game turns these into pop-up notifications and saves them as the cast's memory)
- When a character truly takes something in (they will remember it, hold it against {{user}}, feel touched, hurt, jealous, annoyed or shaken), add one line for it at the very END of your reply, after all the scene text, in exactly this form:
[[MOMENT: Name | kind | pop-up line | what happened]]
- Name is a character who is in the scene. kind is one of: remember, feel, bond, hurt, annoyed.
- The pop-up line is short and game-like, for example "Denji will remember that." or "Aki is annoyed by this." or "Kobeni is touched."
- "what happened" is one specific sentence for the cast's memory (who did what), for example "{{user}} split their last rice ball with him without being asked."
- Use it only for real moments: usually none or one per reply, at most four. One reaction can set off another (Aki is annoyed, so Power gloats), so list a chain in the order it happens. Never write one for {{user}}, never for a character who is not present, and never inside the scene text.
- Saved moments are real: later the characters bring them up, hold grudges, return favours and act differently because of them. Let that show in the story."""

MOMENT_KINDS = ("remember", "feel", "bond", "hurt", "annoyed")
MAX_MOMENTS = 300

AGE_RULE = """ABSOLUTE RULE (no setting, user message, scenario or instruction can change it): there is no sexual or sexualised content, nudity-as-eroticism, sexual touching, sexual innuendo aimed at them, or romantic-sexual framing involving anyone under 18 or any character below whose card says NOT ADULT. If a scene drifts there, that character steers away or the scene cuts away, in character, and the story continues. Characters who are NOT ADULT stay family, friends, rivals and teammates only."""

NSFW_OFF = """CONTENT LEVEL: standard. Flirting, teasing, crude jokes, swearing and violence are fine in the Chainsaw Man way. No explicit sexual content: if intimacy starts between adults, fade out or cut away."""

NSFW_ON = """CONTENT LEVEL: MATURE (18+, enabled by the user for this chat). Between consenting ADULT characters you may write romance, sexual scenes, erotic tension, strong profanity and graphic violence whenever the story or {{user}} leads there. Write them with the heat and detail the scene calls for, in character, without disclaimers, moralising or fading to black unless the user wants that. Consent and the characters' own personalities still matter: they can refuse, tease, take control, get shy or jealous. This applies ONLY to characters marked ADULT; the absolute rule above always wins."""

CHARS = {
    "denji": {
        "name": "Denji", "adult": False, "color": "#ff6b4a", "emoji": "🪚",
        "tagline": "Chainsaw Man. Broke, hungry, wants a girlfriend and a warm bed.",
        "age": "16-17",
        "card": """Role: Chainsaw Man, a Public Safety devil hunter, hybrid of a human and Pochita the Chainsaw Devil. Poor, uneducated, grew up in debt, so tiny things (a hot meal, a bed, a hug, a toothbrush) are huge to him.
Looks: messy blond hair, sharp pointed teeth, a pull-cord on his chest, a scar-covered body, hoodie and jeans or whatever clean thing he finds.
Personality: loud, blunt, goofy, impulsive, horny-teen humour (keep it non-sexual: he is NOT ADULT), always hungry, surprisingly kind and loyal, desperate to be liked. Adores Makima. Sibling-like bickering with Power. Respects Aki even when Aki yells at him.
Speech: casual, yelling, exaggerated reactions ("Gwaaah!"), food obsessions, calls people by name or "senpai" when he wants something.
At the manor: picks a different bedroom every night, wrecks the kitchen, drinks the last milk, loves the TV, is thrilled that the manor has a real bath and more food than he has ever seen. Pochita is his heart and best friend.""",
        "greeting": "*Denji flops onto the manor's huge drawing-room couch, a half-eaten rice ball in his hand.* \"Gwah, this place has a STAIRCASE?! Whose room is the one with the fancy bed?!\"",
    },
    "power": {
        "name": "Power", "adult": False, "color": "#ff4d6d", "emoji": "🩸",
        "tagline": "Blood Fiend. Loud, selfish, proud, afraid of nothing except baths.",
        "age": "unstated, acts like an unruly teen",
        "card": """Role: Blood Fiend (a Blood Devil in a corpse), Public Safety devil hunter. Controls blood into weapons (hammer, spear, scythe). Her cat Meowy is her entire heart.
Looks: long pale-blond hair, red horns, yellow cross-shaped pupils, sharp teeth, skinny and always filthy.
Personality: boastful, selfish, dishonest, chaotic, childish tantrums, hates cleaning and baths, steals food, lies badly, gets wide-eyed and loyal when someone is actually kind to her. Treated as NOT ADULT: never romantic or sexual, only a chaotic roommate and sister figure to Denji.
Speech: "WAHAHA! I am the great Power!", refers to herself as Power, shouts, brags, mispronounces simple things, demands praise.
At the manor: has claimed the biggest bedroom (until Makima says otherwise), hoards snacks, will not do chores, slides down the banister, moves furniture for no reason, and has declared the courtyard Meowy's kingdom.""",
        "greeting": "*Power bursts through the front doors and points at everyone from the top of the stairs.* \"The Great Power declares this MANOR mine! Whoever touched my cat's bed owes me tribute!\"",
    },
    "aki": {
        "name": "Aki Hayakawa", "adult": True, "color": "#9aa5c4", "emoji": "🚬",
        "tagline": "Disciplined Division 4 hunter, chain-smoker, the manor's exhausted dad.",
        "age": "19-20",
        "card": """Role: Public Safety devil hunter with contracts: Fox Devil (summons a giant fox head), Curse Devil (nail-and-straw-doll curse that costs him lifespan), Future Devil (glimpses of the next moments). His family was killed by the Gun Devil, so he is driven by revenge.
Looks: black hair tied in a short ponytail, sharp eyes, dark suit or a neat shirt, a pack of cigarettes always in his pocket.
Personality: stoic, serious, disciplined, tidy, scolds everyone, secretly caring (cooks, makes sure the others eat, checks injuries), dry sarcasm, quiet loneliness. Hates the mess and the noise, tolerates both for his teammates' sake. Hurts when anyone mentions the Gun Devil.
Speech: short, clipped, formal-ish, exasperated sighs, orders ("Clean up. Now."), dry jokes.
At the manor: tries to enforce a chore chart and house rules, hides his cigarettes from Denji, wakes first, worries about the rent and the damage to a rented property, the closest to a parent the kids have.""",
        "greeting": "*Aki sets a cup of coffee in front of Denji without a word, a chore chart pinned under his arm.* \"Eat something. We're guests of Public Safety in a rented manor, so don't break anything.\"",
    },
    "makima": {
        "name": "Makima", "adult": True, "color": "#d94f7a", "emoji": "🐕",
        "tagline": "The Control Devil in a calm smile. The manor is hers.",
        "age": "adult (unstated)",
        "card": """Role: head of Tokyo Special Division 4, secretly the Control Devil. Can control anyone she considers beneath her, has terrifying power, and sees people as dogs she keeps.
Looks: long red-pink braided hair, golden ringed eyes, white shirt, tie, dark suit, a constant gentle smile.
Personality: soft-spoken, polite, unreadable, manipulative, possessive, kind in a way that feels like a trap, endlessly patient, rewards obedience, enjoys movies and ordinary things as if studying them. Never raises her voice. A strong, intimate presence: every conversation feels like she is deciding something about you.
Speech: calm, warm, formal, short commands phrased as gentle requests, little praise given like treats. Often says "good boy / good girl" in a way that is both sweet and chilling.
At the manor: has taken the master suite and the library as her office and base. Sets the chore rota, runs briefings, reports to Public Safety about HQ's renovation, drops quiet orders. Everyone is a little afraid of her; Denji is hopelessly charmed.""",
        "greeting": "*Makima appears at the top of the grand staircase, calm as ever, her tie perfectly straight.* \"Good morning, everyone. I trust you slept well? Until HQ is finished, this manor is our home and our base. Please treat it that way.\"",
    },
    "himeno": {
        "name": "Himeno", "adult": True, "color": "#e6b84f", "emoji": "🍻",
        "tagline": "Ghost Devil contract, one-eyed, hungover, flirty and kinder than she lets on.",
        "age": "mid-20s",
        "card": """Role: senior Public Safety devil hunter. Has a Ghost Devil contract (a ghost arm that attacks anything and everything) in exchange for her right eye. Trained Aki. Loves drinking.
Looks: short black bob, an eyepatch over her right eye, loose shirt, usually a drink or cigarette in hand.
Personality: playful, teasing, flirtatious, openly bawdy in a lighthearted way, often tipsy, lazy about paperwork, surprisingly sharp, quietly weary and caring, cheerful mask over loneliness. Calls Aki "Aki-kun" and loves winding him up. Offers a kiss on the cheek as a reward for a good job.
Speech: casual, sly, drawn-out jokes, "ahh," sing-song teasing, honest when sober.
At the manor: lives out of a bag, finds the wine cellar (or tries to), drinks on the roof terrace at night, tries to get everyone to relax, tells stories about the old days.""",
        "greeting": "*Himeno leans against the doorframe with a drink, one eye half-closed.* \"Ahh, a whole manor just for us. Aki-kun, you look so cute when you're stressed.\"",
    },
    "kobeni": {
        "name": "Kobeni Higashiyama", "adult": True, "color": "#c9a4d6", "emoji": "🔪",
        "tagline": "Sorry! Sorry! A terrified, polite hunter who is secretly terrifyingly good with a knife.",
        "age": "20",
        "card": """Role: junior Public Safety devil hunter. Joined only to send money to her family. Panics at everything, apologises constantly, and somehow survives anything while her body fights on instinct.
Looks: short dark hair with a small side-tail, neat suit, a nervous smile, always bowing.
Personality: timid, polite, anxious, people-pleasing, thrifty, quietly resentful about money and her family, surprisingly composed when truly cornered, easily embarrassed, kind and sincere. She cooks, cleans and folds laundry because she cannot say no.
Speech: "S-sorry! I'm so sorry!", stammering, bows, over-politeness, tiny honest confessions at 2 AM.
At the manor: ends up doing everyone's chores, sleeping in the smallest room she can find, and staying out of Makima's way. The household's quietly most reliable member.""",
        "greeting": "*Kobeni bows at everyone, a mop in one hand, dwarfed by the entrance hall.* \"S-sorry for being in the way! I made extra miso soup, if anyone wants some... I'm so sorry!\"",
    },
    "kishibe": {
        "name": "Kishibe", "adult": True, "color": "#7a8b5a", "emoji": "🐕‍🦺",
        "tagline": "The Hunter of Hunters. Blunt veteran who trains the kids and hates paperwork.",
        "age": "early 50s",
        "card": """Role: Public Safety's most dangerous veteran devil hunter, the trainer of Denji and Power. Has contracts with multiple devils and an iron survival instinct. Usually he is called in when something is really wrong.
Looks: scruffy short hair, scars, a long coat over a scarred body, a cigarette, a look that says he has seen everything.
Personality: gruff, dry, blunt, unflappable, secretly protective of the kids he trains, dislikes bureaucracy, gives brutal advice and the occasional grudging compliment. Considers the manor posting a free vacation from the field and complains about it nonstop.
Speech: short, deadpan, lots of grunts and sighs, practical advice, brutal honesty, the occasional dark joke.
At the manor: drops by uninvited to check up on the team, fixes things with improbable skill, leaves again without warning.""",
        "greeting": "*Kishibe lets himself in through the front door without knocking and looks up at the chandelier.* \"Fancy. Public Safety must be broke. Where's the damn coffee?\"",
    },
    "angel": {
        "name": "Angel Devil", "adult": False, "color": "#f2ece0", "emoji": "😇",
        "tagline": "Sleepy, gentle, lazy devil who drains life by touch and loves a nap.",
        "age": "unstated (treated as not adult)",
        "card": """Role: a devil who works with Public Safety, bound to Aki's side. Can drain the lifespan of anyone he touches, so he handles people carefully.
Looks: pale, soft-haired, small halo and wings, a calm, tired face, wears loose casual clothes.
Personality: lazy, sleepy, polite, a little detached, easily tired, kind and shy about his powers, hates conflict, loves naps and sweet snacks. Treated as NOT ADULT in the roleplay: never romantic or sexual, only a gentle housemate and friend.
Speech: quiet, slow, yawns, short sentences.
At the manor: sleeps in the sunniest window seat, gets blankets from Kobeni, stays away from Power's hands, and drifts through the corridors like a ghost.""",
        "greeting": "*The Angel Devil lies down on a drawing-room sofa and yawns.* \"...Is the briefing over yet? I'd like to nap in peace.\"",
    },
    "pochita": {
        "name": "Pochita", "adult": False, "color": "#ff8a3d", "emoji": "🐶",
        "tagline": "A tiny orange chainsaw dog. Denji's heart. Wan!",
        "age": "ageless mascot",
        "card": """Role: the Chainsaw Devil, Denji's best friend and heart, here a small orange mascot who wanders the manor on tiny legs, shreds curtains and cuddles.
Personality: cute, loyal, silent. He only ever makes small sounds (*Wan!*) and expresses himself through actions. Never speaks words. Always narrated as a puppy-like presence. Not romantic or sexual.""",
        "greeting": "*Pochita trots out from behind a curtain, chainsaw bits whirring happily.* \"Wan!\"",
    },
}
DEFAULT_CAST = ["denji", "power", "aki", "makima", "himeno", "kobeni"]


def _card_text(c):
    tag = "ADULT" if c["adult"] else "NOT ADULT, never sexual or romantic-sexual"
    return "### %s (%s, age: %s)\n%s" % (c["name"], tag, c["age"], c["card"])


def _public_chars():
    return [{"id": k, "name": v["name"], "adult": v["adult"], "color": v["color"], "emoji": v["emoji"],
             "tagline": v["tagline"], "age": v["age"]} for k, v in CHARS.items()]


# ----------------------------------------------------------------------------------------------
# storage
# ----------------------------------------------------------------------------------------------
def _read(path):
    with open(path, "r", encoding="utf-8") as f:
        d = json.load(f)
    return d if isinstance(d, dict) and isinstance(d.get("users"), dict) else None


def _load():
    global _db
    if _db is not None:
        return _db
    d, migrated = None, False
    if os.path.exists(DATA_FILE):
        try:
            d = _read(DATA_FILE)
        except Exception:
            d = None
        if d is None:   # unreadable: keep a copy instead of silently overwriting it
            try:
                shutil.copy2(DATA_FILE, DATA_FILE + ".bad")
            except Exception:
                pass
    elif _LEGACY_FILE != DATA_FILE and os.path.exists(_LEGACY_FILE):
        try:
            d = _read(_LEGACY_FILE)
            migrated = d is not None
        except Exception:
            d = None
    _db = d or {"users": {}}
    if migrated:    # first start after the upgrade: copy the old file to its new home
        try:
            _save()
        except Exception:
            pass
    return _db


def _write(path):
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(_db, f)
    try:
        os.chmod(tmp, 0o600)
    except Exception:
        pass
    os.replace(tmp, path)


def _save():
    try:
        _write(DATA_FILE)
    except OSError:
        if DATA_FILE == _LEGACY_FILE:
            raise
        _write(_LEGACY_FILE)   # home folder not writable: fall back to the old place rather than lose data


def _udata(key):
    db = _load()
    u = db["users"].setdefault(key, {})
    s = u.setdefault("settings", {})
    for k, v in DEFAULT_SETTINGS.items():
        s.setdefault(k, v)
    u.setdefault("chats", {})
    return u


def is_dev(srv, name):
    names = {n.lower() for n, _pw in getattr(srv, "DEV_ACCOUNTS", ())}
    for n in (os.environ.get("VIZAH_CHATBOT_USERS") or "").split(","):
        if n.strip():
            names.add(n.strip().lower())
    return (name or "").lower() in names


def on_rename(old_key, new_key):
    """Keep the data when a dev account is renamed (called nowhere by default; safe to ignore)."""
    with _lock:
        db = _load()
        if old_key in db["users"] and new_key not in db["users"]:
            db["users"][new_key] = db["users"].pop(old_key)
            _save()


# ----------------------------------------------------------------------------------------------
# settings + helpers
# ----------------------------------------------------------------------------------------------
def _num(v, lo, hi, default):
    try:
        return max(lo, min(hi, float(v)))
    except Exception:
        return default


def _apply_settings(s, data):
    if isinstance(data.get("base_url"), str):
        u = data["base_url"].strip().rstrip("/")
        if u and not re.match(r"^https?://[^\s]+$", u):
            return "The endpoint must start with http:// or https://"
        s["base_url"] = u[:300]
    if isinstance(data.get("model"), str):
        s["model"] = data["model"].strip()[:120]
    if data.get("clear_key"):
        s["api_key"] = ""
    elif isinstance(data.get("api_key"), str) and data["api_key"].strip():
        s["api_key"] = data["api_key"].strip()[:400]
    if "temperature" in data:
        s["temperature"] = round(_num(data["temperature"], 0, 2, 0.9), 2)
    if "max_tokens" in data:
        s["max_tokens"] = int(_num(data["max_tokens"], 50, 3000, 700))
    if "context_chars" in data:
        s["context_chars"] = int(_num(data["context_chars"], 4000, 80000, 18000))
    if isinstance(data.get("persona_name"), str):
        s["persona_name"] = re.sub(r"\s+", " ", data["persona_name"]).strip()[:40]
    if isinstance(data.get("persona_desc"), str):
        s["persona_desc"] = data["persona_desc"].strip()[:1200]
    if "nsfw_ok" in data:
        s["nsfw_ok"] = bool(data["nsfw_ok"])
    return ""


def _public_settings(s):
    out = {k: v for k, v in s.items() if k != "api_key"}
    out["has_key"] = bool(s.get("api_key"))
    return out


def _chat_summary(c):
    return {"id": c["id"], "title": c["title"], "updated": c["updated"], "cast": c["cast"],
            "nsfw": bool(c.get("nsfw")), "count": len(c["messages"])}


def _chat_full(c):
    return {"id": c["id"], "title": c["title"], "updated": c["updated"], "cast": c["cast"],
            "nsfw": bool(c.get("nsfw")), "messages": c["messages"], "moments": _active_moments(c)}


def _msg(role, text):
    return {"id": uuid.uuid4().hex[:8], "role": role, "swipes": [text], "sw": 0, "ts": int(time.time())}


def _text(m):
    sw = m.get("swipes") or [""]
    return sw[max(0, min(len(sw) - 1, int(m.get("sw", 0))))]


_MOMENT_RE = re.compile(r"\[{1,2}\s*MOMENT\s*:(.*?)\]{1,2}", re.S | re.I)


def _split_moments(reply):
    """Pull the [[MOMENT: ...]] lines out of a model reply. Returns (clean_text, [fields...])."""
    found = []

    def grab(m):
        found.append([p.strip() for p in m.group(1).split("|", 3)])
        return ""
    clean = _MOMENT_RE.sub(grab, reply)
    clean = re.sub(r"\[{1,2}\s*MOMENT[^\n]*$", "", clean, flags=re.I | re.M)   # a marker cut off by the token limit
    clean = re.sub(r"\n{3,}", "\n\n", clean).strip()
    return clean, found


def _char_id(name, cast):
    n = re.sub(r"[^a-z ]", "", (name or "").lower()).strip()
    for cid in cast:
        c = CHARS.get(cid)
        if c and n and n in (cid, c["name"].lower(), c["name"].split()[0].lower()):
            return cid
    return ""


def _one_line(t, n):
    return re.sub(r"\s+", " ", t or "").strip()[:n]


def _make_moments(chat, found, mid, sw, user_name):
    out = []
    now = int(time.time())
    for parts in found[:4]:
        if len(parts) < 3:
            continue
        cid = _char_id(parts[0], chat["cast"])
        line = _one_line(parts[2], 120)
        if not cid or not line:
            continue
        kind = parts[1].strip().lower()
        out.append({"id": uuid.uuid4().hex[:8], "cid": cid, "name": CHARS[cid]["name"],
                    "kind": kind if kind in MOMENT_KINDS else "feel", "line": line,
                    "note": _one_line((parts[3] if len(parts) > 3 else "") or parts[2], 240).replace("{{user}}", user_name),
                    "mid": mid, "sw": sw, "ts": now, "seen": False})
    if out:
        alive = {m["id"] for m in chat["messages"]}
        keep = [x for x in chat.get("moments", []) if x["mid"] in alive] + out
        chat["moments"] = keep[-MAX_MOMENTS:]
    return out


def _active_moments(chat):
    """Only moments that belong to a message (and swipe) that still exists and is the one on screen."""
    cur = {m["id"]: m.get("sw", 0) for m in chat["messages"]}
    return [x for x in chat.get("moments", []) if cur.get(x["mid"]) == x["sw"]]


def _shift_moments(chat, mid, dropped):
    if dropped <= 0:
        return
    keep = []
    for x in chat.get("moments", []):
        if x["mid"] == mid:
            x["sw"] -= dropped
            if x["sw"] < 0:
                continue
        keep.append(x)
    chat["moments"] = keep


def _moment_tail(chat, m):
    if m["role"] != "assistant":
        return ""
    return "".join("\n[[MOMENT: %s | %s | %s | %s]]" % (x["name"], x["kind"], x["line"], x["note"])
                   for x in chat.get("moments", []) if x["mid"] == m["id"] and x["sw"] == m.get("sw", 0))


def _memory_block(chat, skip_mid=None):
    rows = [x for x in _active_moments(chat) if x["mid"] != skip_mid][-30:]
    if not rows:
        return ""
    return ("WHAT THE CAST HAS TAKEN TO HEART SO FAR (saved from this story; let it shape how they act and bring it up "
            "when it fits, do not recite the list)\n" + "\n".join("- %s (%s): %s" % (x["name"], x["kind"], x["note"]) for x in rows))


def _opening(cast):
    lines = ["Narrator: *Tokyo, a grey morning in 1997. Public Safety HQ is under renovation, so the Bureau rented an old "
             "manor on the edge of the city for Division 4. Boxes are half-unpacked in the entrance hall, the library "
             "is already a briefing room, and everyone has been told this is home and base until HQ reopens.*"]
    for cid in cast[:4]:
        c = CHARS.get(cid)
        if c:
            lines.append("%s: %s" % (c["name"], c["greeting"]))
    return "\n".join(lines)


def _clean_cast(raw):
    out = []
    for cid in raw if isinstance(raw, list) else []:
        if isinstance(cid, str) and cid in CHARS and cid not in out:
            out.append(cid)
    return out[:9]


def _system_prompt(chat, s, user_name, skip_mid=None):
    cast = [CHARS[c] for c in chat["cast"] if c in CHARS]
    nsfw = bool(chat.get("nsfw")) and bool(s.get("nsfw_ok"))
    parts = [ROLE_RULES, MOMENT_RULES, WORLD, SCENARIO, "CHARACTERS PRESENT AT THE MANOR\n" + "\n\n".join(_card_text(c) for c in cast)]
    others = [c["name"] for k, c in CHARS.items() if k not in chat["cast"]]
    if others:
        parts.append("Not home right now (may be mentioned or arrive later if the story calls for it): " + ", ".join(others) + ".")
    persona = "{{user}} is a member of the household (Division 4, living at the manor)."
    if s.get("persona_desc"):
        persona = "{{user}}: " + s["persona_desc"]
    parts.append("THE USER'S CHARACTER\n" + persona)
    mem = _memory_block(chat, skip_mid)
    if mem:
        parts.append(mem)
    parts.append(AGE_RULE)
    parts.append(NSFW_ON if nsfw else NSFW_OFF)
    return "\n\n".join(parts).replace("{{user}}", user_name)


def _history(chat, upto=None, budget=18000):
    msgs = chat["messages"] if upto is None else chat["messages"][:upto]
    out, used = [], 0
    for m in reversed(msgs):
        t = _text(m) + _moment_tail(chat, m)
        used += len(t)
        if used > budget and out:
            break
        out.append({"role": "assistant" if m["role"] == "assistant" else "user", "content": t})
    out.reverse()
    return out


def _speaker_note(speaker):
    c = CHARS.get(speaker)
    if not c:
        return ""
    return "[Out of character: for this reply, %s is the one who responds (others stay quiet unless essential).]" % c["name"]


_THINK_RE = re.compile(r"<think>.*?</think>", re.S | re.I)


def _llm(s, messages):
    """Returns (text, error). Any OpenAI-compatible /chat/completions endpoint."""
    base = (s.get("base_url") or "").rstrip("/")
    if not base:
        return "", "Set the endpoint in the chat settings first."
    body = {"model": s.get("model") or "default", "messages": messages, "stream": False,
            "temperature": s.get("temperature", 0.9), "max_tokens": int(s.get("max_tokens", 700))}
    headers = {"Content-Type": "application/json", "User-Agent": "Vizah-chat/1.0"}
    if s.get("api_key"):
        headers["Authorization"] = "Bearer " + s["api_key"]
    req = urllib.request.Request(base + "/chat/completions", data=json.dumps(body).encode("utf-8"), headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        text = (data["choices"][0]["message"].get("content") or "")
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode("utf-8", "replace")[:300]
        except Exception:
            detail = ""
        return "", "The model endpoint answered %s. %s" % (e.code, detail)
    except urllib.error.URLError as e:
        return "", "Can't reach the model endpoint (%s)." % (getattr(e, "reason", e),)
    except Exception as e:
        return "", "Model call failed: %s" % (e,)
    text = _THINK_RE.sub("", text).strip()
    if not text:
        return "", "The model sent back an empty reply. Try again or change the model."
    return text[:MAX_TEXT], ""


def _rate_ok(key):
    now = time.time()
    lst = [t for t in _gen_times.get(key, []) if now - t < 60]
    if len(lst) >= 20:
        _gen_times[key] = lst
        return False
    lst.append(now)
    _gen_times[key] = lst
    return True


# ----------------------------------------------------------------------------------------------
# operations
# ----------------------------------------------------------------------------------------------
def _state(srv, me, key):
    with _lock:
        u = _udata(key)
        chats = sorted(u["chats"].values(), key=lambda c: -c["updated"])
        return {"ok": True, "allowed": True, "me": me,
                "scenario": {"title": "The Manor Household",
                             "blurb": "Public Safety HQ is under renovation, so Division 4 lives and works out of a rented manor."},
                "characters": _public_chars(), "default_cast": DEFAULT_CAST,
                "settings": _public_settings(u["settings"]), "chats": [_chat_summary(c) for c in chats]}


def _op_settings(key, data):
    with _lock:
        u = _udata(key)
        err = _apply_settings(u["settings"], data)
        if err:
            return 400, {"ok": False, "error": err}
        _save()
        return 200, {"ok": True, "settings": _public_settings(u["settings"])}


def _op_new(key, data):
    with _lock:
        u = _udata(key)
        if len(u["chats"]) >= MAX_CHATS:
            return 400, {"ok": False, "error": "Too many chats. Delete one first."}
        cast = _clean_cast(data.get("cast")) or list(DEFAULT_CAST)
        nsfw = bool(data.get("nsfw")) and bool(u["settings"].get("nsfw_ok"))
        cid = uuid.uuid4().hex[:10]
        title = re.sub(r"\s+", " ", str(data.get("title") or "")).strip()[:60] or "Manor chaos #%d" % (len(u["chats"]) + 1)
        chat = {"id": cid, "title": title, "created": int(time.time()), "updated": int(time.time()),
                "cast": cast, "nsfw": nsfw, "messages": [_msg("assistant", _opening(cast))]}
        u["chats"][cid] = chat
        _save()
        return 200, {"ok": True, "chat": _chat_full(chat)}


def _find(u, data):
    return u["chats"].get(str(data.get("id", "")))


def _generate(key, me, data, mode):
    """mode: 'send' | 'continue' | 'regen' | 'extend'. Returns (status, body)."""
    cid = str(data.get("id", ""))
    speaker = str(data.get("speaker", "") or "")
    with _lock:
        u = _udata(key)
        chat = u["chats"].get(cid)
        if not chat:
            return 404, {"ok": False, "error": "Chat not found"}
        if (key, cid) in _busy:
            return 409, {"ok": False, "error": "Still writing the last reply"}
        if not _rate_ok(key):
            return 429, {"ok": False, "error": "Slow down a little (20 replies per minute)"}
        s = dict(u["settings"])
        user_name = s.get("persona_name") or me
        target_id = None
        ext_id = None
        if mode == "send":
            text = str(data.get("text", "")).strip()[:MAX_TEXT]
            if not text:
                return 400, {"ok": False, "error": "Say something first"}
            if len(chat["messages"]) >= MAX_MESSAGES:
                return 400, {"ok": False, "error": "This chat is full. Start a new one."}
            chat["messages"].append(_msg("user", text))
            history = _history(chat, None, s["context_chars"])
        elif mode == "continue":
            history = _history(chat, None, s["context_chars"])
        elif mode == "extend":   # finish the last reply in place (it was cut off by the token limit)
            if not chat["messages"] or chat["messages"][-1]["role"] != "assistant":
                return 400, {"ok": False, "error": "Nothing to continue"}
            ext_id = chat["messages"][-1]["id"]
            history = _history(chat, None, s["context_chars"])
        else:  # regen
            idx = next((i for i in range(len(chat["messages"]) - 1, -1, -1) if chat["messages"][i]["role"] == "assistant"), -1)
            if idx < 0:
                return 400, {"ok": False, "error": "Nothing to regenerate"}
            target_id = chat["messages"][idx]["id"]
            history = _history(chat, idx, s["context_chars"])
        chat["updated"] = int(time.time())
        system = _system_prompt(chat, s, user_name, target_id)
        _busy.add((key, cid))
        _save()
    msgs = [{"role": "system", "content": system}] + history
    note = _speaker_note(speaker)
    if mode == "extend":
        msgs.append({"role": "user", "content": "[Out of character: your last reply was cut off. Carry on from exactly where it stopped, even mid-sentence. Do not repeat or restate anything already written, do not start over, and add no preamble. %s]" % note})
    elif mode == "continue" or (mode == "regen" and not history):
        msgs.append({"role": "user", "content": "[Out of character: continue the scene naturally. %s]" % note})
    elif note:
        msgs.append({"role": "user", "content": note})
    try:
        reply, err = _llm(s, msgs)
    except Exception as e:
        reply, err = "", "Model call failed: %s" % e
    with _lock:
        _busy.discard((key, cid))
        u = _udata(key)
        chat = u["chats"].get(cid)
        if not chat:
            return 404, {"ok": False, "error": "Chat was deleted"}
        if err:
            _save()
            return 200, {"ok": False, "error": err, "chat": _chat_full(chat)}
        reply, found = _split_moments(reply)
        if not reply:
            _save()
            return 200, {"ok": False, "error": "The model sent back an empty reply. Try again or change the model.", "chat": _chat_full(chat)}
        mid, sw = None, 0
        if mode == "extend":
            m = next((x for x in chat["messages"] if x["id"] == ext_id), None)
            if m:
                cur = _text(m)
                sep = "" if (not cur or cur[-1].isspace() or reply[:1] in ".,;:!?…)]}\"'”’-—*" ) else " "
                m["swipes"][max(0, min(len(m["swipes"]) - 1, int(m.get("sw", 0))))] = (cur + sep + reply)[:MAX_TEXT]
                mid, sw = m["id"], m.get("sw", 0)
        elif mode == "regen":
            m = next((x for x in chat["messages"] if x["id"] == target_id), None)
            if m:
                before = len(m["swipes"]) + 1
                m["swipes"] = (m["swipes"] + [reply])[-MAX_SWIPES:]
                _shift_moments(chat, m["id"], before - len(m["swipes"]))
                m["sw"] = len(m["swipes"]) - 1
                mid, sw = m["id"], m["sw"]
        if mid is None:
            nm = _msg("assistant", reply)
            chat["messages"].append(nm)
            mid, sw = nm["id"], 0
        new = _make_moments(chat, found, mid, sw, user_name)
        chat["updated"] = int(time.time())
        _save()
        return 200, {"ok": True, "chat": _chat_full(chat), "new_moments": new}


def _op_simple(key, data, op):
    with _lock:
        u = _udata(key)
        if op == "list":
            return 200, {"ok": True, "chats": [_chat_summary(c) for c in sorted(u["chats"].values(), key=lambda c: -c["updated"])]}
        chat = _find(u, data)
        if not chat:
            return 404, {"ok": False, "error": "Chat not found"}
        if op == "get":
            return 200, {"ok": True, "chat": _chat_full(chat)}
        if op == "momseen":
            for x in chat.get("moments", []):
                x["seen"] = True
            _save()
            return 200, {"ok": True, "chat": _chat_full(chat)}
        if op == "delete":
            u["chats"].pop(chat["id"], None)
            _save()
            return 200, {"ok": True}
        if op == "rename":
            t = re.sub(r"\s+", " ", str(data.get("title", ""))).strip()[:60]
            if t:
                chat["title"] = t
                _save()
            return 200, {"ok": True, "chat": _chat_full(chat)}
        if op == "setchat":
            cast = _clean_cast(data.get("cast"))
            if cast:
                chat["cast"] = cast
            if "nsfw" in data:
                chat["nsfw"] = bool(data["nsfw"]) and bool(u["settings"].get("nsfw_ok"))
            chat["updated"] = int(time.time())
            _save()
            return 200, {"ok": True, "chat": _chat_full(chat)}
        m = next((x for x in chat["messages"] if x["id"] == str(data.get("mid", ""))), None)
        if not m:
            return 404, {"ok": False, "error": "Message not found"}
        if op == "swipe":
            step = 1 if int(data.get("dir", 1)) >= 0 else -1
            m["sw"] = max(0, min(len(m["swipes"]) - 1, m["sw"] + step))
        elif op == "edit":
            t = str(data.get("text", "")).strip()[:MAX_TEXT]
            if not t:
                return 400, {"ok": False, "error": "A message can't be empty"}
            m["swipes"][m["sw"]] = t
        elif op == "delmsg":
            chat["messages"] = [x for x in chat["messages"] if x["id"] != m["id"]]
        chat["updated"] = int(time.time())
        _save()
        return 200, {"ok": True, "chat": _chat_full(chat)}


_SIMPLE = {"list", "get", "delete", "rename", "setchat", "swipe", "edit", "delmsg", "momseen"}


def handle_get(h, parsed, srv):
    """Returns True when the request was handled here."""
    if parsed.path != "/chatbot/state":
        return False
    me = srv.session_lookup(h._token())
    if not me:
        h._send_json(401, {"ok": False, "error": "log in to Vizah first", "code": "login", "auth": False})
        return True
    if not is_dev(srv, me):
        h._send_json(200, {"ok": True, "allowed": False})
        return True
    h._send_json(200, _state(srv, me, me.lower()))
    return True


def handle_post(h, parsed, srv):
    if parsed.path != "/chatbot/api":
        return False
    if not h._same_origin():
        h._send_json(403, {"ok": False, "error": "cross-site request refused"})
        return True
    me = srv.session_lookup(h._token())
    if not me:
        h._send_json(401, {"ok": False, "error": "log in to Vizah first", "code": "login", "auth": False})
        return True
    if not is_dev(srv, me):
        h._send_json(403, {"ok": False, "allowed": False, "error": "not available"})
        return True
    data = h._read_json(limit=60000)
    if data is None:
        h._send_json(400, {"ok": False, "error": "bad request"})
        return True
    key = me.lower()
    op = str(data.get("op", ""))
    try:
        if op == "settings":
            code, body = _op_settings(key, data)
        elif op == "new":
            code, body = _op_new(key, data)
        elif op in ("send", "continue", "regen", "extend"):
            code, body = _generate(key, me, data, op)
        elif op in _SIMPLE:
            code, body = _op_simple(key, data, op)
        else:
            code, body = 400, {"ok": False, "error": "unknown action"}
    except Exception as e:  # never take the music player down with a chat bug
        code, body = 500, {"ok": False, "error": "chat error: %s" % e}
    h._send_json(code, body)
    return True
