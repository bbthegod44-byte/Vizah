/* Vizah service worker.
   Deliberately tiny: it makes the app installable and shows a friendly page when the
   server is unreachable. It never caches or touches API calls, logins, streams or
   anything that is not a page navigation, so the live app behaves exactly as before. */
const VERSION = "vizah-pwa-v1";
const SHELL = ["/offline.html", "/icons/icon-192.png", "/icons/icon-512.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  // only page navigations; everything else goes straight to the network untouched
  if (req.mode !== "navigate" || req.method !== "GET") return;
  event.respondWith(
    fetch(req).catch(() =>
      caches.match("/offline.html").then((r) => r || new Response("Offline", { status: 503 }))
    )
  );
});
