#!/usr/bin/env python3
"""Wipe every saved Vizah user from this server.

    python3 clear_users.py          # asks first
    python3 clear_users.py --yes    # no question

Removes: all accounts and login sessions (~/.vizah_accounts.json), every account's password and
YouTube login in creds.txt, and all direct messages (~/.vizah_messages.json). A backup of each
file is saved next to it as <name>.bak before anything is changed. Stop the server first, then
start it again afterwards (a running server keeps the old list in memory).

Left alone: config.json (the old single-user Last.fm setup), the shared YouTube API key.
"""
import os
import shutil
import sys

import creds

AUTH = os.environ.get("VIZAH_AUTH") or os.path.expanduser("~/.vizah_accounts.json")
MSGS = os.environ.get("VIZAH_MESSAGES") or os.path.expanduser("~/.vizah_messages.json")


def main():
    if "--yes" not in sys.argv[1:]:
        print("This deletes ALL Vizah accounts on this server (logins, friends, messages).")
        if input("Type DELETE to continue: ").strip() != "DELETE":
            print("Cancelled.")
            return
    for path in (AUTH, MSGS):
        if os.path.exists(path):
            shutil.copy2(path, path + ".bak")
            os.remove(path)
            print("Removed", path, "(backup:", path + ".bak)")
    entries, extra = creds._read()
    drop = [k for k in entries if k.startswith("pw.") or k.partition(".")[0] in creds.USER_KEYS and "." in k]
    if drop:
        shutil.copy2(creds.CREDS_FILE, creds.CREDS_FILE + ".bak")
        for k in drop:
            entries.pop(k, None)
        creds._write(entries, extra)
    print("Removed %d saved login entries from creds.txt." % len(drop))
    print("Done. Start the server again; the first person to sign up becomes the first account.")


if __name__ == "__main__":
    main()
