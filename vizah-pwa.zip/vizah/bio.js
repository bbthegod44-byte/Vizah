/* Vizah profile settings behaviour (added): the Profile tab (a preview of how others see you, with an
   Edit button that opens the editor: bio + listening-status switch + camera button), the
   Profile / Connections tabs, and the social connection cards (Instagram, TikTok, ...).
   The markup lives in the settings panel in index.html. The bio saves go through /save-config with
   ONLY {bio, showListening}, and the social cards save ONLY {socials}, so the theme / Last.fm save
   code is never touched. The server validates every handle and builds the real links itself. */
(function () {
  "use strict";
  if (window.__vizahBio) return;
  window.__vizahBio = true;

  var $ = function (id) { return document.getElementById(id); };

  /* ------------------------------------------------------------------ logos
     Small inline glyphs (24x24, drawn for a dark background). Also used by the profile view in dm.js
     through window.vizahSocialIcon(key, size). Static markup only - nothing user-supplied goes in. */
  var GH = "M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z";
  var TT = "M16.5 3c.3 2.3 1.7 3.9 4 4.1v3a7 7 0 0 1-4-1.3v6.4a5.7 5.7 0 1 1-5.7-5.7c.3 0 .6 0 .9.1v3.1a2.7 2.7 0 1 0 1.8 2.5V3z";
  var BS = "M12 10.8c-1.087-2.114-4.046-6.053-6.798-7.995C2.566.944 1.561 1.266.902 1.565.139 1.908 0 3.08 0 3.768c0 .69.378 5.65.624 6.479.815 2.736 3.713 3.66 6.383 3.364.136-.02.275-.039.415-.056-.138.022-.276.04-.415.056-3.912.58-7.387 2.005-2.83 7.078 5.013 5.19 6.87-1.113 7.823-4.308.953 3.195 2.05 9.271 7.733 4.308 4.267-4.308 1.172-6.498-2.74-7.078a8.741 8.741 0 0 1-.415-.056c.14.017.279.036.415.056 2.67.297 5.568-.628 6.383-3.364.246-.828.624-5.79.624-6.478 0-.69-.139-1.861-.902-2.206-.659-.298-1.664-.62-4.3 1.24C16.046 4.748 13.087 8.687 12 10.8Z";
  var SC = "M12 3c-3 0-4.6 2.2-4.6 4.8v1.9c-.5.1-1.2.1-1.7.4-.3.2-.2.6.1.8.4.2 1 .3 1.3.5-.3 1.2-1.3 2.3-2.6 2.8-.3.2-.2.6.1.8.7.4 1.5.4 1.9.6.2.5-.1 1.2.6 1.2.7 0 1.5-.2 2.2.3.8.5 1.6 1.4 2.7 1.4s1.9-.9 2.7-1.4c.7-.5 1.5-.3 2.2-.3.7 0 .4-.7.6-1.2.4-.2 1.2-.2 1.9-.6.3-.2.4-.6.1-.8-1.3-.5-2.3-1.6-2.6-2.8.3-.2.9-.3 1.3-.5.3-.2.4-.6.1-.8-.5-.3-1.2-.3-1.7-.4V7.8C16.6 5.2 15 3 12 3z";

  // key -> [label, input hint, svg inner markup]
  var SITES = {
    instagram:  ["Instagram",  "username", '<rect x="3" y="3" width="18" height="18" rx="5.2" fill="none" stroke="#ff4f81" stroke-width="2"/><circle cx="12" cy="12" r="4.2" fill="none" stroke="#ff4f81" stroke-width="2"/><circle cx="17.3" cy="6.7" r="1.2" fill="#ff4f81"/>'],
    tiktok:     ["TikTok",     "username", '<path d="' + TT + '" fill="#25f4ee" transform="translate(-.7 -.5)"/><path d="' + TT + '" fill="#fe2c55" transform="translate(.7 .5)"/><path d="' + TT + '" fill="#fff"/>'],
    x:          ["X",          "username", '<path d="M4.5 4h4l11 16h-4z" fill="#fff"/><path d="M19 4l-5.6 6.5M5 20l5.6-6.5" stroke="#fff" stroke-width="1.6" fill="none"/>'],
    youtube:    ["YouTube",    "handle",   '<rect x="1" y="4.5" width="22" height="15" rx="4.6" fill="#ff0033"/><path d="M10 9v6l5.2-3z" fill="#fff"/>'],
    twitch:     ["Twitch",     "username", '<path d="M4.5 3h16v10.5l-4 4h-4l-3 3v-3h-5z" fill="#9146ff"/><path d="M11 7.5v4M15.5 7.5v4" stroke="#fff" stroke-width="1.8"/>'],
    soundcloud: ["SoundCloud", "username", '<path d="M9.5 18.5V9.2c1-.7 2.2-1.1 3.5-1.1 2.6 0 4.7 1.9 5 4.4 1.7 0 3 1.2 3 2.9s-1.4 3.1-3.1 3.1z" fill="#ff5500"/><path d="M3 15v3M5.2 13v5M7.4 12v6" stroke="#ff5500" stroke-width="1.5" stroke-linecap="round"/>'],
    bandcamp:   ["Bandcamp",   "name",     '<path d="M2.5 17.5l6-11h13l-6 11z" fill="#1da0c3"/>'],
    spotify:    ["Spotify",    "user id",  '<circle cx="12" cy="12" r="11" fill="#1ed760"/><path d="M6.4 9.5c3.6-1.1 7.9-.8 11 1.1M7 12.5c3-.9 6.4-.6 8.9 1M7.6 15.4c2.4-.7 5-.5 7 .8" fill="none" stroke="#000" stroke-width="1.6" stroke-linecap="round"/>'],
    github:     ["GitHub",     "username", '<g transform="translate(0 0) scale(1.5)"><path fill="#fff" d="' + GH + '"/></g>'],
    reddit:     ["Reddit",     "username", '<ellipse cx="12" cy="13.3" rx="7.6" ry="5.6" fill="#ff4500"/><circle cx="4.6" cy="10.6" r="1.9" fill="#ff4500"/><circle cx="19.4" cy="10.6" r="1.9" fill="#ff4500"/><circle cx="9" cy="12.6" r="1.3" fill="#fff"/><circle cx="15" cy="12.6" r="1.3" fill="#fff"/><path d="M9 16c1.7 1.1 4.3 1.1 6 0" stroke="#fff" stroke-width="1.2" fill="none" stroke-linecap="round"/><path d="M12 7.7l1.2-4.3 3.6.8" stroke="#ff4500" stroke-width="1.2" fill="none"/><circle cx="17.6" cy="4.4" r="1.4" fill="#ff4500"/>'],
    bluesky:    ["Bluesky",    "name.bsky.social", '<path d="' + BS + '" fill="#1185fe"/>'],
    threads:    ["Threads",    "username", '<path d="M17.5 9.5C16.8 6.5 14.6 5 12 5c-3.6 0-6 2.7-6 7s2.4 7 6 7c2.6 0 4.6-1.4 4.6-3.6 0-2.2-2-3.2-4.2-3.2-1.9 0-3 .8-3 2 0 1.2 1 1.9 2.4 1.9 2 0 3.2-1.4 3.3-4.6" fill="none" stroke="#fff" stroke-width="1.9" stroke-linecap="round"/>'],
    snapchat:   ["Snapchat",   "username", '<path d="' + SC + '" fill="#fffc00"/>'],
    steam:      ["Steam",      "custom id", '<circle cx="12" cy="12" r="10" fill="none" stroke="#66c0f4" stroke-width="1.8"/><circle cx="15.2" cy="9.6" r="3" fill="none" stroke="#66c0f4" stroke-width="1.8"/><circle cx="8.6" cy="15.4" r="1.9" fill="#66c0f4"/><path d="M9.8 14.2l3-2.6" stroke="#66c0f4" stroke-width="1.8"/>'],
    letterboxd: ["Letterboxd", "username", '<circle cx="6.5" cy="12" r="4.2" fill="#ff8000"/><circle cx="17.5" cy="12" r="4.2" fill="#40bcf4"/><circle cx="12" cy="12" r="4.2" fill="#00e054" fill-opacity=".92"/>'],
    facebook:   ["Facebook",   "username", '<circle cx="12" cy="12" r="11" fill="#1877f2"/><path d="M13.5 21v-7.5h2.5l.4-3h-2.9V8.7c0-.9.3-1.5 1.5-1.5h1.5V4.5c-.3 0-1.2-.1-2.2-.1-2.2 0-3.7 1.3-3.7 3.8v2.3H8v3h2.6V21z" fill="#fff"/>'],
    website:    ["Website",    "https://\u2026", '<circle cx="12" cy="12" r="9.5" fill="none" stroke="#79e7ff" stroke-width="1.8"/><ellipse cx="12" cy="12" rx="4" ry="9.5" fill="none" stroke="#79e7ff" stroke-width="1.6"/><path d="M2.5 12h19M4 7.5h16M4 16.5h16" stroke="#79e7ff" stroke-width="1.4" fill="none"/>']
  };
  var ORDER = ["instagram", "tiktok", "x", "youtube", "twitch", "soundcloud", "bandcamp", "spotify", "github",
               "reddit", "bluesky", "threads", "snapchat", "steam", "letterboxd", "facebook", "website"];

  function iconSvg(k, size) {
    var s = SITES[k]; if (!s) return "";
    size = size || 22;
    return '<svg viewBox="0 0 24 24" width="' + size + '" height="' + size + '" aria-hidden="true">' + s[2] + "</svg>";
  }
  window.vizahSocialIcon = iconSvg;

  /* ------------------------------------------------------------------ tabs */
  var tabs = { profile: [$("stTabProfile"), $("stPaneProfile")], conn: [$("stTabConn"), $("stPaneConn")] };
  function showTab(name) {
    if (!tabs[name] || !tabs[name][0] || !tabs[name][1]) return;
    Object.keys(tabs).forEach(function (k) {
      var on = k === name;
      tabs[k][0].classList.toggle("on", on);
      tabs[k][0].setAttribute("aria-selected", on ? "true" : "false");
      tabs[k][1].hidden = !on;
    });
    if (name === "conn") loadSocials();
  }
  window.vizahSettingsTab = showTab;
  Object.keys(tabs).forEach(function (k) {
    if (tabs[k][0]) tabs[k][0].addEventListener("click", function () { showTab(k); });
  });
  var tablist = $("stTabs");
  if (tablist) tablist.addEventListener("keydown", function (e) {      // arrow keys move between the tabs
    if (e.key !== "ArrowLeft" && e.key !== "ArrowRight") return;
    var next = document.activeElement === tabs.profile[0] ? "conn" : "profile";
    showTab(next); tabs[next][0].focus(); e.preventDefault();
  });

  /* ------------------------------------------------------------------ social connection cards */
  var grid = $("socGrid");
  var socials = {};          // site key -> handle, as the server stored it
  var cards = {};            // site key -> { card, dot, status, open, form, input, go, cancel, disc, change, msg }
  var socBusy = false;

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function note(c, text, ok) {
    c.msg.textContent = text || ""; c.msg.hidden = !text;
    c.msg.className = "settings-error" + (ok ? " ok" : "");
  }

  function buildCard(k) {
    var site = SITES[k], c = {};
    var card = el("div", "lf-card soc-card"); card.setAttribute("data-k", k);

    var logo = el("div", "lf-logo soc-logo"); logo.setAttribute("role", "img"); logo.setAttribute("aria-label", site[0]);
    logo.innerHTML = iconSvg(k, 24);
    logo.appendChild(el("span", "", site[0]));

    var nm = el("div", "account-name");
    c.dot = el("span", "account-dot"); c.status = el("span", "", "Not connected");
    nm.appendChild(c.dot); nm.appendChild(c.status);

    c.form = el("div", "soc-form"); c.form.hidden = true;
    var f = el("div", "field");
    var lab = el("label", "", site[0] + (k === "website" ? " address" : " username or link"));
    c.input = el("input"); c.input.type = "text"; c.input.maxLength = 200; c.input.placeholder = site[1];
    c.input.autocomplete = "off"; c.input.autocapitalize = "off"; c.input.spellcheck = false;
    c.input.id = "soc_" + k; lab.setAttribute("for", c.input.id);
    f.appendChild(lab); f.appendChild(c.input);
    c.go = el("button", "button primary lf-btn connect", "Save & connect"); c.go.type = "button";
    c.cancel = el("button", "yt-link", "Cancel"); c.cancel.type = "button";
    c.form.appendChild(f); c.form.appendChild(c.go); c.form.appendChild(c.cancel);

    c.open = el("button", "button primary lf-btn connect", "Connect " + site[0]); c.open.type = "button";
    c.disc = el("button", "button lf-btn disconnect", "Disconnect"); c.disc.type = "button"; c.disc.hidden = true;
    c.change = el("button", "yt-link", "Change"); c.change.type = "button"; c.change.hidden = true;
    c.msg = el("p", "settings-error"); c.msg.hidden = true;

    [logo, nm, c.form, c.open, c.disc, c.change, c.msg].forEach(function (n) { card.appendChild(n); });
    c.card = card;

    function openForm() { note(c, ""); c.input.value = socials[k] || ""; c.form.hidden = false; c.open.hidden = true; c.disc.hidden = true; c.change.hidden = true; c.input.focus(); }
    c.open.addEventListener("click", openForm);
    c.change.addEventListener("click", openForm);
    c.cancel.addEventListener("click", function () { c.form.hidden = true; paint(k); });
    c.input.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); c.go.click(); } });
    c.go.addEventListener("click", function () {
      var v = c.input.value.trim();
      if (!v) { note(c, "Enter your " + (k === "website" ? "address" : "username") + " first"); return; }
      var next = copy(socials); next[k] = v;
      c.go.disabled = true; c.go.textContent = "Saving\u2026";
      saveSocials(next).then(function (stored) {
        c.go.disabled = false; c.go.textContent = "Save & connect";
        if (!stored) { note(c, "Couldn\u2019t save \u2014 try again"); return; }
        if (!stored[k]) { note(c, "That doesn\u2019t look like a valid " + (k === "website" ? "address" : "username")); return; }
        c.form.hidden = true; paintAll();
        note(c, site[0] + " connected.", true);
      });
    });
    c.disc.addEventListener("click", function () {
      var next = copy(socials); delete next[k];
      c.disc.disabled = true;
      saveSocials(next).then(function (stored) {
        c.disc.disabled = false;
        if (!stored) { note(c, "Couldn\u2019t disconnect \u2014 try again"); return; }
        paintAll();
      });
    });
    return c;
  }

  function copy(o) { var r = {}; Object.keys(o).forEach(function (k) { r[k] = o[k]; }); return r; }

  function paint(k) {
    var c = cards[k]; if (!c) return;
    var v = socials[k], editing = !c.form.hidden;
    c.dot.className = "account-dot" + (v ? " on" : "");
    c.status.textContent = v ? (k === "website" ? v.replace(/^https?:\/\/(www\.)?/i, "") : "@" + v) : "Not connected";
    c.open.hidden = !!v || editing;
    c.disc.hidden = !v || editing;
    c.change.hidden = !v || editing;
  }
  function paintAll() { ORDER.forEach(paint); }

  function buildGrid() {
    if (!grid || grid.childNodes.length) return;
    ORDER.forEach(function (k) { cards[k] = buildCard(k); grid.appendChild(cards[k].card); });
    paintAll();
  }

  function listOf(map) {
    return ORDER.filter(function (k) { return !!map[k]; }).map(function (k) { return { k: k, v: map[k] }; });
  }
  function mapOf(list) {
    var m = {};
    (Array.isArray(list) ? list : []).forEach(function (it) {
      if (it && typeof it.k === "string" && SITES[it.k] && typeof it.v === "string" && it.v) m[it.k] = it.v;
    });
    return m;
  }

  // save the whole list, then read back what the server actually kept (it normalises and validates)
  function saveSocials(map) {
    if (socBusy) return Promise.resolve(null);
    socBusy = true;
    return fetch("/save-config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ socials: listOf(map) }) })
      .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return fetch("/config", { cache: "no-store" }); })
      .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
      .then(function (c) { socials = mapOf(c && c.socials); return socials; })
      .catch(function () { return null; })
      .then(function (res) { socBusy = false; return res; });
  }

  // connected platforms float to the top whenever the tab is (re)opened - never while you're typing in one
  function sortCards() {
    if (!grid) return;
    for (var i = 0; i < ORDER.length; i++) if (cards[ORDER[i]] && !cards[ORDER[i]].form.hidden) return;
    var on = ORDER.filter(function (k) { return !!socials[k]; });
    var off = ORDER.filter(function (k) { return !socials[k]; });
    on.concat(off).forEach(function (k) { if (cards[k]) grid.appendChild(cards[k].card); });
  }

  function loadSocials() {
    buildGrid();
    if (socBusy) return;
    fetch("/config", { cache: "no-store" }).then(function (r) { return r.ok ? r.json() : null; }).then(function (c) {
      if (!c || socBusy) return;
      socials = mapOf(c.socials);
      ORDER.forEach(function (k) { if (cards[k] && cards[k].form.hidden) paint(k); });
      sortCards();
    }).catch(function () {});
  }

  /* ------------------------------------------------------------------ bio + listening switch */
  var MAX = 160, DELAY = 800;
  var ta = $("bioInput"), share = $("bioShare"), count = $("bioCount"), status = $("bioStatus");
  if (!ta || !share) return;

  var timer = null, dirty = false, saving = false, again = false, hideT = null;

  function upd() { if (count) count.textContent = ta.value.length + "/" + MAX; }
  function say(text, err) {
    if (!status) return;
    clearTimeout(hideT);
    status.textContent = text;
    status.className = "pf-status" + (text ? " show" : "") + (err ? " err" : "");
    if (text && !err && text !== "Saving\u2026") hideT = setTimeout(function () { status.classList.remove("show"); }, 2200);
  }
  function payload() { return { bio: ta.value.trim().slice(0, MAX), showListening: !!share.checked }; }

  var cur = Promise.resolve();
  function save() {
    clearTimeout(timer);
    if (saving) { again = true; return cur; }
    saving = true; again = false;
    var body = payload();
    say("Saving\u2026");
    cur = fetch("/save-config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); dirty = false; say("Saved \u2713"); })
      .catch(function () { say("Couldn\u2019t save \u2014 will retry", true); })
      .then(function () { saving = false; if (again || dirty) { timer = setTimeout(save, 1500); } });
    return cur;
  }
  function queue() { dirty = true; clearTimeout(timer); timer = setTimeout(save, DELAY); }

  ta.addEventListener("input", function () { upd(); queue(); });
  ta.addEventListener("blur", function () { if (dirty) save(); });
  share.addEventListener("change", function () { dirty = true; save(); });
  // don't lose a pending edit if the tab is closed
  window.addEventListener("pagehide", function () {
    if (!dirty) return;
    try { fetch("/save-config", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload()) }); } catch (e) {}
  });

  function load() {
    if (dirty || saving) return;
    fetch("/config", { cache: "no-store" }).then(function (r) { return r.ok ? r.json() : null; }).then(function (c) {
      if (!c || dirty || saving) return;
      if (document.activeElement !== ta) ta.value = typeof c.bio === "string" ? c.bio : "";
      share.checked = c.showListening !== false;
      if (!socBusy) { socials = mapOf(c.socials); ORDER.forEach(function (k) { if (cards[k] && cards[k].form.hidden) paint(k); }); }
      upd();
    }).catch(function () {});
  }
  load();

  /* ---- Profile tab: preview first (exactly what friends see), "Edit profile" opens the editor ---- */
  var pfView = $("pfView"), pfEditWrap = $("pfEditWrap"), pfPrev = $("pfPrev");
  var pfEdit = $("pfEdit"), pfDone = $("pfDone"), pfLogoutAlt = $("pfLogoutAlt");
  var prevTok = 0;

  function renderPreview() {
    if (!pfPrev || !window.vizahRenderProfile) return;
    var tok = ++prevTok;
    fetch("/auth/me", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (me) {
      if (tok !== prevTok) return;
      if (!me || !me.username) { pfPrev.textContent = ""; return; }
      var box = document.createElement("div"); box.className = "dm-prof pf-prev";
      window.vizahRenderProfile(box, me.username, { preview: true, alive: function () { return tok === prevTok; } });
      // swap in once drawn, so an older preview stays on screen instead of flashing "Loading"
      var placeholder = !pfPrev.firstChild || !!pfPrev.querySelector(".dm-empty");
      new MutationObserver(function (m, o) {
        if (!box.firstChild || tok !== prevTok) return;
        o.disconnect();
        if (box.querySelector(".dm-empty") && !placeholder) return;   // couldn't load: keep what's there
        pfPrev.textContent = ""; pfPrev.appendChild(box);
      }).observe(box, { childList: true });
    }).catch(function () {});
  }
  function showProfileView(mode) {            // "view" or "edit"
    if (!pfView || !pfEditWrap) return;
    if (!window.vizahRenderProfile) mode = "edit";   // no preview available: fall back to the editor
    var edit = mode === "edit";
    pfView.hidden = edit; pfEditWrap.hidden = !edit;
    if (edit) load(); else renderPreview();
  }
  window.vizahProfileEdit = function () { showTab("profile"); showProfileView("edit"); };
  if (pfEdit) pfEdit.addEventListener("click", function () { showProfileView("edit"); });
  if (pfLogoutAlt) pfLogoutAlt.addEventListener("click", function () { var b = $("vizLogoutBtn"); if (b) b.click(); });
  if (pfDone) pfDone.addEventListener("click", function () {
    pfDone.disabled = true;
    clearTimeout(timer);
    var finish = function () { pfDone.disabled = false; showProfileView("view"); };
    // make sure the latest bio / switch is saved before the preview is drawn
    var go = dirty || saving ? save() : Promise.resolve();
    go.then(function () { return dirty ? save() : null; }).then(finish, finish);
  });

  var t = $("toggleSettings");           // refresh whenever the panel opens (e.g. after switching account)
  if (t) t.addEventListener("click", function () { load(); showTab("profile"); showProfileView("view"); });
  var root = $("appRoot");               // and once the login finishes
  if (root) new MutationObserver(load).observe(root, { attributes: true, attributeFilter: ["class"] });
  upd();

  // the camera badge on the avatar opens the same file picker as "Choose photo"
  var cam = $("pfCam"), choose = $("avatarChoose");
  if (cam && choose) cam.addEventListener("click", function () { choose.click(); });
})();
