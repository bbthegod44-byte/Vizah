#!/usr/bin/env bash
# Stop the Vizah server started by launch.sh.
cd "$(dirname "$0")" || exit 1
if [ -f .server.pid ] && kill "$(cat .server.pid)" 2>/dev/null; then
  rm -f .server.pid
  echo "Vizah server stopped."
else
  pkill -f "python3 server.py" 2>/dev/null && echo "Vizah server stopped." || echo "Vizah server wasn't running."
fi
command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock
