#!/usr/bin/env bash
# Play/pause (and friends) for YouTube Music (or any media app) via adb, from Termux.
# Standalone: does not touch the visualizer files.
#
# Usage:
#   bash playpause.sh            # toggle play/pause
#   bash playpause.sh play
#   bash playpause.sh pause
#   bash playpause.sh next
#   bash playpause.sh prev
#
# If adb isn't already connected, set the address once, e.g.:
#   ADB_ADDR=127.0.0.1:5555 bash playpause.sh
# or save it:  echo "127.0.0.1:5555" > ~/.playpause_adb

ACTION="${1:-toggle}"

case "$ACTION" in
  toggle|playpause) KEY=85  ;;  # KEYCODE_MEDIA_PLAY_PAUSE
  play)             KEY=126 ;;  # KEYCODE_MEDIA_PLAY
  pause)            KEY=127 ;;  # KEYCODE_MEDIA_PAUSE
  next)             KEY=87  ;;  # KEYCODE_MEDIA_NEXT
  prev|previous)    KEY=88  ;;  # KEYCODE_MEDIA_PREVIOUS
  *) echo "Unknown action: $ACTION (use toggle|play|pause|next|prev)"; exit 1 ;;
esac

if ! command -v adb >/dev/null 2>&1; then
  echo "adb not found. Install it with:  pkg install android-tools"
  exit 1
fi

# Is a device already connected?
connected() { adb devices | awk 'NR>1 && $2=="device"{f=1} END{exit !f}'; }

if ! connected; then
  ADDR="${ADB_ADDR:-}"
  if [ -z "$ADDR" ] && [ -f "$HOME/.playpause_adb" ]; then
    ADDR="$(head -n1 "$HOME/.playpause_adb")"
  fi
  if [ -n "$ADDR" ]; then
    adb connect "$ADDR" >/dev/null 2>&1
  fi
fi

if ! connected; then
  echo "No adb device connected."
  echo "Turn on Wireless debugging, then run:"
  echo "  adb pair <ip>:<pairing-port>      (first time only)"
  echo "  adb connect <ip>:<port>"
  echo "Or save the address:  echo \"<ip>:<port>\" > ~/.playpause_adb"
  exit 1
fi

adb shell input keyevent "$KEY"
