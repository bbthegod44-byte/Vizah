In Termux (once): pkg install git
Then, from the project folder: bash install_fnf.sh
That downloads the game into this folder (games/fnf/index.html).
