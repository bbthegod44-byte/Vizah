#!/usr/bin/env bash
# Start the Vizah server (if it isn't already running) and open it as an app.
#   bash launch.sh            start + open
#   bash launch.sh --no-open  start only (used by Termux:Boot)
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
PORT="${PORT:-8000}"
# 127.0.0.1 (not the LAN address): browsers treat it as a secure context so the app is installable,
# and it's the address Spotify's redirect URI expects.
URL="http://127.0.0.1:$PORT/"
LOG="$HERE/server.log"
PIDFILE="$HERE/.server.pid"

healthy() {
  python3 - "$URL" <<'PY' >/dev/null 2>&1
import sys, urllib.request
urllib.request.urlopen(sys.argv[1] + "auth/me", timeout=2).read()
PY
}

if healthy; then
  echo "Vizah server already running on $URL"
else
  command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock   # keep the server alive with the screen off
  echo "Starting Vizah server on port $PORT ..."
  PORT="$PORT" nohup python3 server.py >>"$LOG" 2>&1 &
  echo $! > "$PIDFILE"
  for i in $(seq 1 30); do
    healthy && break
    sleep 0.5
  done
  if ! healthy; then
    echo "Server didn't come up. Last log lines:" >&2
    tail -n 15 "$LOG" >&2
    exit 1
  fi
  echo "Server is up."
fi

[ "$1" = "--no-open" ] && exit 0

open_app() {
  # Prefer Chrome (best PWA install support), then whatever the default browser is.
  if command -v am >/dev/null 2>&1; then
    for pkg in com.android.chrome com.chrome.beta com.brave.browser org.chromium.chrome; do
      out="$(am start -a android.intent.action.VIEW -d "$URL" -p "$pkg" 2>&1)"
      case "$out" in *Error*|*error*|*Exception*) ;; *) return 0 ;; esac
    done
    am start -a android.intent.action.VIEW -d "$URL" >/dev/null 2>&1 && return 0
  fi
  command -v termux-open-url >/dev/null 2>&1 && termux-open-url "$URL" && return 0
  return 1
}

if open_app; then
  echo "Opened $URL"
else
  echo "Couldn't open a browser automatically. Open this yourself: $URL"
fi
