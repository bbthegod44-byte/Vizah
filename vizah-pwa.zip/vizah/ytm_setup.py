#!/usr/bin/env python3
"""One-time setup for the Playlists section.

Usage:
    python3 ytm_setup.py cookie.txt       # file containing a copied cURL command, raw headers, or just the cookie
    python3 ytm_setup.py                  # or paste when asked (long cookies may get cut off - prefer the file)

Saves the login into creds.txt (next to this script; the page server never serves it).
"""
import hashlib
import json
import os
import re
import sys
import time

import creds

DEFAULT_UA = "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"


def parse_args():
    path, authuser = None, None
    args = sys.argv[1:]
    i = 0
    while i < len(args):
        if args[i] == "--authuser" and i + 1 < len(args):
            authuser = args[i + 1]
            i += 2
            continue
        if path is None:
            path = args[i]
        i += 1
    return path, authuser


def read_input(path):
    if path:
        path = os.path.expanduser(path)
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    print("Paste your cURL / headers / cookie, then press Enter.")
    print("(If it is very long, save it to a file and run: python3 ytm_setup.py yourfile.txt)")
    return sys.stdin.readline()


def _cookie_from_json(text):
    """Cookie-Editor / EditThisCookie style export: a JSON list of {name, value, domain...}."""
    try:
        data = json.loads(text)
    except Exception:
        return ""
    if isinstance(data, dict):
        data = data.get("cookies") or []
    if not isinstance(data, list):
        return ""
    pairs = {}
    for c in data:
        if not isinstance(c, dict) or not c.get("name"):
            continue
        dom = str(c.get("domain", "")).lower()
        if dom and "youtube.com" not in dom and "google." not in dom:
            continue
        pairs[c["name"]] = str(c.get("value", ""))
    return "; ".join("%s=%s" % kv for kv in pairs.items())


def _cookie_from_netscape(text):
    """cookies.txt export (tab separated: domain, flag, path, secure, expiry, name, value)."""
    pairs = {}
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("#HttpOnly_"):
            line = line[len("#HttpOnly_"):]
        elif not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) < 7:
            continue
        dom = parts[0].lower()
        if "youtube.com" not in dom and "google." not in dom:
            continue
        pairs[parts[5]] = parts[6]
    return "; ".join("%s=%s" % kv for kv in pairs.items())


def parse(text):
    text = (text or "").strip()
    if text[:1] in "[{":
        c = _cookie_from_json(text)
        if c:
            return {"cookie": c}
    if "\t" in text and "\n" in text:
        c = _cookie_from_netscape(text)
        if c:
            return {"cookie": c}
    text = text.replace("\\\n", " ").replace("^\n", " ").strip()
    headers = {}

    # curl: -H 'name: value'   (Chrome, Firefox, Safari "Copy as cURL (bash)")
    for m in re.finditer(r"""(?:-H|--header)\s+(['"])(.*?)\1""", text, re.S):
        line = m.group(2)
        if ":" in line:
            k, v = line.split(":", 1)
            headers[k.strip().lower()] = v.strip()

    # curl: -b 'cookie string'  (Chrome puts cookies here)
    m = re.search(r"""(?:-b|--cookie)\s+(['"])(.*?)\1""", text, re.S)
    if m and "cookie" not in headers:
        headers["cookie"] = m.group(2).strip()

    if not headers:
        # raw request headers, one "name: value" per line
        for line in text.splitlines():
            if ":" in line and not line.lstrip().startswith("curl"):
                k, v = line.split(":", 1)
                if re.match(r"^[A-Za-z0-9-]+$", k.strip()):
                    headers[k.strip().lower()] = v.strip()

    if "cookie" not in headers:
        # maybe the whole text is just the cookie value (Firefox: right-click Cookie -> Copy Value)
        raw = text.strip().strip("'\"` ")
        if raw.lower().startswith("cookie:"):
            raw = raw.split(":", 1)[1]
        raw = " ".join(raw.split())
        if "=" in raw and (";" in raw or "SAPISID=" in raw or "PAPISID=" in raw):
            headers["cookie"] = raw

    return headers


def sapisid_from(cookie):
    for name in ("__Secure-3PAPISID", "SAPISID", "__Secure-1PAPISID"):
        m = re.search(r"(?:^|;\s*)" + re.escape(name) + r"=([^;]+)", cookie)
        if m:
            return m.group(1)
    return ""


def make_authorization(cookie, origin):
    """The library only uses this to recognise a browser login and refreshes it per request."""
    sapisid = sapisid_from(cookie)
    if not sapisid:
        return ""
    ts = int(time.time())
    digest = hashlib.sha1(("%d %s %s" % (ts, sapisid, origin)).encode()).hexdigest()
    return "SAPISIDHASH %d_%s" % (ts, digest)


def store(authuser, base):
    """Saves the login for this account index into creds.txt."""
    creds.save_ytm(base.get("Cookie", ""), authuser, base.get("User-Agent", ""), base.get("Accept-Language", ""))


def check(authuser, base):
    """Tests the login for this account index (nothing is saved). Returns a result dict."""
    out = dict(base)
    out["X-Goog-AuthUser"] = str(authuser)
    from ytmusicapi import YTMusic
    res = {"authuser": str(authuser), "playlists": None, "liked": None, "account": "", "error": ""}
    try:
        yt = creds.open_ytmusic(YTMusic, out)
    except Exception as e:
        res["error"] = str(e)[:200]
        return res
    try:
        info = yt.get_account_info() or {}
        res["account"] = info.get("accountName") or ""
    except Exception:
        pass
    try:
        res["playlists"] = [p.get("title", "?") for p in (yt.get_library_playlists(limit=25) or [])]
    except Exception as e:
        res["error"] = str(e)[:200]
    try:
        res["liked"] = len((yt.get_liked_songs(limit=5) or {}).get("tracks", []) or [])
    except Exception:
        pass
    return res


def main():
    path, forced = parse_args()
    text = read_input(path)
    h = parse(text)
    cookie = h.get("cookie", "")
    if not cookie:
        print("Couldn't find a cookie in that. Copy the request as cURL (bash) from a")
        print("music.youtube.com request while logged in, and try again.")
        sys.exit(1)
    if "SAPISID" not in cookie:
        print("Warning: no SAPISID in that cookie - you may not be logged in, or it was cut off.")

    origin = "https://music.youtube.com"
    auth = h.get("authorization", "")
    if not auth.startswith("SAPISIDHASH"):
        auth = make_authorization(cookie, origin)

    base = {
        "User-Agent": h.get("user-agent", DEFAULT_UA),
        "Accept": "*/*",
        "Accept-Language": h.get("accept-language", "en-US,en;q=0.5"),
        "Content-Type": "application/json",
        "x-origin": origin,
        "origin": origin,
        "Cookie": cookie,
    }
    if auth:
        base["Authorization"] = auth

    try:
        import importlib.metadata as md
        print("ytmusicapi version:", md.version("ytmusicapi"))
    except Exception:
        pass
    try:
        import ytmusicapi  # noqa: F401
    except Exception:
        store(forced or h.get("x-goog-authuser", "0"), base)
        print("Saved to creds.txt")
        print("ytmusicapi isn't installed yet. Run: pip install ytmusicapi")
        return

    candidates = [forced] if forced else [h.get("x-goog-authuser", "0")] + [str(i) for i in range(0, 5)]
    tried, results = set(), []
    for au in candidates:
        if au in tried:
            continue
        tried.add(au)
        r = check(au, base)
        results.append(r)
        n = len(r["playlists"]) if r["playlists"] is not None else None
        print("Account index %s%s: %s playlists, %s liked songs%s" % (
            au,
            (" (" + r["account"] + ")") if r["account"] else "",
            "?" if n is None else n,
            "?" if r["liked"] is None else r["liked"],
            (" - " + r["error"]) if r["error"] else "",
        ))
        if (n or 0) > 0 or (forced and r["error"] == ""):
            break

    good = next((r for r in results if r["playlists"]), None)
    if good is None:
        good = next((r for r in results if r["liked"]), None)
    if good is None:
        good = results[0]
    store(good["authuser"], base)  # keep the best account's login
    print("Saved to creds.txt (account index %s)" % good["authuser"])

    if good["playlists"]:
        print("Login works. Playlists: " + ", ".join(good["playlists"][:5]) + (", ..." if len(good["playlists"]) > 5 else ""))
    elif good["liked"]:
        print("Login works (liked songs found) but no library playlists were returned.")
        print("That usually means ytmusicapi is out of date. Run: pip install -U ytmusicapi")
        print("then run this script again. Liked Music will still show on the page meanwhile.")
    else:
        print("The login works but no account returned any playlists or liked songs.")
        print("Try: python3 ytm_setup.py <file> --authuser N   (N = 0, 1, 2 ... the account with your playlists)")
        print("or re-export the cookie while logged in to the account that has them.")


def setup_from_text(text, forced=None):
    """Same job as main(), but quiet and importable (used by the page's setup screen).
    Returns {"ok", "playlists", "liked", "account", "error", "code"}."""
    h = parse(text or "")
    cookie = h.get("cookie", "")
    if not cookie:
        return {"ok": False, "error": "Couldn't find a cookie in that. Copy a music.youtube.com request as cURL (bash) while logged in."}
    if "SAPISID" not in cookie and "PAPISID" not in cookie:
        return {"ok": False, "error": "That has no YouTube login in it. Make sure you're logged in and copied the whole request."}
    if not re.search(r"(?:^|;\s*)(?:__Secure-[13]PSID|SID)=", cookie):
        return {"ok": False, "code": "partial_cookie",
                "error": "That cookie is missing the private session part (SID). Browsers hide it from "
                         "page scripts, so use the one-click helper or copy the request from DevTools > Network."}
    try:
        import ytmusicapi  # noqa: F401
    except Exception:
        return {"ok": False, "code": "not_installed", "error": "ytmusicapi isn't installed on the server. Run: pip install ytmusicapi"}

    origin = "https://music.youtube.com"
    auth = h.get("authorization", "")
    if not auth.startswith("SAPISIDHASH"):
        auth = make_authorization(cookie, origin)
    base = {
        "User-Agent": h.get("user-agent", DEFAULT_UA),
        "Accept": "*/*",
        "Accept-Language": h.get("accept-language", "en-US,en;q=0.5"),
        "Content-Type": "application/json",
        "x-origin": origin,
        "origin": origin,
        "Cookie": cookie,
    }
    if auth:
        base["Authorization"] = auth

    candidates = [forced] if forced else [h.get("x-goog-authuser", "0")] + [str(i) for i in range(0, 5)]
    tried, results = set(), []
    for au in candidates:
        if au in tried:
            continue
        tried.add(au)
        r = check(au, base)
        results.append(r)
        if (len(r["playlists"]) if r["playlists"] is not None else 0) > 0:
            break
    good = (next((r for r in results if r["playlists"]), None)
            or next((r for r in results if r["liked"]), None)
            or results[0])
    store(good["authuser"], base)  # keep the best account's login
    n = len(good["playlists"] or [])
    if n or good["liked"]:
        return {"ok": True, "playlists": n, "liked": good["liked"] or 0, "account": good["account"], "error": ""}
    return {"ok": False, "error": good["error"] or "Logged in, but no playlists or liked songs were found for that account."}


if __name__ == "__main__":
    main()
