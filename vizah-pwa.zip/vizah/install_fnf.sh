#!/usr/bin/env bash
# Downloads the Friday Night Funkin' web build into games/fnf so the arrow in the
# YouTube section can play it. Works in Termux and on regular Linux/macOS.
#
#   Termux first-time setup:   pkg install git
#   Then, in the project dir:  bash install_fnf.sh
#
# Needs about 2 GB free (the download is cleaned up afterwards, ~850 MB stays).
#
# NOTE: The game's art/music are owned by The Funkin' Crew Inc. and their license
# does not allow anyone else to publicly host them. Use this for private/personal
# use on your own device or network only. Don't put games/fnf on a public site.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
REPO="${FNF_REPO:-https://github.com/anime-kun32/Friday-Night-Funkin-html.git}"
DEST="${FNF_DEST:-$HERE/games/fnf}"

if ! command -v git >/dev/null 2>&1; then
  if command -v pkg >/dev/null 2>&1; then
    echo "git is missing. Install it with:  pkg install git   then run this again." >&2
  else
    echo "git is missing. Install git and run this again." >&2
  fi
  exit 1
fi

# Work in the home folder: on Termux, shared storage (/storage/emulated/0) breaks git.
WORK="${FNF_WORK:-$HOME/.fnf_download}"
rm -rf "$WORK"
mkdir -p "$WORK"
trap 'rm -rf "$WORK"' EXIT

echo "Downloading (about 1.6 GB, this can take a while on mobile data - use Wi-Fi)..."
git clone --depth 1 --progress "$REPO" "$WORK/repo"
if [ ! -f "$WORK/repo/html5_build/index.html" ]; then
  echo "Could not find html5_build/index.html in the download." >&2
  exit 1
fi
rm -rf "$WORK/repo/.git"          # frees ~800 MB before copying

echo "Copying the game into $DEST ..."
rm -rf "$DEST"
mkdir -p "$DEST"
cp -r "$WORK/repo/html5_build/." "$DEST/"
if [ ! -f "$DEST/index.html" ]; then
  echo "Copy failed (out of space?). Free some storage and try again." >&2
  exit 1
fi
COUNT=$(find "$DEST" -type f | wc -l)
echo "Copied $COUNT files (a complete install has 2037)."
if [ "$COUNT" -lt 2037 ]; then
  echo "WARNING: some files are missing. Free up storage and run this again, or the game will get stuck loading." >&2
fi
echo
echo "Done. Start the server with:  bash start.sh"
echo "Then open http://localhost:8000 in your browser, open the arrow in the YouTube section and press Play."
