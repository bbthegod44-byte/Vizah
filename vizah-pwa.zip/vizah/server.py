import json
import os
import creds
import sys
try:
    import social  # direct messages + friend profiles (added)
except Exception as _e:  # the rest of the server keeps working without it
    social = None
    print("Warning: social.py not loaded:", _e)
try:
    import spotify  # Spotify playback + playlists (added)
except Exception as _e:  # YouTube Music keeps working without it
    spotify = None
    print("Warning: spotify.py not loaded:", _e)
try:
    import lyrics_src  # extra synced-lyrics sources (added)
except Exception as _e:  # lyrics keep working from the page's own sources without it
    lyrics_src = None
    print("Warning: lyrics_src.py not loaded:", _e)
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

CONFIG_FILE = "config.json"
PORT = int(os.environ.get("PORT", "8000"))

def load_config():
    if not os.path.exists(CONFIG_FILE):
        return {}
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_config(data):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

import re
import subprocess
import threading
import time

MEDIA_ACTIONS = {
    # action: (cmd media_session name, adb keycode)
    "playpause": ("play-pause", "85"),
    "play": ("play", "126"),
    "pause": ("pause", "127"),
    "next": ("next", "87"),
    "prev": ("previous", "88"),
}
_adb_lock = threading.Lock()

def playback_provider():
    """Which service plays music: 'youtube' (adb / YouTube Music) or 'spotify'.

    An explicit choice in Settings wins. Otherwise we keep the old behaviour for
    anyone who already connected YouTube Music, and only fall back to Spotify
    when that is the one that is connected."""
    p = (creds.get("playback_provider") or "").strip().lower()
    if p == "spotify" and spotify is not None and spotify.connected():
        return "spotify"
    if p == "youtube":
        return "youtube"
    if creds.has("ytm_cookie"):
        return "youtube"
    if spotify is not None and spotify.connected():
        return "spotify"
    return "youtube"

def _adb(args, timeout=10):
    return subprocess.run(["adb"] + args, capture_output=True, text=True, timeout=timeout)

def _adb_device_state():
    """Returns (state, detail): state is 'device', 'offline', 'unauthorized', or None."""
    lines = _adb(["devices"]).stdout.splitlines()[1:]
    found = None
    for l in lines:
        parts = l.split()
        if len(parts) >= 2:
            if parts[1] == "device":
                return "device", parts[0]
            found = (parts[1], parts[0])
    return found if found else (None, "")

def adb_ensure():
    """Make sure a device is connected, trying a saved address once. Returns (ok, error)."""
    try:
        state, _ = _adb_device_state()
        if state != "device":
            addr = os.environ.get("ADB_ADDR", "")
            f = os.path.expanduser("~/.playpause_adb")
            if not addr and os.path.exists(f):
                with open(f, "r", encoding="utf-8") as fh:
                    addr = fh.readline().strip()
            if addr:
                _adb(["connect", addr])
                state, _ = _adb_device_state()
        if state == "device":
            return True, ""
        if state in ("offline", "unauthorized"):
            return False, "device " + state
        return False, "no adb device connected"
    except FileNotFoundError:
        return False, "adb not installed or broken"
    except Exception as e:
        return False, str(e)

def get_media():
    """Reads the media app's session from the phone. Returns a dict or None:
    {playing, state, position (ms, as of right now), speed, desc, package}"""
    t_start = time.time()
    try:
        out = _adb(["shell", "cat /proc/uptime; dumpsys media_session"]).stdout
    except Exception:
        return None
    lines = out.splitlines()
    uptime_ms = None
    if lines:
        try:
            uptime_ms = float(lines[0].split()[0]) * 1000.0
        except Exception:
            uptime_ms = None

    blocks = []
    cur = None
    for line in lines:
        m = re.search(r"^\s*package=(\S+)", line)
        if m:
            cur = {"package": m.group(1)}
            blocks.append(cur)
            continue
        if cur is None:
            continue
        if "state" not in cur and "PlaybackState" in line:
            ms = re.search(r"PlaybackState\s*\{state=(?:[A-Za-z_]+\()?(\d+)", line)
            if ms:
                cur["state"] = int(ms.group(1))
                mp = re.search(r"position=(\d+)", line)
                cur["position"] = int(mp.group(1)) if mp else 0
                msp = re.search(r"speed=(-?[\d.]+)", line)
                cur["speed"] = float(msp.group(1)) if msp else 1.0
                mu = re.search(r"updated=(\d+)", line)
                cur["updated"] = int(mu.group(1)) if mu else None
        if "desc" not in cur:
            md = re.search(r"metadata:.*?description=(.*)$", line)
            if md:
                cur["desc"] = md.group(1).strip()

    # keep the first block per package (the system lists the top session first)
    seen, sessions = set(), []
    for blk in blocks:
        if blk["package"] in seen or "state" not in blk:
            continue
        seen.add(blk["package"])
        sessions.append(blk)
    if not sessions:
        return None
    pick = next((x for x in sessions if "youtube.music" in x["package"]), sessions[0])

    state = pick["state"]
    pos = pick.get("position", 0)
    speed = pick.get("speed", 1.0)
    if state in (3, 4, 6) and uptime_ms is not None and pick.get("updated") is not None:
        delta = uptime_ms - pick["updated"]
        if 0 <= delta < 600000:
            pos = pos + delta * (speed if speed > 0 else 1.0)
            # the clock was read when the adb command started; the command itself took a moment,
            # so the song has moved on by now - without this the lyrics/progress trail by that time (added)
            pos = pos + min(3.0, max(0.0, time.time() - t_start - 0.15)) * 1000.0 * (speed if speed > 0 else 1.0)
    return {
        "playing": state in (3, 4, 6),
        "state": state,
        "position": int(max(0, pos)),
        "speed": speed,
        "desc": pick.get("desc", ""),
        "package": pick["package"],
    }

def get_playing():
    m = get_media()
    return None if m is None else m["playing"]

def media_status():
    if playback_provider() == "spotify" and spotify is not None:
        return spotify.media_status()
    ok, err = adb_ensure()
    if not ok:
        return {"connected": False, "playing": None, "error": err}
    m = get_media()
    if m is None:
        return {"connected": True, "playing": None, "error": ""}
    m["connected"] = True
    m["error"] = ""
    return m

def media_action(action):
    """Returns (ok, error, media_dict_or_None)."""
    if playback_provider() == "spotify" and spotify is not None:
        return spotify.media_action(action)
    if action not in MEDIA_ACTIONS:
        return False, "unknown action", None
    with _adb_lock:
        ok, err = adb_ensure()
        if not ok:
            return False, err, None
        try:
            effective = action
            before = None
            if action == "playpause":
                before = get_media()
                if before is not None:
                    effective = "pause" if before["playing"] else "play"
            cmd_name, key = MEDIA_ACTIONS[effective]
            want = {"play": True, "pause": False}.get(effective)

            # unknown state or next/prev: just send the key once
            if want is None:
                r = _adb(["shell", "input", "keyevent", key])
                if r.returncode != 0:
                    return False, (r.stderr or r.stdout or "adb error").strip(), None
                return True, "", None

            attempts = [
                ["shell", "cmd", "media_session", "dispatch", cmd_name],
                ["shell", "input", "keyevent", key],
                ["shell", "input", "keyevent", MEDIA_ACTIONS["playpause"][1]],
            ]
            media = before
            for a in attempts:
                _adb(a)
                time.sleep(0.8)
                media = get_media()
                if media is None or media["playing"] == want:
                    return True, "", media
            return False, "command sent but playback did not change", media
        except Exception as e:
            return False, str(e), None

# ---------- YouTube Music playlists (added) ----------
YTM_AUTH = os.environ.get("YTM_AUTH") or os.path.expanduser("~/.ytmusic_browser.json")
YTM_PKG = "com.google.android.apps.youtube.music"
_ID_RE = re.compile(r"^[A-Za-z0-9_-]{2,80}$")
_ytm = None
_ytm_lock = threading.Lock()
_pl_cache = {"t": 0.0, "data": None}

_ytm_user = None   # which account the cached client above was built for

def get_ytm():
    """Returns (client, code, message). code is '' on success."""
    global _ytm, _ytm_user
    if _ytm is not None and _ytm_user == creds.get_user():
        return _ytm, "", ""
    _ytm = None
    try:
        from ytmusicapi import YTMusic
    except Exception:
        return None, "not_installed", "ytmusicapi is not installed"
    headers = creds.ytm_headers()
    if not headers:
        return None, "not_setup", "not set up yet"
    try:
        _ytm = creds.open_ytmusic(YTMusic, headers)
        _ytm_user = creds.get_user()
        return _ytm, "", ""
    except Exception as e:
        return None, "auth", "auth file problem: %s" % e

def _list_playlists_yt(force=False):
    with _ytm_lock:
        if not force and _pl_cache["data"] is not None and time.time() - _pl_cache["t"] < 300:
            return {"ok": True, "playlists": _pl_cache["data"], "code": "", "error": ""}
        yt, code, msg = get_ytm()
        if yt is None:
            return {"ok": False, "playlists": [], "code": code, "error": msg}
        try:
            items = [{"id": "LM", "title": "Liked Music", "count": "", "thumb": ""}]
            seen = {"LM"}
            for p in (yt.get_library_playlists(limit=200) or []):
                pid = p.get("playlistId")
                if not pid or pid in seen:
                    continue
                seen.add(pid)
                th = p.get("thumbnails") or []
                items.append({
                    "id": pid,
                    "title": p.get("title") or "Untitled",
                    "count": str(p.get("count") or ""),
                    "thumb": (th[-1].get("url", "") if th else ""),
                })
            _pl_cache["t"] = time.time()
            _pl_cache["data"] = items
            return {"ok": True, "playlists": items, "code": "", "error": ""}
        except Exception as e:
            global _ytm
            _ytm = None
            text = str(e)
            low = text.lower()
            if any(k in low for k in ("401", "403", "unauthorized", "sign in", "log in", "forbidden")):
                return {"ok": False, "playlists": [], "code": "auth", "error": "login expired"}
            return {"ok": False, "playlists": [], "code": "error", "error": text[:200]}

def list_playlists(force=False):
    """Playlists for the active playback provider (YouTube Music or Spotify)."""
    if playback_provider() == "spotify" and spotify is not None:
        res = spotify.playlists(force)
        res["provider"] = "spotify"
        return res
    res = _list_playlists_yt(force)
    res["provider"] = "youtube"
    return res

_yt_acct = {"t": 0.0, "data": None}
_YT_PHOTO_HOSTS = ("googleusercontent.com", "ggpht.com", "ytimg.com", "gstatic.com")

def _safe_photo(url):
    """Only https pictures from Google's own image hosts, sized for an avatar."""
    try:
        u = urlparse(url or "")
    except Exception:
        return ""
    host = (u.hostname or "").lower()
    if u.scheme != "https" or not any(host == h or host.endswith("." + h) for h in _YT_PHOTO_HOSTS):
        return ""
    return re.sub(r"=s\d+[^?#\s]*$", "=s176-c-k-c0x00ffffff-no-rj", url)

def youtube_account(force=False):
    """Who the saved YouTube Music login belongs to: name, @handle and profile picture."""
    global _ytm
    with _ytm_lock:
        if not force and _yt_acct["data"] is not None and time.time() - _yt_acct["t"] < 600:
            return _yt_acct["data"]
        yt, code, msg = get_ytm()
        if yt is None:
            if code == "not_setup":
                return {"ok": True, "connected": False, "code": "", "error": "", "name": "", "handle": "", "photo": ""}
            return {"ok": True, "connected": creds.has("ytm_cookie"), "code": code, "error": msg,
                    "name": "", "handle": "", "photo": ""}
        try:
            info = yt.get_account_info() or {}
        except Exception as e:
            _ytm = None
            text = str(e)
            low = text.lower()
            expired = any(k in low for k in ("401", "403", "unauthorized", "sign in", "log in", "forbidden"))
            return {"ok": True, "connected": True, "code": "auth" if expired else "error",
                    "error": "login expired" if expired else text[:200], "name": "", "handle": "", "photo": ""}
        res = {"ok": True, "connected": True, "code": "", "error": "",
               "name": str(info.get("accountName") or "")[:100],
               "handle": str(info.get("channelHandle") or "")[:100],
               "photo": _safe_photo(info.get("accountPhotoUrl") or "")}
        _yt_acct["t"] = time.time()
        _yt_acct["data"] = res
        return res

def youtube_disconnect():
    """Forgets the saved YouTube Music login (the cookie) on the server."""
    global _ytm
    with _ytm_lock:
        for k in ("ytm_cookie", "ytm_authuser", "ytm_user_agent", "ytm_language"):
            try:
                creds.delete(k)
            except Exception:
                pass
        _ytm = None
        _pl_cache["data"] = None
        _pl_cache["t"] = 0.0
        _yt_acct["data"] = None
    try:
        _tracks_cache.clear()
        _ctx.update({"pid": None, "tracks": [], "ready": False, "last": 0})
    except Exception:
        pass

def _play_playlist_yt(pid, video=None, index=None):
    """Starts a playlist in YouTube Music on the phone via adb. Returns (ok, error).
    video / index (optional): start from that song of the playlist instead of the first one."""
    if not _ID_RE.match(pid or ""):
        return False, "bad playlist id"
    if video is not None and not _ID_RE.match(video):
        return False, "bad song id"
    ok, err = adb_ensure()
    if not ok:
        return False, "phone not connected (%s)" % err
    if video is None:
        yt, _, _ = get_ytm()
        if yt is not None:
            try:
                data = yt.get_playlist(pid, limit=1)
                for t in (data.get("tracks") or []):
                    v = t.get("videoId")
                    if v and _ID_RE.match(v):
                        video = v
                        break
            except Exception:
                video = None
    if video:
        url = "https://music.youtube.com/watch?v=%s&list=%s" % (video, pid)
        if isinstance(index, int) and 0 <= index < 5000:
            url += "&index=%d" % (index + 1)
    else:
        url = "https://music.youtube.com/playlist?list=%s" % pid
    try:
        # The whole command is one string: the phone's shell would split on '&' otherwise.
        # "Activity not started" usually means the explicit-package intent didn't resolve, so
        # try a few launch styles in turn (package-only, YTM's own activity, any app that
        # handles the link, then the YouTube Music deep link scheme).
        base = "am start -a android.intent.action.VIEW -c android.intent.category.BROWSABLE -d '%s'" % url
        attempts = [
            base + " -p " + YTM_PKG,
            base + " -n " + YTM_PKG + "/com.google.android.apps.youtube.music.activities.MusicActivity",
            base,
            "am start -a android.intent.action.VIEW -d '%s'" % url.replace("https://", "vnd.youtube.music://", 1),
        ]
        last = ""
        launched = False
        for cmd in attempts:
            r = _adb(["shell", cmd])
            out = ((r.stdout or "") + (r.stderr or "")).strip()
            if r.returncode == 0 and "Error" not in out and "Exception" not in out:
                launched = True
                break
            last = out or "adb error"
        if not launched:
            return False, last[:200]
        _status_cache["data"] = None
        _start_ctx_load(pid, start=index if isinstance(index, int) else 0)
        return True, ""
    except Exception as e:
        return False, str(e)

def play_playlist(pid, video=None, index=None):
    """Starts a playlist in whichever service is active. Returns (ok, error)."""
    if str(pid or "").startswith("sp_"):
        if spotify is None:
            return False, "spotify.py is missing on the server"
        ok, err = spotify.play_playlist(pid, video, index)
        if ok:
            _status_cache["data"] = None
            _start_ctx_load(pid, start=index if isinstance(index, int) else 0)
        return ok, err
    if playback_provider() == "spotify" and spotify is not None:
        return False, "that playlist isn't on Spotify"
    return _play_playlist_yt(pid, video, index)

def add_to_playlist(pid, song_id="", title="", artist=""):
    """Adds a song to one of the user's playlists (YouTube Music or Spotify).
    The playlist id decides the service. If the song came from the other service (or only
    its name is known, like the song playing on the phone) it is looked up by title + artist.
    Returns (ok, error, code)."""
    pid = str(pid or "").strip()
    song_id = str(song_id or "").strip()
    title = str(title or "").strip()[:200]
    artist = str(artist or "").strip()[:200]
    q = ("%s %s" % (title, artist)).strip()[:100]
    if not pid:
        return False, "pick a playlist", "error"
    if pid.startswith("sp_"):
        if spotify is None:
            return False, "spotify.py is missing on the server", "not_installed"
        if not spotify.connected():
            return False, "Connect Spotify in Profile & connections first", "not_setup"
        tid = song_id if song_id.startswith("sp_") else ""
        if not tid:
            if not q:
                return False, "no song to add", "error"
            res = spotify.search(q)
            if not res.get("ok"):
                return False, res.get("error") or "couldn't look the song up on Spotify", res.get("code") or "error"
            if not res.get("results"):
                return False, "couldn't find that song on Spotify", "notfound"
            tid = res["results"][0]["id"]
        return spotify.add_to_playlist(pid, tid)
    # ---- YouTube Music ----
    if not _ID_RE.match(pid):
        return False, "bad playlist id", "error"
    vid = song_id if (_ID_RE.match(song_id) and not song_id.startswith("sp_")) else ""
    if not vid:
        if not q:
            return False, "no song to add", "error"
        res = _ytm_search_yt(q)
        if not res.get("ok"):
            return False, {"not_setup": "Run ytm_setup.py on the server first",
                           "not_installed": "ytmusicapi isn't installed on the server",
                           "auth": "Your YouTube Music login expired. Run ytm_setup.py again"}.get(res.get("code"), res.get("error") or "search failed"), res.get("code") or "error"
        if not res.get("results"):
            return False, "couldn't find that song on YouTube Music", "notfound"
        vid = res["results"][0]["id"]
    global _ytm
    with _ytm_lock:
        yt, code, msg = get_ytm()
        if yt is None:
            return False, {"not_setup": "Run ytm_setup.py on the server first",
                           "not_installed": "ytmusicapi isn't installed on the server"}.get(code, msg), code
        try:
            if pid == "LM":
                yt.rate_song(vid, "LIKE")
                out = {"status": "STATUS_SUCCEEDED"}
            else:
                out = yt.add_playlist_items(pid, [vid], duplicates=False)
        except Exception as e:
            _ytm = None
            text = str(e)
            low = text.lower()
            if any(k in low for k in ("401", "403", "unauthorized", "sign in", "log in", "forbidden")):
                return False, "Your YouTube Music login expired, or that playlist isn't yours to edit", "auth"
            return False, text[:200] or "YouTube Music refused that", "error"
    status = str((out or {}).get("status", "")) if isinstance(out, dict) else ""
    if "SUCCEEDED" in status or (isinstance(out, dict) and not status):
        _pl_cache.update({"t": 0.0, "data": None})
        with _tracks_lock:
            _tracks_cache.clear()
        return True, "", ""
    return False, "Couldn't add it - it may already be in that playlist", "duplicate"

# ---------- YouTube Music song search + play one song (added) ----------
def _ytm_search_yt(q):
    """Searches YouTube Music for songs. Returns {ok, code, error, results:[{id,title,artist,thumb}]}."""
    q = (q or "").strip()[:100]
    if not q:
        return {"ok": True, "code": "", "error": "", "results": []}
    global _ytm
    with _ytm_lock:
        yt, code, msg = get_ytm()
        if yt is None:
            return {"ok": False, "code": code, "error": msg, "results": []}
        try:
            raw = yt.search(q, filter="songs", limit=12) or []
        except Exception as e:
            _ytm = None
            text = str(e)
            low = text.lower()
            if any(k in low for k in ("401", "403", "unauthorized", "sign in", "log in", "forbidden")):
                return {"ok": False, "code": "auth", "error": "login expired", "results": []}
            return {"ok": False, "code": "error", "error": text[:200], "results": []}
    out = []
    for r in raw:
        vid = r.get("videoId")
        if not vid or not _ID_RE.match(vid):
            continue
        th = r.get("thumbnails") or []
        arts = r.get("artists") or []
        out.append({
            "id": vid,
            "title": r.get("title") or "Untitled",
            "artist": ", ".join(a.get("name", "") for a in arts if a.get("name"))[:120],
            "thumb": (th[0].get("url", "") if th else ""),
            "duration": r.get("duration") or "",
        })
    return {"ok": True, "code": "", "error": "", "results": out}

def _play_song_yt(video):
    """Opens one song in YouTube Music on the phone via adb. Returns (ok, error)."""
    if not _ID_RE.match(video or ""):
        return False, "bad song id"
    ok, err = adb_ensure()
    if not ok:
        return False, "phone not connected (%s)" % err
    url = "https://music.youtube.com/watch?v=%s" % video
    try:
        base = "am start -a android.intent.action.VIEW -c android.intent.category.BROWSABLE -d '%s'" % url
        attempts = [
            base + " -p " + YTM_PKG,
            base + " -n " + YTM_PKG + "/com.google.android.apps.youtube.music.activities.MusicActivity",
            base,
            "am start -a android.intent.action.VIEW -d '%s'" % url.replace("https://", "vnd.youtube.music://", 1),
        ]
        last = ""
        for cmd in attempts:
            r = _adb(["shell", cmd])
            out = ((r.stdout or "") + (r.stderr or "")).strip()
            if r.returncode == 0 and "Error" not in out and "Exception" not in out:
                _status_cache["data"] = None
                return True, ""
            last = out or "adb error"
        return False, last[:200]
    except Exception as e:
        return False, str(e)

def ytm_search(q):
    """Song search for the active provider. Keeps the old /ytm/search route working."""
    if playback_provider() == "spotify" and spotify is not None:
        return spotify.search(q)
    return _ytm_search_yt(q)

def play_song(video):
    """Plays one song in the active provider. Returns (ok, error)."""
    if str(video or "").startswith("sp_"):
        if spotify is None:
            return False, "spotify.py is missing on the server"
        ok, err = spotify.play_song(video)
        if ok:
            _status_cache["data"] = None
            _ctx.update({"pid": None, "user": creds.get_user(), "tracks": [], "ready": False, "last": 0})
        return ok, err
    if playback_provider() == "spotify" and spotify is not None:
        return False, "that song isn't on Spotify - search for it instead"
    return _play_song_yt(video)

def music_play(media_id, track="", artist=""):
    """Plays a shared song on the recipient's own provider.

    If the id already belongs to the active service it is used directly; a song
    that came from the other service is looked up by title + artist first."""
    provider = playback_provider()
    media_id = str(media_id or "")
    q = ("%s %s" % (track or "", artist or "")).strip()[:100]
    if provider == "spotify" and spotify is not None:
        if media_id.startswith("sp_"):
            return spotify.play_song(media_id)
        if not q:
            return False, "no song to play"
        r = spotify.search(q)
        if r.get("ok") and r.get("results"):
            return spotify.play_song(r["results"][0]["id"])
        if not r.get("ok"):
            return False, r.get("error") or "Spotify search failed"
        return False, "Couldn't find that song on Spotify"
    if not media_id.startswith("sp_"):
        return _play_song_yt(media_id)
    if not q:
        return False, "no song to play"
    r = _ytm_search_yt(q)
    if r.get("ok") and r.get("results"):
        return _play_song_yt(r["results"][0]["id"])
    if not r.get("ok"):
        return False, r.get("error") or "YouTube Music search failed"
    return False, "Couldn't find that song on YouTube Music"

# ---------- first-run setup checks (added) ----------
_ADDR_RE = re.compile(r"^[A-Za-z0-9.\-]{1,100}:\d{2,5}$")
_CODE_RE = re.compile(r"^\d{4,8}$")

def setup_status():
    with _adb_lock:
        ok, err = adb_ensure()
    try:
        import importlib.util
        installed = importlib.util.find_spec("ytmusicapi") is not None
    except Exception:
        installed = False
    return {"ok": True,
            "adb": {"connected": bool(ok), "error": "" if ok else err},
            "playlists": {"ready": creds.has("ytm_cookie"), "installed": installed},
            "spotify": {"configured": bool(spotify and spotify.configured()),
                        "connected": bool(spotify and spotify.connected())},
            "provider": playback_provider()}

def setup_adb(addr, pair_addr="", code=""):
    """Optionally pairs, then connects to the phone's wireless-debugging address and remembers it."""
    try:
        with _adb_lock:
            if pair_addr or code:
                if not _ADDR_RE.match(pair_addr or "") or not _CODE_RE.match(code or ""):
                    return False, "Pairing needs the pairing address (ip:port) and the 6-digit code"
                r = _adb(["pair", pair_addr, code], timeout=25)
                out = ((r.stdout or "") + (r.stderr or "")).strip()
                if "successfully paired" not in out.lower():
                    return False, ("Pairing failed: " + (out or "no answer"))[:200]
            if not _ADDR_RE.match(addr or ""):
                return False, "Enter the connection address like 192.168.1.5:37000"
            r = _adb(["connect", addr], timeout=20)
            out = ((r.stdout or "") + (r.stderr or "")).strip()
            state, _ = _adb_device_state()
            if state != "device":
                if state == "unauthorized":
                    return False, "Phone says unauthorized - accept the prompt on the phone"
                return False, (out or "Could not connect")[:200]
            try:
                with open(os.path.expanduser("~/.playpause_adb"), "w", encoding="utf-8") as fh:
                    fh.write(addr + "\n")
            except Exception:
                pass
        _status_cache["data"] = None
        return True, ""
    except FileNotFoundError:
        return False, "adb isn't installed on the server (pkg install android-tools)"
    except subprocess.TimeoutExpired:
        return False, "Timed out talking to the phone"
    except Exception as e:
        return False, str(e)[:200]

def setup_playlists(text):
    global _ytm
    try:
        import ytm_setup
    except Exception as e:
        return {"ok": False, "error": "ytm_setup.py is missing: %s" % e}
    with _ytm_lock:
        try:  # one YouTube login per Vizah account (added)
            if creds.cookie_owner(ytm_setup.parse(text or "").get("cookie", ""), creds.get_user()):
                return {"ok": False, "code": "cookie_in_use", "error": creds.IN_USE_MSG}
        except Exception:
            pass
        try:
            res = ytm_setup.setup_from_text(text)
        except Exception as e:
            return {"ok": False, "error": str(e)[:200]}
        _ytm = None
        _pl_cache["data"] = None
        _yt_acct["data"] = None
    return res

# ---------- YouTube search (official Data API v3, added) ----------
import urllib.error
import urllib.request
import urllib.parse as _up

_YT_KEY_RE = re.compile(r"^[A-Za-z0-9_-]{20,80}$")

def yt_key():
    k = (creds.get("yt_api_key") or os.environ.get("YT_API_KEY") or "").strip()
    return k if _YT_KEY_RE.match(k) else ""

def _yt_call(endpoint, params, key):
    params = dict(params, key=key)
    url = "https://www.googleapis.com/youtube/v3/%s?%s" % (endpoint, _up.urlencode(params))
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            return json.loads(r.read().decode("utf-8")), ""
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read().decode("utf-8"))
            msg = (body.get("error") or {}).get("message") or ""
            reasons = [x.get("reason", "") for x in (body.get("error") or {}).get("errors", [])]
        except Exception:
            msg, reasons = "", []
        if "quotaExceeded" in reasons:
            return None, "quota"
        if e.code in (400, 403) and any(r in ("keyInvalid", "API_KEY_INVALID", "forbidden", "accessNotConfigured") for r in reasons + [msg]):
            return None, "key"
        if e.code in (400, 403) and ("API key" in msg or "not been used" in msg or "disabled" in msg):
            return None, "key"
        return None, "error: %s" % (msg or e.code)
    except Exception as e:
        return None, "error: could not reach YouTube (%s)" % type(e).__name__

def _walk_renderers(node, name, out):
    """Collects every dict stored under `name` anywhere in the response (layout-proof)."""
    if isinstance(node, dict):
        for k, v in node.items():
            if k == name and isinstance(v, dict):
                out.append(v)
            else:
                _walk_renderers(v, name, out)
    elif isinstance(node, list):
        for v in node:
            _walk_renderers(v, name, out)

def _runs_text(obj):
    if not isinstance(obj, dict):
        return ""
    if obj.get("simpleText"):
        return str(obj["simpleText"])
    return "".join(str(r.get("text", "")) for r in (obj.get("runs") or []) if isinstance(r, dict))

def parse_web_search(data):
    found = []
    _walk_renderers(data, "videoRenderer", found)
    items, seen = [], set()
    for v in found:
        vid = v.get("videoId")
        if not vid or vid in seen or not _ID_RE.match(vid):
            continue
        seen.add(vid)
        by = _runs_text(v.get("ownerText")) or _runs_text(v.get("longBylineText"))
        length = _runs_text(v.get("lengthText"))
        items.append({"id": vid, "title": _runs_text(v.get("title")),
                      "channel": (by + (" \u00b7 " + length if length else "")).strip(),
                      "thumb": "https://i.ytimg.com/vi/%s/mqdefault.jpg" % vid,
                      "art": "https://i.ytimg.com/vi/%s/maxresdefault.jpg" % vid})
    return items

def yt_search_web(q):
    """Regular YouTube search with no API key: the same request youtube.com's own search box
    makes. Unofficial, so YouTube can change it; playback still goes through the official embed."""
    body = json.dumps({
        "context": {"client": {"clientName": "WEB", "clientVersion": "2.20250101.00.00", "hl": "en", "gl": "US"}},
        "query": q,
        "params": "EgIQAQ%3D%3D",   # videos only
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://www.youtube.com/youtubei/v1/search?prettyPrint=false", data=body, method="POST",
        headers={"Content-Type": "application/json", "Origin": "https://www.youtube.com",
                 "Referer": "https://www.youtube.com/",
                 "Accept-Language": "en-US,en;q=0.9",
                 "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"})
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            data = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        print("YouTube web search failed: HTTP", e.code)
        return {"ok": False, "code": "error", "error": "YouTube answered with an error (%s). Try again, or add an API key." % e.code, "items": []}
    except Exception as e:
        print("YouTube web search failed:", repr(e)[:300])
        return {"ok": False, "code": "error", "error": "Could not reach YouTube from the server (%s)" % type(e).__name__, "items": []}
    items = parse_web_search(data)
    if not items:
        print("YouTube web search: no videos found in the response (layout may have changed)")
    return {"ok": True, "code": "", "error": "", "items": items}

def yt_search(q):
    key = yt_key()
    q = (q or "").strip()[:100]
    if not q:
        return {"ok": True, "code": "", "error": "", "items": []}
    if not key:
        return yt_search_web(q)
    data, err = _yt_call("search", {"part": "snippet", "type": "video", "maxResults": 20, "q": q,
                                    "videoEmbeddable": "true", "safeSearch": "none"}, key)
    if data is None:
        if err in ("quota", "key"):
            return yt_search_web(q)     # key problem: fall back to the keyless search
        msg = {"quota": "Daily YouTube search quota used up - try again tomorrow",
               "key": "YouTube rejected the API key (is YouTube Data API v3 enabled for it?)"}.get(err, err)
        return {"ok": False, "code": err if err in ("quota", "key") else "error", "error": msg, "items": []}
    items = []
    for it in data.get("items", []):
        vid = (it.get("id") or {}).get("videoId")
        sn = it.get("snippet") or {}
        if not vid or not _ID_RE.match(vid):
            continue
        th = sn.get("thumbnails") or {}
        thumb = (th.get("medium") or th.get("default") or {}).get("url", "")
        items.append({"id": vid, "title": sn.get("title", ""), "channel": sn.get("channelTitle", ""), "thumb": thumb})
    return {"ok": True, "code": "", "error": "", "items": items}

# ---------- YouTube subscriptions + "who posted" (added) ----------
# Subscriptions come from the saved YouTube login (the same cookie as the YouTube Music card),
# using the request youtube.com's own "Subscriptions" page makes. Unofficial, so YouTube can
# change it. "Posted" comes from each channel's public upload feed (no login needed).
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, wait as _fwait
from datetime import datetime

_CHAN_RE = re.compile(r"^UC[A-Za-z0-9_-]{22}$")
_subs_cache = {"t": 0.0, "data": None}
_subs_lock = threading.Lock()
_rss_cache = {}          # channel id -> (time, {"latest": epoch, "videos": [...]})
_YT_UA = "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"

def _walk(o):
    stack = [o]
    while stack:
        x = stack.pop()
        if isinstance(x, dict):
            yield x
            stack.extend(reversed(list(x.values())))
        elif isinstance(x, list):
            stack.extend(reversed(x))

def _text_of(t):
    if not isinstance(t, dict):
        return ""
    if t.get("simpleText"):
        return str(t["simpleText"])
    return "".join(str(r.get("text", "")) for r in (t.get("runs") or []) if isinstance(r, dict))

def parse_subscriptions(data):
    """Channels (id, title, photo) and the next-page token from a browse response."""
    chans, seen, token = [], set(), ""
    for d in _walk(data):
        for key in ("channelRenderer", "gridChannelRenderer"):
            r = d.get(key)
            if not isinstance(r, dict):
                continue
            cid = r.get("channelId") or ""
            if not _CHAN_RE.match(cid) or cid in seen:
                continue
            seen.add(cid)
            th = (r.get("thumbnail") or {}).get("thumbnails") or []
            url = (th[-1].get("url", "") if th and isinstance(th[-1], dict) else "")
            if url.startswith("//"):
                url = "https:" + url
            chans.append({"id": cid, "title": _text_of(r.get("title"))[:80], "photo": _safe_photo(url)})
        c = d.get("continuationItemRenderer")
        if isinstance(c, dict) and not token:
            token = (((c.get("continuationEndpoint") or {}).get("continuationCommand") or {}).get("token")) or ""
    return chans, token

def _yt_browse(body, cookie):
    origin = "https://www.youtube.com"
    headers = {"Content-Type": "application/json", "Origin": origin, "Referer": origin + "/",
               "X-Origin": origin, "Accept-Language": "en-US,en;q=0.9", "User-Agent": creds.get("ytm_user_agent") or _YT_UA,
               "Cookie": cookie, "X-Goog-AuthUser": creds.get("ytm_authuser") or "0"}
    auth = creds.make_authorization(cookie, origin)
    if auth:
        headers["Authorization"] = auth
    req = urllib.request.Request("https://www.youtube.com/youtubei/v1/browse?prettyPrint=false",
                                 data=json.dumps(body).encode("utf-8"), method="POST", headers=headers)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode("utf-8"))

def youtube_subscriptions(force=False):
    ctx = {"client": {"clientName": "WEB", "clientVersion": "2.20250101.00.00", "hl": "en", "gl": "US"}}
    with _subs_lock:
        if not force and _subs_cache["data"] is not None and time.time() - _subs_cache["t"] < 1800:
            return _subs_cache["data"]
        cookie = creds.get("ytm_cookie")
        if not cookie:
            return {"ok": True, "connected": False, "code": "", "error": "", "channels": []}
        chans, seen = [], set()
        try:
            body = {"context": ctx, "browseId": "FEchannels"}
            for _ in range(8):
                data = _yt_browse(body, cookie)
                page, token = parse_subscriptions(data)
                for c in page:
                    if c["id"] not in seen:
                        seen.add(c["id"])
                        chans.append(c)
                if not token:
                    break
                body = {"context": ctx, "continuation": token}
        except urllib.error.HTTPError as e:
            code = "auth" if e.code in (401, 403) else "error"
            print("YouTube subscriptions failed: HTTP", e.code)
            return {"ok": True, "connected": True, "code": code,
                    "error": "login expired" if code == "auth" else "YouTube answered with an error (%s)" % e.code, "channels": []}
        except Exception as e:
            print("YouTube subscriptions failed:", repr(e)[:300])
            return {"ok": True, "connected": True, "code": "error",
                    "error": "Could not reach YouTube (%s)" % type(e).__name__, "channels": []}
        if not chans:
            print("YouTube subscriptions: no channels found in the response (not signed in, or layout changed)")
        res = {"ok": True, "connected": True, "code": "" if chans else "empty",
               "error": "" if chans else "No subscriptions found", "channels": chans}
        if chans:
            _subs_cache["t"] = time.time()
            _subs_cache["data"] = res
        return res

def parse_channel_feed(xml_bytes):
    """Latest uploads from a channel's public Atom feed -> (latest_epoch, videos)."""
    ns = {"a": "http://www.w3.org/2005/Atom", "yt": "http://www.youtube.com/xml/schemas/2015"}
    root = ET.fromstring(xml_bytes)
    vids, latest = [], 0
    chan_name = (root.findtext("a:author/a:name", default="", namespaces=ns) or "")[:80]
    for e in root.findall("a:entry", ns):
        vid = e.findtext("yt:videoId", default="", namespaces=ns)
        if not _ID_RE.match(vid or ""):
            continue
        ts = 0
        try:
            ts = int(datetime.fromisoformat((e.findtext("a:published", default="", namespaces=ns) or "").replace("Z", "+00:00")).timestamp())
        except Exception:
            pass
        latest = max(latest, ts)
        vids.append({"id": vid, "title": (e.findtext("a:title", default="", namespaces=ns) or "")[:200],
                     "channel": chan_name, "thumb": "https://i.ytimg.com/vi/%s/mqdefault.jpg" % vid,
                     "art": "https://i.ytimg.com/vi/%s/maxresdefault.jpg" % vid, "published": ts})
    return latest, vids

def _fetch_feed(cid):
    hit = _rss_cache.get(cid)
    if hit and time.time() - hit[0] < 900:
        return hit[1]
    req = urllib.request.Request("https://www.youtube.com/feeds/videos.xml?channel_id=" + cid,
                                 headers={"User-Agent": _YT_UA})
    try:
        with urllib.request.urlopen(req, timeout=6) as r:
            latest, vids = parse_channel_feed(r.read(400000))
    except Exception:
        return None
    res = {"latest": latest, "videos": vids}
    _rss_cache[cid] = (time.time(), res)
    return res

def yt_latest(ids):
    ids = [i for i in dict.fromkeys(ids) if _CHAN_RE.match(i)][:40]
    out = {}
    if not ids:
        return out
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(_fetch_feed, i): i for i in ids}
        done, _ = _fwait(list(futs), timeout=15)
        for f in done:
            try:
                r = f.result()
            except Exception:
                r = None
            if r is not None:
                out[futs[f]] = r["latest"]
    return out

def _parse_channel_items(data):
    """Videos from a channel browse response: classic videoRenderer plus the newer lockupViewModel layout."""
    items = parse_web_search(data)
    seen = {i["id"] for i in items}
    for d in _walk(data):
        lk = d.get("lockupViewModel")
        if not isinstance(lk, dict) or lk.get("contentType") not in (None, "LOCKUP_CONTENT_TYPE_VIDEO"):
            continue
        vid = lk.get("contentId") or ""
        if not _ID_RE.match(vid) or vid in seen:
            continue
        seen.add(vid)
        title = (((lk.get("metadata") or {}).get("lockupMetadataViewModel") or {}).get("title") or {}).get("content", "")
        items.append({"id": vid, "title": str(title)[:200], "channel": "",
                      "thumb": "https://i.ytimg.com/vi/%s/mqdefault.jpg" % vid,
                      "art": "https://i.ytimg.com/vi/%s/maxresdefault.jpg" % vid})
    return items

def _channel_videos_browse(cid):
    """Fallback when the RSS feed fails: the channel's Videos tab, the same request youtube.com makes.
    Uses the saved YouTube login when there is one (YouTube answers that more reliably)."""
    body = {"context": {"client": {"clientName": "WEB", "clientVersion": "2.20250101.00.00", "hl": "en", "gl": "US"}},
            "browseId": cid, "params": "EgZ2aWRlb3PyBgQKAjoA"}
    cookie = creds.get("ytm_cookie")
    if cookie:
        try:
            data = _yt_browse(body, cookie)
        except Exception:
            data = None
    else:
        data = None
    if data is None:
        req = urllib.request.Request("https://www.youtube.com/youtubei/v1/browse?prettyPrint=false",
                                     data=json.dumps(body).encode("utf-8"), method="POST",
                                     headers={"Content-Type": "application/json", "Origin": "https://www.youtube.com",
                                              "Referer": "https://www.youtube.com/", "Accept-Language": "en-US,en;q=0.9",
                                              "User-Agent": _YT_UA})
        with urllib.request.urlopen(req, timeout=12) as r:
            data = json.loads(r.read().decode("utf-8"))
    name = ""
    for d in _walk(data):
        if isinstance(d.get("channelMetadataRenderer"), dict):
            name = str(d["channelMetadataRenderer"].get("title", ""))[:80]
            break
    items = _parse_channel_items(data)[:30]
    for it in items:
        it["channel"] = name or it.get("channel", "")
    return items

def yt_channel_videos(cid):
    if not _CHAN_RE.match(cid or ""):
        return {"ok": False, "code": "error", "error": "bad channel id", "items": []}
    why = []
    r = _fetch_feed(cid)
    if r is None:
        time.sleep(0.4)
        r = _fetch_feed(cid)          # YouTube's feed fails now and then: one retry
    if r is not None and r["videos"]:
        return {"ok": True, "code": "", "error": "", "items": r["videos"]}
    why.append("feed " + ("empty" if r is not None else "failed"))
    try:
        items = _channel_videos_browse(cid)
        if items:
            return {"ok": True, "code": "", "error": "", "items": items}
        why.append("channel page had no videos")
    except Exception as e:
        print("YouTube channel fallback failed:", repr(e)[:300])
        why.append("channel page: " + type(e).__name__ + (" %s" % getattr(e, "code", "") if hasattr(e, "code") else ""))
    return {"ok": False, "code": "error", "items": [],
            "error": "Couldn't load that channel's videos (" + "; ".join(why) + "). Check the server's internet access to youtube.com."}

def yt_save_key(key):
    key = (key or "").strip()
    if not _YT_KEY_RE.match(key):
        return False, "That doesn't look like a YouTube API key"
    data, err = _yt_call("videos", {"part": "id", "id": "dQw4w9WgXcQ"}, key)
    if data is None and err in ("key",):
        return False, "YouTube rejected that key (enable YouTube Data API v3 for it)"
    if data is None and err != "quota":
        return False, err[:200]
    try:
        creds.set("yt_api_key", key)
    except Exception as e:
        return False, "Couldn't save the key: %s" % e
    return True, ""

# ---------- up-next preview + status cache (added) ----------
# Android does not expose the phone's upcoming queue over adb, so the next song comes from the
# exact order of the playlist that was started from the app (needs ytm_setup.py). There is no
# guessing: if the playing song isn't in that playlist, no "up next" is shown.
from urllib.parse import parse_qs

_ctx = {"pid": None, "tracks": [], "ready": False, "last": 0}
_tracks_cache = {}  # pid -> (timestamp, [track info]); feeds the song picker and the up-next order
_tracks_lock = threading.Lock()
_next_cache = {}  # norm(desc) -> (timestamp, result)
_next_lock = threading.Lock()
_status_cache = {"t": 0.0, "data": None}
_status_lock = threading.Lock()

def _norm(s):
    return re.sub(r"[\W_]+", "", (s or "").lower())

def _small_thumb(th):
    """Thumbnail for a song row: sharp on a 2x phone screen without being a full-size image."""
    items = [x for x in th if isinstance(x, dict) and x.get("url")]
    if not items:
        return ""
    sized = sorted(items, key=lambda x: x.get("width") or 0)
    for x in sized:
        if (x.get("width") or 0) >= 226:
            return x["url"]
    return sized[-1]["url"]

def _big_thumb(th):
    """Largest thumbnail available - used for the player's cover, where it is shown big."""
    items = [x for x in th if isinstance(x, dict) and x.get("url")]
    if not items:
        return ""
    return max(items, key=lambda x: (x.get("width") or 0) * (x.get("height") or 0))["url"]

def _track_info(t):
    th = t.get("thumbnails") or t.get("thumbnail") or []
    names = [a.get("name", "") for a in (t.get("artists") or []) if isinstance(a, dict) and a.get("name")]
    return {
        "videoId": t.get("videoId") or "",
        "title": t.get("title") or "",
        "artist": ", ".join(names),
        "artists": names,
        "thumb": (th[-1].get("url", "") if th and isinstance(th[-1], dict) else ""),
        "thumbSmall": _small_thumb(th),
    }

def _public(info, source):
    return {"ok": True, "found": True, "pending": False, "source": source,
            "title": info["title"], "artist": info["artist"], "thumb": info["thumb"]}

def _get_playlist_tracks_yt(pid, force=False):
    """Returns (tracks, code, error). code is '' on success. Cached for 5 minutes."""
    if not _ID_RE.match(pid or ""):
        return [], "error", "bad playlist id"
    ck = (creds.get_user() or "", pid)
    with _tracks_lock:
        hit = _tracks_cache.get(ck)
        if hit and not force and time.time() - hit[0] < 300:
            return hit[1], "", ""
    yt, code, msg = get_ytm()
    if yt is None:
        return [], code, msg
    try:
        data = yt.get_playlist(pid, limit=500)
        tracks = [_track_info(t) for t in (data.get("tracks") or []) if t.get("videoId")]
    except Exception as e:
        low = str(e).lower()
        if any(k in low for k in ("401", "403", "unauthorized", "sign in", "log in", "forbidden")):
            return [], "auth", "login expired"
        return [], "error", str(e)[:200]
    with _tracks_lock:
        if len(_tracks_cache) >= 12:
            _tracks_cache.pop(next(iter(_tracks_cache)))
        _tracks_cache[ck] = (time.time(), tracks)
    return tracks, "", ""

def get_playlist_tracks(pid, force=False):
    """Tracks for a playlist id from either provider."""
    if str(pid or "").startswith("sp_"):
        if spotify is None:
            return [], "not_installed", "spotify.py is missing on the server"
        return spotify.playlist_tracks(pid, force)
    if playback_provider() == "spotify" and spotify is not None:
        return [], "error", "that playlist isn't on Spotify"
    return _get_playlist_tracks_yt(pid, force)

def _load_ctx(pid, user=None):
    creds.set_user(user)          # this thread works for the account that started it
    tracks, _, _ = get_playlist_tracks(pid)
    if _ctx["pid"] == pid and _ctx.get("user") == user:
        _ctx["tracks"] = tracks
        _ctx["ready"] = True
        with _next_lock:
            _next_cache.clear()

def _start_ctx_load(pid, start=0):
    _ctx["pid"] = pid
    _ctx["user"] = creds.get_user()
    _ctx["tracks"] = []
    _ctx["ready"] = False
    _ctx["last"] = start
    with _next_lock:
        _next_cache.clear()
    threading.Thread(target=_load_ctx, args=(pid, creds.get_user()), daemon=True).start()

def _match_ctx(desc):
    """Index of the playing song inside the loaded playlist, or -1. The phone's description
    looks like 'Title, Artist, Album'; the longest matching title wins."""
    d = _norm(desc)
    cands = []
    for i, t in enumerate(_ctx["tracks"]):
        nt = _norm(t["title"])
        if not nt or not d.startswith(nt):
            continue
        if t["artists"] and not any(_norm(a) in d for a in t["artists"]):
            continue
        cands.append((len(nt), i))
    if not cands:
        return -1
    top = max(n for n, _ in cands)
    idxs = [i for n, i in cands if n == top]
    last = _ctx.get("last", 0)
    after = [i for i in idxs if i >= last]  # a repeated title: take the one next in playing order
    pick = min(after) if after else idxs[0]
    _ctx["last"] = pick
    return pick

def up_next(desc):
    desc = (desc or "").strip()[:300]
    if not desc:
        return {"ok": True, "found": False, "pending": False}
    key = _norm(desc)
    with _next_lock:
        hit = _next_cache.get(key)
        if hit and time.time() - hit[0] < 600:
            return hit[1]
    loading = bool(_ctx["pid"]) and not _ctx["ready"]
    result = {"ok": True, "found": False, "pending": loading}
    if _ctx["ready"] and _ctx["tracks"]:
        i = _match_ctx(desc)
        if i >= 0:
            if i + 1 < len(_ctx["tracks"]):
                result = _public(_ctx["tracks"][i + 1], "playlist")
            with _next_lock:
                _next_cache[key] = (time.time(), result)
            return result
    return result

def media_status_cached(ttl=1.2):
    """media_status() shells out to adb (3 processes). Several tabs / quick polls share one answer."""
    with _status_lock:
        now = time.time()
        data = _status_cache["data"]
        if data is not None and now - _status_cache["t"] < ttl:
            out = dict(data)
            if out.get("connected") and out.get("state") in (3, 4, 6) and out.get("position") is not None:
                speed = out.get("speed") or 1.0
                out["position"] = int(out["position"] + (now - _status_cache["t"]) * 1000.0 * (speed if speed > 0 else 1.0))
            return out
        data = media_status()
        _status_cache["t"] = time.time()
        _status_cache["data"] = data
        return dict(data)

# ---------- accounts / login (added) ----------
# Real accounts: username + password (PBKDF2-SHA256, per-user salt), server-side sessions in an
# HttpOnly cookie. Each account keeps its own Last.fm connection + theme. Stored OUTSIDE the web
# folder (the web folder is served to the network) in ~/.vizah_accounts.json, same idea as the
# ~/.ytmusic_browser.json file. Set VIZAH_SIGNUP=0 to stop new accounts being created.
import hashlib
import hmac
import secrets
from http.cookies import SimpleCookie

AUTH_FILE = os.environ.get("VIZAH_AUTH") or os.path.expanduser("~/.vizah_accounts.json")
SIGNUP_OPEN = os.environ.get("VIZAH_SIGNUP", "1") != "0"
COOKIE_NAME = "vizah_session"
SESSION_SECONDS = 30 * 24 * 3600
PBKDF2_ITERS = 300000
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")
COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
AVATAR_RE = re.compile(r"^data:image/(jpeg|png|webp|gif);base64,[A-Za-z0-9+/=]+$")
AVATAR_MAX = 1500000  # characters; a 256x256 JPEG is ~50 KB, animated GIFs can be much larger
AVATAR_CROP_RE = re.compile(r"^(\d{1,3}(?:\.\d+)?),(\d{1,3}(?:\.\d+)?),(\d(?:\.\d+)?)$")
DEFAULT_CONFIG = {
    "user": "", "apiKey": "",
    "bg1": "#110d18", "bg2": "#4d1733", "bg3": "#0d1b2a",
    "acc1": "#ff7a59", "acc2": "#ffd166", "acc3": "#79e7ff",
    "avatarCrop": "", "bgStyle": "",
}
_auth_lock = threading.RLock()
_auth_db = None
_fails = {}  # throttle key -> [timestamps of recent failures]

def _auth_load():
    global _auth_db
    if _auth_db is None:
        db = {}
        try:
            with open(AUTH_FILE, "r", encoding="utf-8") as f:
                db = json.load(f)
        except Exception:
            db = {}
        if not isinstance(db, dict):
            db = {}
        db.setdefault("users", {})
        db.setdefault("sessions", {})
        _auth_db = db
        # password hashes used to sit in this file; they live in creds.txt now
        moved = False
        for key, u in db["users"].items():
            if isinstance(u, dict) and u.get("pw"):
                try:
                    if not creds.has("pw." + key):
                        creds.set("pw." + key, u["pw"])
                    del u["pw"]
                    moved = True
                except Exception:
                    pass
        if moved:
            _auth_save()
    return _auth_db

def _auth_save():
    tmp = AUTH_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(_auth_db, f, indent=2)
    try:
        os.chmod(tmp, 0o600)
    except Exception:
        pass
    os.replace(tmp, AUTH_FILE)

def clean_config(data, base=None):
    """Only the known settings, with sane types - never trust what the browser sends."""
    out = dict(base if isinstance(base, dict) else DEFAULT_CONFIG)
    if not isinstance(data, dict):
        return out
    for k in ("user", "apiKey"):
        v = data.get(k)
        if isinstance(v, str):
            out[k] = v.strip()[:200]
    for k in ("bg1", "bg2", "bg3", "acc1", "acc2", "acc3"):
        v = data.get(k)
        if isinstance(v, str) and COLOR_RE.match(v):
            out[k] = v
    # background style (blobs / particles) follows the account too
    bs = data.get("bgStyle")
    if isinstance(bs, str) and bs in ("", "blobs", "particles"):
        out["bgStyle"] = bs
    # profile picture: stored with the account so it follows you to every device
    av = data.get("avatar")
    if isinstance(av, str):
        if av == "":
            out["avatar"] = ""
        elif len(av) <= AVATAR_MAX and AVATAR_RE.match(av):
            out["avatar"] = av
    # profile bio + whether friends can see what you're listening to (added)
    bio = data.get("bio")
    if isinstance(bio, str):
        bio = re.sub(r"[\x00-\x08\x0b-\x1f\x7f]", "", bio).strip()
        out["bio"] = bio[:160]
    sl = data.get("showListening")
    if isinstance(sl, bool):
        out["showListening"] = sl
    # extra connections (Instagram, TikTok, ...) shown as links on the profile (added)
    so = data.get("socials")
    if isinstance(so, list) and social is not None:
        out["socials"] = social.clean_socials(so)
    # non-destructive crop for animated GIF avatars: "x,y,zoom"
    ac = data.get("avatarCrop")
    if isinstance(ac, str):
        if ac == "":
            out["avatarCrop"] = ""
        else:
            m = AVATAR_CROP_RE.match(ac)
            if m:
                px, py, z = float(m.group(1)), float(m.group(2)), float(m.group(3))
                if 0 <= px <= 100 and 0 <= py <= 100 and 1 <= z <= 6:
                    out["avatarCrop"] = ac
    return out

def hash_password(pw, iters=PBKDF2_ITERS):
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, iters)
    return "pbkdf2_sha256$%d$%s$%s" % (iters, salt.hex(), dk.hex())

def verify_password(pw, stored):
    try:
        algo, iters, salt, want = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(salt), int(iters))
        return hmac.compare_digest(dk.hex(), want)
    except Exception:
        return False

# a real hash to compare against when the username does not exist, so a wrong username and a
# wrong password take the same time and give the same message
_DUMMY_HASH = hash_password("vizah-dummy-password")

def _throttled(key, limit):
    now = time.time()
    hits = [t for t in _fails.get(key, []) if now - t < 900]
    _fails[key] = hits
    return len(hits) >= limit

def _note_fail(key):
    _fails.setdefault(key, []).append(time.time())

def account_count():
    with _auth_lock:
        return len(_auth_load()["users"])

def create_account(username, password, force=False):
    """Returns (ok, error). The very first account also adopts an existing config.json,
    so a setup that already works keeps working."""
    if not SIGNUP_OPEN and not force:
        return False, "Sign-ups are turned off on this server"
    if not USERNAME_RE.match(username or ""):
        return False, "Username: 3-32 letters, numbers, . _ -"
    if not isinstance(password, str) or len(password) < 8:
        return False, "Password must be at least 8 characters"
    if len(password) > 200:
        return False, "Password is too long"
    with _auth_lock:
        db = _auth_load()
        key = username.lower()
        if key in db["users"]:
            return False, "That username is taken"
        cfg = dict(DEFAULT_CONFIG)
        if not db["users"]:
            legacy = load_config()
            if isinstance(legacy, dict) and legacy:
                cfg = clean_config(legacy)
        try:
            creds.set("pw." + key, hash_password(password))
        except Exception as e:
            return False, "Couldn't write creds.txt: %s" % e
        first = not db["users"]
        db["users"][key] = {
            "name": username,
            "created": int(time.time()),
            "config": cfg,
        }
        _auth_save()
        if first:
            try:
                creds.migrate_legacy(key)
            except Exception:
                pass
    return True, ""

# Dev accounts (added): created on every start if they are missing, so you never have to sign up
# again - even after clear_users.py or a fresh install. An existing account is left exactly as it is
# (profile, theme, and a password you changed yourself). Set VIZAH_DEV_ACCOUNTS=0 to turn this off.
DEV_ACCOUNTS = (("Umbrxs", "00000000"), ("Vizah", "00000000"))
DEV_ACCOUNTS_ON = os.environ.get("VIZAH_DEV_ACCOUNTS", "1") != "0"

def ensure_dev_accounts():
    if not DEV_ACCOUNTS_ON:
        return
    for name, pw in DEV_ACCOUNTS:
        key = name.lower()
        try:
            with _auth_lock:
                exists = key in _auth_load()["users"]
            if not exists:
                ok, err = create_account(name, pw, force=True)
                print("Dev account %s: %s" % (name, "created" if ok else "not created (" + err + ")"))
            elif not creds.has("pw." + key):
                creds.set("pw." + key, hash_password(pw))   # account exists but its password was lost
                print("Dev account %s: password restored" % name)
        except Exception as e:
            print("Warning: dev account %s: %s" % (name, e))

def check_login(username, password):
    key = (username or "").lower()
    with _auth_lock:
        u = _auth_load()["users"].get(key)
    stored = (creds.get("pw." + key) if u else "") or _DUMMY_HASH
    ok = verify_password(password if isinstance(password, str) else "", stored)
    return (u["name"] if (u and ok) else None)

def rename_account(old_name, new_username, password):
    """Change the Vizah username (needs the current password). Returns (ok, error, new_name)."""
    new_username = (new_username or "").strip()
    if not USERNAME_RE.match(new_username):
        return False, "Username: 3-32 letters, numbers, . _ -", ""
    if check_login(old_name, password) is None:
        return False, "Wrong password", ""
    old_key, new_key = old_name.lower(), new_username.lower()
    with _auth_lock:
        db = _auth_load()
        u = db["users"].get(old_key)
        if not u:
            return False, "Account not found", ""
        if new_key != old_key and new_key in db["users"]:
            return False, "That username is taken", ""
        if new_key != old_key:
            try:
                creds.set("pw." + new_key, creds.get("pw." + old_key))
                creds.delete("pw." + old_key)
                creds.rename_user(old_key, new_key)
            except Exception as e:
                return False, "Couldn't write creds.txt: %s" % e, ""
            db["users"][new_key] = db["users"].pop(old_key)
            _fr_rename(old_key, new_key)
            for sess in db["sessions"].values():
                if sess.get("user") == old_key:
                    sess["user"] = new_key
        db["users"][new_key]["name"] = new_username
        _auth_save()
        if social:
            try:
                social.on_rename(old_key, new_key)  # keep conversations with the renamed account
            except Exception:
                pass
    return True, "", new_username

def change_password(name, old_password, new_password, keep_token=""):
    """Change the Vizah password (needs the current one). Other logged-in devices are signed out.
    Returns (ok, error)."""
    if not isinstance(new_password, str) or len(new_password) < 8:
        return False, "New password must be at least 8 characters"
    if len(new_password) > 200:
        return False, "Password is too long"
    if not isinstance(old_password, str) or check_login(name, old_password) is None:
        return False, "Wrong password"
    if new_password == old_password:
        return False, "New password must be different from the current one"
    key = name.lower()
    with _auth_lock:
        db = _auth_load()
        if key not in db["users"]:
            return False, "Account not found"
        try:
            creds.set("pw." + key, hash_password(new_password))
        except Exception as e:
            return False, "Couldn't write creds.txt: %s" % e
        keep = hashlib.sha256(keep_token.encode()).hexdigest() if keep_token else ""
        for h in [h for h, s in db["sessions"].items() if s.get("user") == key and h != keep]:
            del db["sessions"][h]
        _auth_save()
    return True, ""

def delete_account(name, password):
    """Permanently removes an account (needs its password): login, sessions, friendships,
    YouTube login, messages. Returns (ok, error)."""
    if not isinstance(password, str) or check_login(name, password) is None:
        return False, "Wrong password"
    key = name.lower()
    with _auth_lock:
        db = _auth_load()
        if key not in db["users"]:
            return False, "Account not found"
        del db["users"][key]
        for h in [h for h, s in db["sessions"].items() if s.get("user") == key]:
            del db["sessions"][h]
        for u in db["users"].values():          # friendships and pending requests that point at it
            for k in ("friends", "req_in", "req_out"):
                if isinstance(u.get(k), list):
                    u[k] = [x for x in u[k] if x != key]
        try:
            creds.delete("pw." + key)
            for k in creds.USER_KEYS:
                creds.delete("%s.%s" % (k, key))
        except Exception as e:
            print("Warning: couldn't clear creds.txt for", key, e)
        _auth_save()
        if social:
            try:
                social.on_delete(key)
            except Exception:
                pass
    _yt_acct["data"] = None
    return True, ""

def new_session(name):
    try:   # a login added with ytm_setup.py (plain names) goes to the first account
        if name.lower() == _legacy_owner():
            creds.migrate_legacy(name.lower())
    except Exception:
        pass
    token = secrets.token_urlsafe(32)
    now = int(time.time())
    with _auth_lock:
        db = _auth_load()
        for h in [h for h, s in db["sessions"].items() if s.get("exp", 0) < now]:
            del db["sessions"][h]
        db["sessions"][hashlib.sha256(token.encode()).hexdigest()] = {
            "user": name.lower(), "exp": now + SESSION_SECONDS, "seen": now}
        _auth_save()
    return token

def session_lookup(token, renew=False):
    """Returns the account name for a valid session token, else None."""
    if not token:
        return None
    h = hashlib.sha256(token.encode()).hexdigest()
    now = int(time.time())
    with _auth_lock:
        db = _auth_load()
        s = db["sessions"].get(h)
        if not s or s.get("exp", 0) < now:
            return None
        u = db["users"].get(s.get("user"))
        if not u:
            return None
        if renew and now - s.get("seen", 0) > 86400:
            s["seen"] = now
            s["exp"] = now + SESSION_SECONDS
            _auth_save()
        return u["name"]

def drop_session(token):
    if not token:
        return
    with _auth_lock:
        db = _auth_load()
        if db["sessions"].pop(hashlib.sha256(token.encode()).hexdigest(), None) is not None:
            _auth_save()

def get_account_config(name):
    with _auth_lock:
        u = _auth_load()["users"].get((name or "").lower())
        return dict(u["config"]) if u else dict(DEFAULT_CONFIG)

def set_account_config(name, data, replace_all=True):
    with _auth_lock:
        u = _auth_load()["users"].get((name or "").lower())
        if not u:
            return False
        u["config"] = clean_config(data, base=(DEFAULT_CONFIG if replace_all else u["config"]))
        _auth_save()
        return True

def disconnect_lastfm(name):
    """Forgets only the Last.fm user + API key; the account and its theme stay."""
    with _auth_lock:
        u = _auth_load()["users"].get((name or "").lower())
        if not u:
            return False
        u["config"]["user"] = ""
        u["config"]["apiKey"] = ""
        _auth_save()
        return True

# ---------- friends (added) ----------
# Stored on each account in the accounts file: "friends", "req_in" (requests received) and
# "req_out" (requests sent), all lists of lowercase usernames.
FRIEND_MAX, REQUEST_MAX = 500, 100

def _fr_lists(u):
    for k in ("friends", "req_in", "req_out"):
        if not isinstance(u.get(k), list):
            u[k] = []
    return u

def _fr_entry(db, key):
    u = db["users"].get(key)
    return {"name": u.get("name", key)} if u else None

def friends_overview(name):
    """friends_overview_base + an "online" flag on each friend (added)."""
    out = _friends_overview_base(name)
    try:
        for e in out.get("friends", []):
            e["online"] = bool(social and social._online(sys.modules[__name__], e["name"].lower()))
    except Exception:
        pass
    return out

def _friends_overview_base(name):
    with _auth_lock:
        db = _auth_load()
        me = db["users"].get((name or "").lower())
        if not me:
            return {"ok": False, "error": "account not found", "friends": [], "incoming": [], "outgoing": []}
        _fr_lists(me)
        def names(keys):
            out = [e for e in (_fr_entry(db, k) for k in keys) if e]
            return sorted(out, key=lambda e: e["name"].lower())
        return {"ok": True, "friends": names(me["friends"]), "incoming": names(me["req_in"]),
                "outgoing": names(me["req_out"])}

def friends_search(name, q):
    q = (q or "").strip().lower()[:32]
    if len(q) < 2:
        return {"ok": True, "results": []}
    me_key = (name or "").lower()
    with _auth_lock:
        db = _auth_load()
        me = _fr_lists(db["users"].get(me_key) or {})
        hits = []
        for key, u in db["users"].items():
            if key == me_key or q not in key:
                continue
            status = ("friend" if key in me["friends"] else "sent" if key in me["req_out"]
                      else "received" if key in me["req_in"] else "none")
            hits.append((0 if key.startswith(q) else 1, key, {"name": u.get("name", key), "status": status}))
        hits.sort(key=lambda h: (h[0], h[1]))
        return {"ok": True, "results": [h[2] for h in hits[:10]]}

def _drop(lst, key):
    while key in lst:
        lst.remove(key)

def friend_action(name, action, target):
    """request / accept / decline / cancel / remove. Returns (ok, error)."""
    me_key, t_key = (name or "").lower(), (target or "").strip().lower()
    if not USERNAME_RE.match(t_key or ""):
        return False, "Enter a valid username"
    if t_key == me_key:
        return False, "That's you"
    with _auth_lock:
        db = _auth_load()
        me, them = db["users"].get(me_key), db["users"].get(t_key)
        if not me:
            return False, "Account not found"
        if not them:
            return False, "No user with that name"
        _fr_lists(me); _fr_lists(them)
        if action == "request":
            if t_key in me["friends"]:
                return True, ""
            if t_key in me["req_in"]:          # they already asked me: that makes us friends
                action = "accept"
            else:
                if len(me["friends"]) >= FRIEND_MAX or len(them["friends"]) >= FRIEND_MAX:
                    return False, "Friend list is full"
                if t_key not in me["req_out"]:
                    if len(me["req_out"]) >= REQUEST_MAX:
                        return False, "Too many pending requests"
                    me["req_out"].append(t_key)
                if me_key not in them["req_in"]:
                    them["req_in"].append(me_key)
                _auth_save()
                return True, ""
        if action == "accept":
            if t_key not in me["req_in"]:
                return False, "No request from that user"
            if len(me["friends"]) >= FRIEND_MAX or len(them["friends"]) >= FRIEND_MAX:
                return False, "Friend list is full"
            for a, b, ak, bk in ((me, them, me_key, t_key), (them, me, t_key, me_key)):
                _drop(a["req_in"], bk); _drop(a["req_out"], bk)
                if bk not in a["friends"]:
                    a["friends"].append(bk)
            _auth_save()
            return True, ""
        if action == "decline":
            _drop(me["req_in"], t_key); _drop(them["req_out"], me_key)
        elif action == "cancel":
            _drop(me["req_out"], t_key); _drop(them["req_in"], me_key)
        elif action == "remove":
            _drop(me["friends"], t_key); _drop(them["friends"], me_key)
        else:
            return False, "Unknown action"
        _auth_save()
        return True, ""

def friend_avatar(name):
    """(mime, bytes) of a user's profile picture, or None."""
    import base64
    with _auth_lock:
        u = _auth_load()["users"].get((name or "").lower())
        av = (u or {}).get("config", {}).get("avatar") or ""
    m = re.match(r"^data:(image/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$", av)
    if not m:
        return None
    try:
        return m.group(1), base64.b64decode(m.group(2))
    except Exception:
        return None

def _fr_rename(old_key, new_key):
    """Keeps friendships intact when someone changes their username (caller holds _auth_lock)."""
    for u in _auth_load()["users"].values():
        for k in ("friends", "req_in", "req_out"):
            if isinstance(u.get(k), list):
                u[k] = [new_key if x == old_key else x for x in u[k]]

# ---------- per-account YouTube state (added) ----------
# YouTube logins/keys live under the account (see creds.py). The few in-memory caches that came
# from a login are dropped whenever a different account takes over, and requests that touch
# them run one at a time so two accounts can never see each other's data.
_user_lock = threading.RLock()
_bound = {"user": None}
_YT_PATHS = ("/playlist", "/play-", "/youtube", "/ytm", "/setup", "/media", "/spotify", "/music")

def _bind_user(name):
    global _ytm
    key = (name or "").lower() or None
    creds.set_user(key or "-")            # "-" matches nothing: no account, no YouTube login
    if _bound["user"] != key:
        _bound["user"] = key
        _ytm = None
        _pl_cache.update({"t": 0.0, "data": None})
        _yt_acct.update({"t": 0.0, "data": None})
        _subs_cache.update({"t": 0.0, "data": None})
        with _tracks_lock:
            _tracks_cache.clear()
        with _next_lock:
            _next_cache.clear()
        _ctx.update({"pid": None, "user": None, "tracks": [], "ready": False, "last": 0})
        _status_cache["data"] = None
        if spotify is not None:
            try:
                spotify.forget()
            except Exception:
                pass

def _legacy_owner():
    """The first account created: it inherits the YouTube login that used to be shared."""
    with _auth_lock:
        users = _auth_load()["users"]
        if not users:
            return None
        return min(users, key=lambda k: (users[k].get("created", 0), k))

# served files that must never be downloadable without logging in
_PRIVATE_STATIC = {"config.json", "creds.txt", "creds.txt.tmp"}

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        """Last line of defence for static files: whatever the URL looks like (encoded, odd
        case, extra slashes), creds.txt and config.json are answered with a 404."""
        real = super().translate_path(path)
        try:
            name = os.path.basename(os.path.realpath(real)).lower()
        except Exception:
            name = ""
        if name in _PRIVATE_STATIC or name.startswith(".vizah") or name.startswith("creds.txt"):
            return os.path.join(os.path.dirname(real), ".vizah-not-found")
        return real

    def end_headers(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        super().end_headers()

    # ---- accounts: helpers (added) ----
    def _send_json(self, code, obj, cookie=None):
        payload = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(payload)

    def _token(self):
        try:
            c = SimpleCookie(self.headers.get("Cookie", ""))
            return c[COOKIE_NAME].value if COOKIE_NAME in c else ""
        except Exception:
            return ""

    def _cookie(self, token, max_age):
        parts = ["%s=%s" % (COOKIE_NAME, token), "Path=/", "HttpOnly", "SameSite=Lax", "Max-Age=%d" % max_age]
        if self.headers.get("X-Forwarded-Proto", "").lower() == "https":
            parts.append("Secure")
        return "; ".join(parts)

    def _read_json(self, limit=20000):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            return None
        if length < 0 or length > limit:
            return None
        try:
            data = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
        except Exception:
            return None
        return data if isinstance(data, dict) else None

    def _same_origin(self):
        origin = self.headers.get("Origin")
        if not origin:
            return True
        host = self.headers.get("Host", "")
        return urlparse(origin).netloc == host

    def _client_ip(self):
        return self.client_address[0] if self.client_address else "?"

    def _base_url(self):
        """This server's own public address, used to build the Spotify redirect URI."""
        proto = "https" if self.headers.get("X-Forwarded-Proto", "").lower() == "https" else "http"
        # behind a tunnel / reverse proxy the real host arrives in X-Forwarded-Host
        host = (self.headers.get("X-Forwarded-Host", "") or self.headers.get("Host", "")
                or "localhost:%s" % PORT).split(",")[0].strip()
        return "%s://%s" % (proto, host)

    def _deny(self, path):
        body = {"ok": False, "error": "log in to Vizah first", "code": "login", "auth": False}
        if path in ("/playlists",) or path.startswith("/play-playlist/") or path.startswith("/playlist-tracks/"):
            body.update({"playlists": []})
        if path == "/media/status":
            body.update({"connected": False, "playing": None})
        self._send_json(401, body)

    # ---- accounts: routes that run BEFORE the original handlers (added) ----
    def _accounts_get(self, parsed):
        """Returns True when the request was fully handled here."""
        path = parsed.path
        if os.path.basename(path).lower() in _PRIVATE_STATIC or os.path.basename(path).startswith(".vizah"):
            self.send_response(404)
            self.end_headers()
            return True
        if path == "/auth/me":
            token = self._token()
            name = session_lookup(token, renew=True)
            cookie = self._cookie(token, SESSION_SECONDS) if name else None
            self._send_json(200, {"ok": True, "loggedIn": bool(name), "username": name or "",
                                  "signupOpen": SIGNUP_OPEN, "hasAccounts": account_count() > 0}, cookie)
            return True
        protected = (path in ("/config", "/playlists", "/media/status", "/media/up-next", "/setup/status", "/youtube/search", "/youtube/status", "/youtube/account", "/youtube/subs", "/youtube/subs/latest", "/youtube/channel", "/ytm/search", "/friends", "/friends/search",
                              "/spotify/status", "/spotify/connect", "/spotify/callback")
                     or path.startswith("/playlist-tracks/") or path.startswith("/friends/avatar/"))
        if protected:
            name = session_lookup(self._token())
            if not name:
                self._deny(path)
                return True
            if path == "/config":
                self._send_json(200, get_account_config(name))
                return True
            if path == "/setup/status":
                self._send_json(200, setup_status())
                return True
            if path == "/youtube/status":
                self._send_json(200, {"ok": True, "hasKey": bool(yt_key()), "canSearch": True})
                return True
            if path == "/youtube/account":
                force = parse_qs(parsed.query or "").get("force", [""])[0] == "1"
                self._send_json(200, youtube_account(force))
                return True
            if path == "/youtube/subs":
                force = parse_qs(parsed.query or "").get("force", [""])[0] == "1"
                self._send_json(200, youtube_subscriptions(force))
                return True
            if path == "/youtube/subs/latest":
                ids = parse_qs(parsed.query or "").get("ids", [""])[0].split(",")
                self._send_json(200, {"ok": True, "latest": yt_latest(ids)})
                return True
            if path == "/youtube/channel":
                cid = parse_qs(parsed.query or "").get("id", [""])[0]
                self._send_json(200, yt_channel_videos(cid))
                return True
            if path == "/youtube/search":
                q = parse_qs(parsed.query or "").get("q", [""])[0]
                self._send_json(200, yt_search(q))
                return True
            if path == "/ytm/search":
                q = parse_qs(parsed.query or "").get("q", [""])[0]
                self._send_json(200, ytm_search(q))
                return True
            if path == "/spotify/status":
                if spotify is None:
                    self._send_json(200, {"ok": True, "connected": False, "code": "not_installed",
                                          "error": "spotify.py is missing on the server", "configured": False})
                    return True
                st = spotify.status(self._base_url() + "/spotify/callback")
                st["provider"] = playback_provider()
                st["youtubeConnected"] = creds.has("ytm_cookie")
                self._send_json(200, st)
                return True
            if path == "/spotify/connect":
                if spotify is None:
                    self._send_json(200, {"ok": False, "error": "spotify.py is missing on the server"})
                    return True
                base_cb = self._base_url() + "/spotify/callback"
                ok, url, err = spotify.connect_url(base_cb)
                self._send_json(200, {"ok": ok, "url": url, "error": err,
                                      "redirect": spotify.redirect_uri_for(base_cb)})
                return True
            if path == "/spotify/callback":
                qs = parse_qs(parsed.query or "")
                code = (qs.get("code") or [""])[0]
                state = (qs.get("state") or [""])[0]
                err = (qs.get("error") or [""])[0]
                ok, msg = (False, "Spotify login was cancelled") if err else \
                    (spotify.handle_callback(code, state) if spotify is not None else (False, "spotify.py is missing"))
                target = "/?spotify=connected" if ok else "/?spotify=error&msg=" + _up.quote(msg or "failed")
                self.send_response(302)
                self.send_header("Location", target)
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                return True
            if path in ("/friends", "/friends/search") or path.startswith("/friends/avatar/"):
                if path.startswith("/friends/avatar/"):
                    from urllib.parse import unquote
                    pic = friend_avatar(unquote(path.split("/friends/avatar/", 1)[1]))
                    if not pic:
                        self.send_response(404)
                        self.end_headers()
                        return True
                    self.send_response(200)
                    self.send_header("Content-Type", pic[0])
                    self.send_header("Content-Length", str(len(pic[1])))
                    self.send_header("Cache-Control", "private, max-age=300")
                    self.send_header("X-Content-Type-Options", "nosniff")
                    self.end_headers()
                    self.wfile.write(pic[1])
                    return True
                fkey = "fr:" + name.lower()
                if _throttled(fkey, 400):
                    self._send_json(429, {"ok": False, "error": "Slow down a little", "results": []})
                    return True
                _note_fail(fkey)
                if path == "/friends/search":
                    self._send_json(200, friends_search(name, parse_qs(parsed.query or "").get("q", [""])[0]))
                else:
                    self._send_json(200, friends_overview(name))
                return True
        return False

    def _accounts_post(self, parsed):
        """Returns True when the request was fully handled here."""
        path = parsed.path
        auth_paths = ("/auth/signup", "/auth/login", "/auth/logout", "/auth/password-public")
        protected = (path in ("/save-config", "/clear-config", "/lastfm/disconnect", "/auth/rename", "/auth/password", "/auth/delete", "/youtube/disconnect")
                     or path.startswith("/play-playlist/") or path.startswith("/media/")
                     or path.startswith("/ytm/play-song/") or path.startswith("/friends/")
                     or path == "/playlist-add"
                     or path in ("/setup/adb", "/setup/playlists", "/youtube/key",
                                 "/spotify/save", "/spotify/finish", "/spotify/disconnect", "/spotify/provider", "/music/play"))
        if not (path in auth_paths or protected):
            return False
        if not self._same_origin():
            self._send_json(403, {"ok": False, "error": "cross-site request refused"})
            return True

        if path in ("/auth/signup", "/auth/login"):
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return True
            username = str(data.get("username", "")).strip()
            password = data.get("password", "")
            ip_key, user_key = "ip:" + self._client_ip(), "user:" + username.lower()
            if _throttled(ip_key, 10) or _throttled(user_key, 20):
                self._send_json(429, {"ok": False, "error": "Too many attempts - wait a few minutes"})
                return True
            if path == "/auth/signup":
                # form mistakes don't count against the login lockout; only cap runaway sign-ups
                su_key = "signup:" + self._client_ip()
                if _throttled(su_key, 10):
                    self._send_json(429, {"ok": False, "error": "Too many new accounts - wait a few minutes"})
                    return True
                ok, err = create_account(username, password)
                if not ok:
                    self._send_json(400 if SIGNUP_OPEN else 403, {"ok": False, "error": err})
                    return True
                _note_fail(su_key)
                name = username
            else:
                name = check_login(username, password)
                if not name:
                    _note_fail(ip_key)
                    _note_fail(user_key)
                    self._send_json(401, {"ok": False, "error": "Wrong username or password"})
                    return True
                _fails.pop(user_key, None)
            token = new_session(name)
            self._send_json(200, {"ok": True, "username": name}, self._cookie(token, SESSION_SECONDS))
            return True

        if path == "/auth/password-public":
            # change the password from the login screen: username + current password + new password
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return True
            username = str(data.get("username", "")).strip()
            ip_key, user_key = "ip:" + self._client_ip(), "user:" + username.lower()
            if _throttled(ip_key, 10) or _throttled(user_key, 20):
                self._send_json(429, {"ok": False, "error": "Too many attempts - wait a few minutes"})
                return True
            real = check_login(username, data.get("oldPassword", ""))
            if not real:
                _note_fail(ip_key)
                _note_fail(user_key)
                self._send_json(401, {"ok": False, "error": "Wrong username or password"})
                return True
            ok, err = change_password(real, data.get("oldPassword", ""), data.get("newPassword", ""), "")
            if not ok:
                self._send_json(400, {"ok": False, "error": err})
                return True
            _fails.pop(user_key, None)
            self._send_json(200, {"ok": True, "username": real})
            return True

        if path == "/auth/logout":
            drop_session(self._token())
            self._send_json(200, {"ok": True}, self._cookie("", 0))
            return True

        # everything else here needs a logged-in account
        name = session_lookup(self._token())
        if not name:
            self._deny(path)
            return True
        if path.startswith("/friends/"):
            action = path.split("/friends/", 1)[1]
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return True
            fkey = "fr:" + name.lower()
            if _throttled(fkey, 400):
                self._send_json(429, {"ok": False, "error": "Slow down a little"})
                return True
            _note_fail(fkey)
            ok, err = friend_action(name, action, str(data.get("username", "")))
            body = friends_overview(name)
            body.update({"ok": ok, "error": err})
            self._send_json(200, body)
            return True
        if path == "/auth/password":
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return True
            user_key = "user:" + name.lower()
            if _throttled(user_key, 20):
                self._send_json(429, {"ok": False, "error": "Too many attempts - wait a few minutes"})
                return True
            ok, err = change_password(name, data.get("oldPassword", ""), data.get("newPassword", ""), self._token() or "")
            if not ok:
                if err == "Wrong password":
                    _note_fail(user_key)
                self._send_json(400, {"ok": False, "error": err})
                return True
            self._send_json(200, {"ok": True})
            return True
        if path == "/auth/delete":
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return True
            user_key = "user:" + name.lower()
            if _throttled(user_key, 20):
                self._send_json(429, {"ok": False, "error": "Too many attempts - wait a few minutes"})
                return True
            ok, err = delete_account(name, data.get("password", ""))
            if not ok:
                if err == "Wrong password":
                    _note_fail(user_key)
                self._send_json(400, {"ok": False, "error": err})
                return True
            self._send_json(200, {"ok": True}, self._cookie("", 0))
            return True
        if path == "/auth/rename":
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return True
            user_key = "user:" + name.lower()
            if _throttled(user_key, 20):
                self._send_json(429, {"ok": False, "error": "Too many attempts - wait a few minutes"})
                return True
            ok, err, new_name = rename_account(name, str(data.get("username", "")), data.get("password", ""))
            if not ok:
                if err == "Wrong password":
                    _note_fail(user_key)
                self._send_json(400, {"ok": False, "error": err})
                return True
            self._send_json(200, {"ok": True, "username": new_name})
            return True
        if path == "/save-config":
            data = self._read_json(limit=1700000)  # room for the profile picture (animated GIFs can be big)
            if data is None:
                self._send_json(400, {"status": "bad request"})
                return True
            set_account_config(name, data, replace_all=False)
            self._send_json(200, {"status": "ok"})
            return True
        if path == "/clear-config":
            prev = get_account_config(name)
            keep = prev.get("avatar")
            keepCrop = prev.get("avatarCrop")
            fresh = dict(DEFAULT_CONFIG)
            if isinstance(keep, str):
                fresh["avatar"] = keep
            if isinstance(keepCrop, str):
                fresh["avatarCrop"] = keepCrop
            if isinstance(prev.get("bio"), str):
                fresh["bio"] = prev["bio"]
            if isinstance(prev.get("showListening"), bool):
                fresh["showListening"] = prev["showListening"]
            if isinstance(prev.get("socials"), list):
                fresh["socials"] = prev["socials"]
            set_account_config(name, fresh)
            self._send_json(200, {"status": "cleared"})
            return True
        if path == "/lastfm/disconnect":
            disconnect_lastfm(name)
            self._send_json(200, {"status": "disconnected"})
            return True
        if path == "/youtube/disconnect":
            youtube_disconnect()
            self._send_json(200, {"ok": True})
            return True
        if path == "/youtube/key":
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return True
            ok, err = yt_save_key(str(data.get("key", "")))
            self._send_json(200, {"ok": ok, "error": err})
            return True
        if path == "/spotify/save":
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return True
            if spotify is None:
                self._send_json(200, {"ok": False, "error": "spotify.py is missing on the server"})
                return True
            ok, err = spotify.save_client(str(data.get("clientId", "")), str(data.get("clientSecret", "")))
            if ok and "redirect" in data:
                ok, err = spotify.save_redirect(str(data.get("redirect", "")))
            self._send_json(200, {"ok": ok, "error": err,
                                  "redirect": spotify.redirect_uri_for(self._base_url() + "/spotify/callback")})
            return True
        if path == "/spotify/finish":
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return True
            if spotify is None:
                self._send_json(200, {"ok": False, "error": "spotify.py is missing on the server"})
                return True
            ok, err = spotify.finish_manual(str(data.get("url", "")))
            if ok:
                _status_cache["data"] = None
            self._send_json(200, {"ok": ok, "error": err})
            return True
        if path == "/spotify/disconnect":
            if spotify is not None:
                spotify.disconnect()
            self._send_json(200, {"ok": True})
            return True
        if path == "/spotify/provider":
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return True
            provider = str(data.get("provider", "")).strip().lower()
            if provider not in ("youtube", "spotify"):
                self._send_json(400, {"ok": False, "error": "pick youtube or spotify"})
                return True
            if provider == "spotify" and (spotify is None or not spotify.connected()):
                self._send_json(200, {"ok": False, "error": "Connect Spotify first"})
                return True
            creds.set("playback_provider", provider)
            _status_cache["data"] = None
            _ctx.update({"pid": None, "user": creds.get_user(), "tracks": [], "ready": False, "last": 0})
            with _next_lock:
                _next_cache.clear()
            self._send_json(200, {"ok": True, "provider": provider})
            return True
        if path == "/music/play":
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return True
            ok, err = music_play(str(data.get("id", "")), str(data.get("track", "")), str(data.get("artist", "")))
            self._send_json(200, {"ok": ok, "error": err})
            return True
        if path == "/setup/adb":
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return True
            ok, err = setup_adb(str(data.get("addr", "")).strip(), str(data.get("pairAddr", "")).strip(),
                                str(data.get("code", "")).strip())
            self._send_json(200, {"ok": ok, "error": err})
            return True
        if path == "/setup/playlists":
            data = self._read_json(limit=400000)  # a copied request with cookies is long
            if data is None:
                self._send_json(400, {"ok": False, "error": "That was too long or not readable"})
                return True
            self._send_json(200, setup_playlists(str(data.get("text", ""))))
            return True
        return False  # play-playlist and media controls: logged in, carry on to the original code


    def _with_account(self, fn):
        path = urlparse(self.path).path
        if not path.startswith(_YT_PATHS):
            creds.set_user("-")
            try:
                fn()
            finally:
                creds.set_user(None)
            return
        try:
            name = session_lookup(self._token())
        except Exception:
            name = None
        with _user_lock:
            _bind_user(name)
            try:
                fn()
            finally:
                creds.set_user(None)

    def do_GET(self):
        self._with_account(self._do_GET)

    def do_POST(self):
        self._with_account(self._do_POST)

    def _send_helper_zip(self):
        """The browser helper (ytm-helper/), zipped on the fly with this server's own address in it."""
        import io, zipfile
        root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ytm-helper")
        proto = "https" if self.headers.get("X-Forwarded-Proto", "").lower() == "https" else "http"
        host = self.headers.get("Host", "") or "localhost:%s" % PORT
        buf = io.BytesIO()
        try:
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                for name in sorted(os.listdir(root)):
                    full = os.path.join(root, name)
                    if not os.path.isfile(full):
                        continue
                    if name == "config.js":
                        z.writestr("vizah-ytm-helper/config.js",
                                   "// Written by your Vizah server.\nvar VIZAH = %s;\n" % json.dumps("%s://%s" % (proto, host)))
                    else:
                        z.write(full, "vizah-ytm-helper/" + name)
        except Exception:
            self.send_response(404)
            self.end_headers()
            return
        data = buf.getvalue()
        self.send_response(200)
        self.send_header("Content-Type", "application/zip")
        self.send_header("Content-Disposition", 'attachment; filename="vizah-ytm-helper.zip"')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/ytm-helper.zip":
            self._send_helper_zip()
            return
        if self._accounts_get(parsed):  # accounts + login gate (added)
            return
        if social and social.handle_get(self, parsed, sys.modules[__name__]):  # DMs + friend profiles (added)
            return
        if lyrics_src and lyrics_src.handle_get(self, parsed, sys.modules[__name__]):  # extra lyric sources (added)
            return
        if parsed.path == "/config":
            payload = json.dumps(load_config()).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if parsed.path == "/playlists":
            force = "refresh=1" in (parsed.query or "")
            payload = json.dumps(list_playlists(force)).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if parsed.path.startswith("/playlist-tracks/"):
            from urllib.parse import unquote
            pid = unquote(parsed.path.split("/playlist-tracks/", 1)[1])
            tracks, code, err = get_playlist_tracks(pid)
            body = {"ok": not code, "code": code, "error": err,
                    "tracks": [{"id": t["videoId"], "title": t["title"], "artist": t["artist"],
                                "thumb": t.get("thumbSmall") or t.get("thumb") or "",
                                "art": t.get("thumbBig") or t.get("thumb") or ""} for t in tracks]}
            payload = json.dumps(body).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if parsed.path == "/media/status":
            payload = json.dumps(media_status_cached()).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if parsed.path == "/media/up-next":
            q = parse_qs(parsed.query or "").get("q", [""])[0]
            payload = json.dumps(up_next(q)).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        return super().do_GET()

    def _do_POST(self):
        parsed = urlparse(self.path)
        if self._accounts_post(parsed):  # accounts + login gate (added)
            return
        if social and social.handle_post(self, parsed, sys.modules[__name__]):  # DMs (added)
            return
        if parsed.path == "/save-config":
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length)

            try:
                data = json.loads(raw.decode("utf-8"))
            except Exception:
                self.send_response(400)
                self.end_headers()
                return

            save_config(data)
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status":"ok"}')
            return

        if parsed.path == "/clear-config":
            save_config({
                "user": "",
                "apiKey": "",
                "bg1": "#110d18",
                "bg2": "#4d1733",
                "bg3": "#0d1b2a",
                "acc1": "#ff7a59",
                "acc2": "#ffd166",
                "acc3": "#79e7ff"
            })
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status":"cleared"}')
            return

        if parsed.path.startswith("/play-playlist/"):
            from urllib.parse import unquote
            qs = parse_qs(parsed.query or "")
            vid = (qs.get("v") or [None])[0]
            try:
                idx = int((qs.get("i") or [""])[0])
            except ValueError:
                idx = None
            ok, err = play_playlist(unquote(parsed.path.split("/play-playlist/", 1)[1]), vid, idx)
            payload = json.dumps({"ok": ok, "error": err}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if parsed.path == "/playlist-add":
            data = self._read_json()
            if data is None:
                self._send_json(400, {"ok": False, "error": "bad request"})
                return
            ok, err, code = add_to_playlist(data.get("playlist"), data.get("id"), data.get("title"), data.get("artist"))
            _status_cache["data"] = None
            self._send_json(200, {"ok": ok, "error": err, "code": code})
            return

        if parsed.path.startswith("/ytm/play-song/"):
            from urllib.parse import unquote
            ok, err = play_song(unquote(parsed.path.split("/ytm/play-song/", 1)[1]))
            payload = json.dumps({"ok": ok, "error": err}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if parsed.path.startswith("/media/"):
            ok, err, media = media_action(parsed.path.split("/media/", 1)[1])
            _status_cache["data"] = None
            body = {"ok": ok, "error": err, "playing": None}
            if media:
                body.update(media)
                body["connected"] = True
            payload = json.dumps(body).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        self.send_response(404)
        self.end_headers()

    def log_message(self, *args):
        pass

if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    try:
        old_key = os.path.expanduser("~/.vizah_youtube_key")   # earlier build kept the API key here
        if os.path.exists(old_key) and not creds.has("yt_api_key"):
            with open(old_key, "r", encoding="utf-8") as fh:
                creds.set("yt_api_key", fh.readline().strip())
        creds.migrate(YTM_AUTH)   # label creds.txt, import an older YouTube Music login if there is one
        account_count()           # moves old password hashes into creds.txt
        _lo = _legacy_owner()
        if _lo:
            creds.migrate_legacy(_lo)   # the shared YouTube login becomes the first account's
    except Exception as e:
        print("Warning: couldn't prepare creds.txt:", e)
    ensure_dev_accounts()
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print(f"Server running on http://0.0.0.0:{PORT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
