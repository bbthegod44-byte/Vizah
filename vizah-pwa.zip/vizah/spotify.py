"""Spotify support for Vizah - standard library only (no pip packages).

Uses Spotify's Web API with the OAuth 2.0 Authorization Code + PKCE flow.  Each
Vizah account keeps its own Spotify app credentials and refresh token in
creds.txt (see creds.py), exactly like the YouTube Music cookie.  Access tokens
are short lived and cached in memory only.

The module deliberately mirrors the shape of the YouTube Music helpers in
server.py so the rest of the app can switch providers without special cases:

    playlists()          -> {"ok", "playlists", "code", "error"}
    playlist_tracks(pid) -> (tracks, code, error)
    search(q)            -> {"ok", "code", "error", "results"}
    play_playlist(...)   -> (ok, error)
    play_song(...)       -> (ok, error)
    media_status()       -> {"connected", "playing", "position", ...}
    media_action(action) -> (ok, error, media)
"""
import base64
import hashlib
import json
import re
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import creds

AUTHORIZE_URL = "https://accounts.spotify.com/authorize"
TOKEN_URL = "https://accounts.spotify.com/api/token"
API_ROOT = "https://api.spotify.com/v1"

SCOPES = " ".join((
    "user-read-playback-state",
    "user-modify-playback-state",
    "user-read-currently-playing",
    "playlist-read-private",
    "playlist-read-collaborative",
    "user-library-read",
    "user-read-private",
    "playlist-modify-public",      # add songs to your playlists
    "playlist-modify-private",
    "user-library-modify",         # add songs to Liked Songs
))

_CLIENT_RE = re.compile(r"^[A-Za-z0-9]{16,64}$")
_SP_ID_RE = re.compile(r"^[A-Za-z0-9]{10,40}$")
_ID_PREFIX = "sp_"
LIKED_ID = "sp_liked"

_lock = threading.RLock()
_tokens = {}          # user -> (access_token, expires_at)
_states = {}          # state -> {user, verifier, redirect, t}
_acct_cache = {}      # user -> (timestamp, dict)
_pl_cache = {}        # user -> (timestamp, list)
_tracks_cache = {}    # (user, pid) -> (timestamp, list)

TOKEN_TTL = 3300      # Spotify access tokens last ~1h; refresh a little early
STATE_TTL = 600
CACHE_TTL = 300


# --------------------------------------------------------------------------- helpers
def _now():
    return time.time()


def _user():
    return creds.get_user() or ""


def _clean(value, limit=400):
    value = str(value or "").replace("\r", " ").replace("\n", " ").strip()
    return value[:limit]


def _strip(pid):
    """Turn a public id ('sp_abc') back into Spotify's own id ('abc')."""
    pid = str(pid or "")
    if pid.startswith(_ID_PREFIX):
        pid = pid[len(_ID_PREFIX):]
    return pid


def public_id(spotify_id):
    return _ID_PREFIX + str(spotify_id or "")


def is_spotify_id(value):
    return isinstance(value, str) and value.startswith(_ID_PREFIX)


def configured():
    return bool(creds.get("spotify_client_id"))


def connected():
    # a refresh token is useless without the app's Client ID, so both must be present
    return bool(creds.get("spotify_client_id") and creds.get("spotify_refresh_token"))


def forget():
    """Drop in-memory tokens/account data when the active Vizah account changes."""
    with _lock:
        _tokens.clear()
        _acct_cache.clear()
        _pl_cache.clear()
        _tracks_cache.clear()


# --------------------------------------------------------------------------- HTTP
def _http(method, url, data=None, headers=None, timeout=15):
    """Returns (status, body_bytes). Never raises for HTTP error statuses."""
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data).encode("utf-8")
    req = urllib.request.Request(url, data=body, method=method)
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    if body is not None:
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.getcode(), r.read()
    except urllib.error.HTTPError as e:
        try:
            return e.code, e.read()
        except Exception:
            return e.code, b""
    except Exception as e:
        return 0, str(e).encode("utf-8", "replace")


def _json(raw):
    try:
        return json.loads(raw.decode("utf-8")) if raw else {}
    except Exception:
        return {}


def _basic(client_id, client_secret):
    raw = ("%s:%s" % (client_id, client_secret)).encode("utf-8")
    return "Basic " + base64.b64encode(raw).decode("ascii")


def _token_request(data):
    client_id = creds.get("spotify_client_id")
    client_secret = creds.get("spotify_client_secret")
    headers = {}
    if client_secret:
        headers["Authorization"] = _basic(client_id, client_secret)
    else:
        data = dict(data, client_id=client_id)
    status, raw = _http("POST", TOKEN_URL, data, headers)
    return status, _json(raw)


def _access_token(force=False):
    """Returns (token, code, error). code is '' on success."""
    user = _user()
    if not user:
        return None, "login", "log in to Vizah first"
    if not configured():
        return None, "not_setup", "add your Spotify app Client ID first"
    refresh = creds.get("spotify_refresh_token")
    if not refresh:
        return None, "not_setup", "Spotify isn't connected yet"
    with _lock:
        hit = _tokens.get(user)
        if hit and not force and hit[1] > _now() + 60:
            return hit[0], "", ""
    status, data = _token_request({
        "grant_type": "refresh_token",
        "refresh_token": refresh,
    })
    token = data.get("access_token")
    if status != 200 or not token:
        err = data.get("error_description") or data.get("error") or "couldn't refresh the Spotify login"
        low = str(err).lower()
        if "invalid" in low or "expired" in low or status in (400, 401):
            return None, "auth", "Spotify login expired - reconnect it"
        return None, "error", str(err)[:200]
    expires = _now() + int(data.get("expires_in") or TOKEN_TTL)
    with _lock:
        _tokens[user] = (token, expires)
    if data.get("refresh_token"):
        try:
            creds.set("spotify_refresh_token", data["refresh_token"])
        except Exception:
            pass
    return token, "", ""


def _api(method, path, params=None, body=None, retry=True):
    """Returns (status, data, code, error). code is '' when the call worked."""
    token, code, err = _access_token()
    if not token:
        return 0, {}, code, err
    url = API_ROOT + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    data = None
    headers = {"Authorization": "Bearer " + token}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method)
    for k, v in headers.items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            status = r.getcode()
            raw = r.read()
    except urllib.error.HTTPError as e:
        status = e.code
        try:
            raw = e.read()
        except Exception:
            raw = b""
    except Exception as e:
        return 0, {}, "error", str(e)[:200]
    payload = _json(raw)
    if status == 401 and retry:
        _access_token(force=True)
        return _api(method, path, params, body, retry=False)
    if status in (200, 201, 204):
        return status, payload, "", ""
    reason = (payload.get("error") or {})
    if isinstance(reason, dict):
        message = reason.get("message") or reason.get("reason") or ""
        reason = reason.get("reason") or ""
    else:
        message = str(reason)
    low = (str(reason) + " " + str(message)).lower()
    if "premium" in low:
        return status, payload, "premium", "Spotify playback needs Premium"
    if "no active device" in low or "device not found" in low:
        return status, payload, "device", "Open Spotify on a device first"
    if "scope" in low or "permission" in low:
        return status, payload, "scope", "Spotify didn't allow that - reconnect and accept the permissions"
    if status == 401:
        return status, payload, "auth", "Spotify login expired - reconnect it"
    if status == 403:
        # not an expired login: Spotify says why (app owner needs Premium, account not added under the app's
        # "User management", a playlist you don't own, ...) so show that instead of "login expired"
        return status, payload, "forbidden", (message or "Spotify refused that request")[:200]
    if status == 429:
        return status, payload, "error", "Spotify says slow down - try again in a moment"
    return status, payload, "error", (message or "Spotify error %s" % status)[:200]


# --------------------------------------------------------------------------- OAuth
_LOOPBACK_HOSTS = ("127.0.0.1", "localhost", "::1", "[::1]")


def check_redirect(uri):
    """Spotify only accepts HTTPS redirect URIs, plus plain HTTP on the loopback
    interface (127.0.0.1 / localhost). Returns (ok, kind, note); kind is one of
    'https', 'loopback' or 'insecure'."""
    uri = _clean(uri, 400)
    if not uri:
        return False, "insecure", "Add the redirect URI shown here to your Spotify app"
    try:
        u = urllib.parse.urlparse(uri)
    except Exception:
        return False, "insecure", "That redirect URI isn't valid"
    scheme = (u.scheme or "").lower()
    host = (u.hostname or "").lower()
    if not host:
        return False, "insecure", "That redirect URI isn't valid"
    if scheme == "https":
        return True, "https", ""
    if scheme == "http" and host in _LOOPBACK_HOSTS:
        return True, "loopback", ""
    return False, "insecure", (
        "Spotify only accepts HTTPS redirect URIs, or plain http://127.0.0.1 / http://localhost. "
        "You're on %s://%s - add an HTTPS address below, or open Vizah at http://127.0.0.1:%s on this device."
        % (scheme or "http", host, urllib.parse.urlparse(uri).port or 8000))


def redirect_uri(base):
    """The redirect URI to use: the account's override if set, else BASE/spotify/callback."""
    override = _clean(creds.get("spotify_redirect_uri"), 400)
    return override or base


def redirect_uri_for(base):
    """Public alias used by server.py: the effective redirect URI for BASE."""
    return redirect_uri(base)


def save_redirect(uri):
    """Store (or clear, with '') a custom redirect URI. Returns (ok, error)."""
    uri = _clean(uri, 400)
    if not uri:
        creds.delete("spotify_redirect_uri")
        return True, ""
    if not uri.lower().startswith(("http://", "https://")):
        return False, "The redirect URI must start with http:// or https://"
    if re.search(r"[\s\"'<>]", uri):
        return False, "That redirect URI isn't valid"
    ok, kind, note = check_redirect(uri)
    if not ok:
        return False, note
    creds.set("spotify_redirect_uri", uri)
    return True, ""


def save_client(client_id, client_secret=""):
    client_id = _clean(client_id, 80)
    client_secret = _clean(client_secret, 120)
    if not _CLIENT_RE.match(client_id):
        return False, "That doesn't look like a Spotify Client ID"
    if client_secret and len(client_secret) < 10:
        return False, "That doesn't look like a Spotify Client Secret"
    creds.set("spotify_client_id", client_id)
    creds.set("spotify_client_secret", client_secret)
    return True, ""


def connect_url(redirect_uri):
    """Build the Spotify authorize URL and remember the PKCE verifier for the callback."""
    client_id = creds.get("spotify_client_id")
    if not _CLIENT_RE.match(client_id or ""):
        return False, "", "Add your Spotify app Client ID first"
    redirect_uri = redirect_uri_for(redirect_uri)
    ok_r, _kind, note = check_redirect(redirect_uri)
    if not ok_r:
        return False, "", note
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode("ascii")).digest()).rstrip(b"=").decode("ascii")
    state = secrets.token_urlsafe(24)
    with _lock:
        now = _now()
        for k in [k for k, v in _states.items() if now - v["t"] > STATE_TTL]:
            _states.pop(k, None)
        _states[state] = {"user": _user(), "verifier": verifier, "redirect": redirect_uri, "t": now}
    params = {
        "client_id": client_id,
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "scope": SCOPES,
        "state": state,
        "code_challenge_method": "S256",
        "code_challenge": challenge,
        "show_dialog": "true",
    }
    return True, AUTHORIZE_URL + "?" + urllib.parse.urlencode(params), ""


def handle_callback(code, state):
    """Exchange the authorization code for a refresh token. Returns (ok, error)."""
    with _lock:
        entry = _states.pop(state or "", None)
    if not entry:
        return False, "That Spotify login link expired - try Connect again"
    if entry["user"] != _user():
        return False, "That Spotify login belongs to a different Vizah account"
    if not code:
        return False, "Spotify didn't send an authorization code"
    data = {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": entry["redirect"],
        "code_verifier": entry["verifier"],
    }
    status, payload = _token_request(data)
    token = payload.get("access_token")
    refresh = payload.get("refresh_token")
    if status != 200 or not refresh:
        err = payload.get("error_description") or payload.get("error") or "Spotify refused the login"
        return False, str(err)[:200]
    creds.set("spotify_refresh_token", refresh)
    with _lock:
        _tokens[_user()] = (token, _now() + int(payload.get("expires_in") or TOKEN_TTL))
        _acct_cache.pop(_user(), None)
        _pl_cache.pop(_user(), None)
    # Remember who this is, so the settings card can show a name even offline.
    status, me, code_, err = _api("GET", "/me")
    if status == 200 and isinstance(me, dict):
        creds.set("spotify_user", _clean(me.get("id"), 100))
        creds.set("spotify_display_name", _clean(me.get("display_name"), 100))
        images = me.get("images") or []
        photo = ""
        if images and isinstance(images[0], dict):
            photo = _safe_photo(images[0].get("url"))
        creds.set("spotify_photo", photo)
        with _lock:
            _acct_cache[_user()] = (_now(), _account_from(me))
    return True, ""


def finish_manual(url):
    """Completes the login from a pasted callback address.

    Useful when Spotify's redirect lands on a page that can't reach this server
    (a tunnel that expired, a different host, or a blank error page): copy the
    whole address bar and paste it here. Accepts a full URL, a query string, or
    just 'code=...&state=...'.
    """
    raw = _clean(url, 2000)
    if not raw:
        return False, "Paste the address Spotify sent you to"
    q = ""
    try:
        u = urllib.parse.urlparse(raw)
        q = u.query or ""
    except Exception:
        q = ""
    if not q and "=" in raw:
        q = raw.split("?", 1)[-1]
    try:
        qs = urllib.parse.parse_qs(q)
    except Exception:
        return False, "That doesn't look like a Spotify login link"
    err = (qs.get("error") or [""])[0]
    if err:
        return False, "Spotify login was cancelled" if err == "access_denied" else ("Spotify error: " + err[:120])
    code = (qs.get("code") or [""])[0]
    state = (qs.get("state") or [""])[0]
    if not code:
        return False, "That link has no authorization code in it"
    if not state:
        return False, "That link is missing its state value - press Connect again"
    return handle_callback(code, state)


def disconnect():
    with _lock:
        _tokens.pop(_user(), None)
        _acct_cache.pop(_user(), None)
        _pl_cache.pop(_user(), None)
        for k in [k for k in _tracks_cache if k[0] == _user()]:
            _tracks_cache.pop(k, None)
    for key in ("spotify_refresh_token", "spotify_user", "spotify_display_name", "spotify_photo"):
        try:
            creds.delete(key)
        except Exception:
            pass


# --------------------------------------------------------------------------- account
_PHOTO_HOSTS = ("scdn.co", "spotifycdn.com", "spotify.com")


def _safe_photo(url):
    try:
        u = urllib.parse.urlparse(url or "")
    except Exception:
        return ""
    host = (u.hostname or "").lower()
    if u.scheme != "https" or not any(host == h or host.endswith("." + h) for h in _PHOTO_HOSTS):
        return ""
    return url


def _account_from(me):
    images = me.get("images") or []
    photo = ""
    if images and isinstance(images[0], dict):
        photo = _safe_photo(images[0].get("url"))
    return {
        "ok": True,
        "connected": True,
        "code": "",
        "error": "",
        "name": _clean(me.get("display_name") or me.get("id"), 100),
        "handle": _clean(me.get("id"), 100),
        "photo": photo,
        "product": _clean(me.get("product"), 20),
    }


def status(redirect_uri=""):
    """Settings-card status. Never fails: always returns a usable dict."""
    effective = redirect_uri_for(redirect_uri)
    ok_r, kind, note = check_redirect(effective)
    base = {
        "ok": True, "connected": False, "code": "", "error": "",
        "name": "", "handle": "", "photo": "", "product": "",
        "configured": configured(), "clientId": creds.get("spotify_client_id"),
        "redirect": effective, "provider": (creds.get("playback_provider") or ""),
        "redirectOk": ok_r, "redirectKind": kind, "redirectNote": note,
        "redirectOverride": _clean(creds.get("spotify_redirect_uri"), 400),
        "suggestedRedirect": redirect_uri,
    }
    if not configured():
        return base
    if not connected():
        return base
    user = _user()
    with _lock:
        hit = _acct_cache.get(user)
        if hit and _now() - hit[0] < CACHE_TTL:
            out = dict(base)
            out.update(hit[1])
            return out
    st, me, code, err = _api("GET", "/me")
    if st == 200 and isinstance(me, dict):
        acct = _account_from(me)
        with _lock:
            _acct_cache[user] = (_now(), acct)
        out = dict(base)
        out.update(acct)
        return out
    out = dict(base)
    out.update({"connected": True, "code": code or "error", "error": err or "Spotify didn't answer",
                "name": creds.get("spotify_display_name"), "handle": creds.get("spotify_user"),
                "photo": creds.get("spotify_photo")})
    return out


# --------------------------------------------------------------------------- library
def _thumb(images, smallest=False):
    items = [x for x in (images or []) if isinstance(x, dict) and x.get("url")]
    if not items:
        return ""
    items.sort(key=lambda x: x.get("width") or 0)
    return items[0]["url"] if smallest else items[-1]["url"]


def playlists(force=False):
    user = _user()
    with _lock:
        hit = _pl_cache.get(user)
        if hit and not force and _now() - hit[0] < CACHE_TTL:
            return {"ok": True, "playlists": hit[1], "code": "", "error": ""}
    items = [{"id": LIKED_ID, "title": "Liked Songs", "count": "", "thumb": ""}]
    seen = {LIKED_ID}
    offset = 0
    while offset < 200:
        st, data, code, err = _api("GET", "/me/playlists", {"limit": 50, "offset": offset})
        if st != 200:
            return {"ok": False, "playlists": [], "code": code or "error", "error": err}
        for p in (data.get("items") or []):
            if not isinstance(p, dict) or not p.get("id"):
                continue
            pid = public_id(p["id"])
            if pid in seen:
                continue
            seen.add(pid)
            total = ((p.get("items") or p.get("tracks") or {}).get("total"))   # "items" since Feb 2026
            items.append({
                "id": pid,
                "title": _clean(p.get("name") or "Untitled", 200),
                "count": str(total) if total is not None else "",
                "thumb": _thumb(p.get("images")),
            })
        if not data.get("next"):
            break
        offset += 50
    with _lock:
        _pl_cache[user] = (_now(), items)
    return {"ok": True, "playlists": items, "code": "", "error": ""}


def _track_info(t):
    if not isinstance(t, dict):
        return None
    track = t.get("item") if isinstance(t.get("item"), dict) else (t.get("track") if isinstance(t.get("track"), dict) else t)
    if not isinstance(track, dict) or not track.get("id"):
        return None
    if track.get("type") and track.get("type") != "track":
        return None
    names = [a.get("name", "") for a in (track.get("artists") or []) if isinstance(a, dict) and a.get("name")]
    images = ((track.get("album") or {}).get("images")) or []
    return {
        "videoId": public_id(track["id"]),
        "title": _clean(track.get("name") or "", 300),
        "artist": _clean(", ".join(names), 200),
        "artists": names,
        "thumb": _thumb(images),
        "thumbSmall": _thumb(images, smallest=True),
        "thumbBig": _thumb(images),
    }


def playlist_tracks(pid, force=False):
    """Returns (tracks, code, error). Tracks use the same shape as YouTube's."""
    pid = str(pid or "")
    if pid != LIKED_ID and (not pid.startswith(_ID_PREFIX) or not _SP_ID_RE.match(_strip(pid) or "")):
        return [], "error", "bad playlist id"      # (Liked Songs is "sp_liked": shorter than a real playlist id)
    user = _user()
    ck = (user, pid)
    with _lock:
        hit = _tracks_cache.get(ck)
        if hit and not force and _now() - hit[0] < CACHE_TTL:
            return hit[1], "", ""
    tracks = []
    if pid == LIKED_ID:
        offset = 0
        while offset < 500:
            st, data, code, err = _api("GET", "/me/tracks", {"limit": 50, "offset": offset})
            if st != 200:
                return [], code or "error", err
            for item in (data.get("items") or []):
                info = _track_info(item)
                if info:
                    tracks.append(info)
            if not data.get("next"):
                break
            offset += 50
    else:
        sid = _strip(pid)
        offset = 0
        while offset < 500:
            st, data, code, err = _api(
                "GET", "/playlists/%s/items" % urllib.parse.quote(sid),
                {"limit": 100, "offset": offset, "additional_types": "track"})
            if st != 200:
                if code == "forbidden" or st in (403, 404):
                    return [], "not_readable", ("Spotify only lets Vizah list the songs of playlists you own or "
                                                "collaborate on. You can still play this one from the start.")
                return [], code or "error", err
            for item in (data.get("items") or []):
                info = _track_info(item)
                if info:
                    tracks.append(info)
            if not data.get("next"):
                break
            offset += 100
    with _lock:
        if len(_tracks_cache) >= 24:
            _tracks_cache.pop(next(iter(_tracks_cache)))
        _tracks_cache[ck] = (_now(), tracks)
    return tracks, "", ""


def search(q):
    q = _clean(q, 100)
    if not q:
        return {"ok": True, "code": "", "error": "", "results": []}
    st, data, code, err = _api("GET", "/search", {"q": q, "type": "track", "limit": 10})   # max 10 since Feb 2026
    if st != 200:
        return {"ok": False, "code": code or "error", "error": err, "results": []}
    out = []
    for r in (((data.get("tracks") or {}).get("items")) or []):
        if not isinstance(r, dict) or not r.get("id"):
            continue
        names = [a.get("name", "") for a in (r.get("artists") or []) if isinstance(a, dict) and a.get("name")]
        ms = r.get("duration_ms") or 0
        dur = "%d:%02d" % (ms // 60000, (ms // 1000) % 60) if ms else ""
        out.append({
            "id": public_id(r["id"]),
            "title": _clean(r.get("name") or "Untitled", 300),
            "artist": _clean(", ".join(names), 200),
            "thumb": _thumb(((r.get("album") or {}).get("images"))),
            "duration": dur,
        })
    return {"ok": True, "code": "", "error": "", "results": out}


def add_to_playlist(pid, track_id):
    """Adds one song to a playlist (or to Liked Songs). Returns (ok, error, code).

    code is '' on success, 'duplicate' when it was already there, 'scope' when the
    saved login predates the playlist-editing permission (reconnect fixes it)."""
    pid = str(pid or "")
    tid = _strip(track_id)
    if not _SP_ID_RE.match(tid or ""):
        return False, "bad song id", "error"
    if pid != LIKED_ID and (not pid.startswith(_ID_PREFIX) or not _SP_ID_RE.match(_strip(pid) or "")):
        return False, "bad playlist id", "error"
    uri = "spotify:track:" + tid
    # skip songs that are already in it (only when the playlist can be listed)
    try:
        have, hcode, _ = playlist_tracks(pid)
        if not hcode and any(_strip(t.get("videoId")) == tid for t in have):
            return False, "That song is already in this playlist", "duplicate"
    except Exception:
        pass
    reconnect = "Reconnect Spotify in Profile & connections so Vizah can edit your playlists"
    if pid == LIKED_ID:
        st, data, code, err = _api("PUT", "/me/library", {"uris": uri})
        if st not in (200, 201, 204) and st in (400, 404, 405):
            st, data, code, err = _api("PUT", "/me/tracks", body={"ids": [tid]})
    else:
        path = "/playlists/%s/items" % urllib.parse.quote(_strip(pid))
        st, data, code, err = _api("POST", path, body={"uris": [uri]})
        if st not in (200, 201, 204) and st in (404, 405):
            st, data, code, err = _api("POST", "/playlists/%s/tracks" % urllib.parse.quote(_strip(pid)), body={"uris": [uri]})
    if st in (200, 201, 204):
        with _lock:                       # counts and song lists changed
            _tracks_cache.pop((_user(), pid), None)
            _pl_cache.pop(_user(), None)
        return True, "", ""
    if code == "scope":
        return False, reconnect, "scope"
    if code == "forbidden":
        return False, "Spotify only lets you add to playlists you own or collaborate on", "forbidden"
    return False, err or "Spotify couldn't add that song", code or "error"


# --------------------------------------------------------------------------- playback
def _device_id():
    """Returns (device_id, code, error). Picks the active device, else the first one."""
    st, data, code, err = _api("GET", "/me/player")
    if st == 200 and isinstance(data, dict):
        dev = data.get("device") or {}
        if dev.get("id"):
            return dev["id"], "", ""
    st, data, code, err = _api("GET", "/me/player/devices")
    if st != 200:
        return None, code or "device", err or "Open Spotify on a device first"
    devices = [d for d in (data.get("devices") or []) if isinstance(d, dict) and d.get("id")]
    if not devices:
        return None, "device", "Open Spotify on a device first"
    devices.sort(key=lambda d: (0 if d.get("is_active") else 1, 0 if not d.get("is_restricted") else 1))
    dev_id = devices[0]["id"]
    # Make it the active device so play commands land there.
    _api("PUT", "/me/player", body={"device_ids": [dev_id], "play": False})
    return dev_id, "", ""


def _play(body):
    dev, code, err = _device_id()
    if not dev:
        return False, err
    st, data, code, err = _api("PUT", "/me/player/play", {"device_id": dev}, body)
    if st not in (200, 204):
        return False, err or "Spotify couldn't start playback"
    return True, ""


def play_playlist(pid, track_id=None, index=None):
    """Starts a Spotify playlist (or Liked Songs) on the active device."""
    pid = str(pid or "")
    if not pid.startswith(_ID_PREFIX):
        return False, "bad playlist id"
    if pid == LIKED_ID:
        tracks, code, err = playlist_tracks(LIKED_ID)
        if code:
            return False, err or "Couldn't load your Liked Songs"
        uris = ["spotify:track:" + _strip(t["videoId"]) for t in tracks[:100]]
        if not uris:
            return False, "Your Liked Songs are empty"
        body = {"uris": uris}
        if isinstance(index, int) and 0 <= index < len(uris):
            body["offset"] = {"position": index}
        return _play(body)
    sid = _strip(pid)
    if not _SP_ID_RE.match(sid):
        return False, "bad playlist id"
    body = {"context_uri": "spotify:playlist:" + sid}
    if track_id:
        body["offset"] = {"uri": "spotify:track:" + _strip(track_id)}
    elif isinstance(index, int) and index >= 0:
        body["offset"] = {"position": index}
    return _play(body)


def play_song(track_id):
    tid = _strip(track_id)
    if not _SP_ID_RE.match(tid or ""):
        return False, "bad song id"
    return _play({"uris": ["spotify:track:" + tid]})


def media_status():
    if not connected():
        return {"connected": False, "playing": None, "error": "Spotify isn't connected"}
    st, data, code, err = _api("GET", "/me/player")
    if st == 204:
        return {"connected": True, "playing": None, "error": ""}
    if st != 200 or not isinstance(data, dict):
        return {"connected": False, "playing": None, "error": err or "Spotify didn't answer"}
    item = data.get("item") or {}
    names = [a.get("name", "") for a in (item.get("artists") or []) if isinstance(a, dict) and a.get("name")]
    title = _clean(item.get("name") or "", 300)
    artist = _clean(", ".join(names), 200)
    desc = title + ((", " + artist) if artist else "")
    playing = bool(data.get("is_playing"))
    return {
        "connected": True,
        "playing": playing,
        "state": 3 if playing else 2,
        "position": int(data.get("progress_ms") or 0),
        "speed": 1.0,
        "desc": desc,
        "package": "spotify",
        "error": "",
    }


def media_action(action):
    """Returns (ok, error, media_dict_or_None)."""
    if action not in ("playpause", "play", "pause", "next", "prev"):
        return False, "unknown action", None
    if not connected():
        return False, "Spotify isn't connected", None
    if action == "playpause":
        cur = media_status()
        action = "pause" if cur.get("playing") else "play"
    if action == "play":
        dev, code, err = _device_id()
        if not dev:
            return False, err, None
        st, data, code, err = _api("PUT", "/me/player/play", {"device_id": dev})
    elif action == "pause":
        st, data, code, err = _api("PUT", "/me/player/pause")
    elif action == "next":
        st, data, code, err = _api("POST", "/me/player/next")
    else:
        st, data, code, err = _api("POST", "/me/player/previous")
    if st not in (200, 204):
        if code == "device":
            dev, _, _ = _device_id()
            if dev:
                # one retry after waking a device
                if action == "play":
                    st, data, code, err = _api("PUT", "/me/player/play", {"device_id": dev})
                elif action == "pause":
                    st, data, code, err = _api("PUT", "/me/player/pause", {"device_id": dev})
                elif action == "next":
                    st, data, code, err = _api("POST", "/me/player/next", {"device_id": dev})
                else:
                    st, data, code, err = _api("POST", "/me/player/previous", {"device_id": dev})
        if st not in (200, 204):
            return False, err or "Spotify couldn't do that", None
    return True, "", media_status()
