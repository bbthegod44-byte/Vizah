"""Extra synced-lyrics sources for Vizah (added).

Self-contained on purpose: server.py only calls handle_get(). Standard library only, no API keys.
These sites do not allow requests straight from a browser (CORS / referer checks), so the page asks
this server and the server asks them:

    GET /lyrics/src?source=netease|qq|kugou&artist=..&track=..&duration=<seconds, optional>

Answers {"ok": true, "source": .., "lrc": "[00:12.30]line...", "title": .., "artist": .., "duration": secs}
or {"ok": false, "error": ".."}. Only time-stamped (LRC) lyrics are returned; a result whose length does
not match the playing song (when the length is known) is dropped, because those would show out of time.
If anything goes wrong the page just uses its other sources, so the rest of Vizah is never affected.
"""
import base64
import html
import json
import re
import threading
import time
import urllib.parse
import urllib.request
from urllib.parse import parse_qs

SOURCES = ("netease", "qq", "kugou")
UA = ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/124.0 Mobile Safari/537.36")
TIMEOUT = 5
CACHE_TTL = 3600
CACHE_MAX = 300
DURATION_SLACK = 6  # seconds a candidate's length may differ from the playing song

_cache = {}
_lock = threading.Lock()


# ---------------------------------------------------------------- helpers
def _norm(s):
    return re.sub(r"[\W_]+", "", str(s or "").lower(), flags=re.UNICODE)


def _clean_title(s):
    """'Song (feat. X) - Remastered 2011' -> 'Song' for matching."""
    s = str(s or "")
    s = re.sub(r"\s*[\(\[].*?[\)\]]", "", s)
    s = re.split(r"\s+-\s+", s)[0]
    return s.strip()


def _http(url, headers=None, data=None, timeout=TIMEOUT):
    req = urllib.request.Request(url, data=data, headers=dict({"User-Agent": UA}, **(headers or {})))
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def _json(url, headers=None, data=None):
    txt = _http(url, headers, data).strip()
    m = re.match(r"^[\w$.]+\((.*)\)\s*;?$", txt, re.S)  # JSONP wrapper some endpoints add
    if m:
        txt = m.group(1)
    return json.loads(txt)


def _score(want_title, want_artist, got_title, got_artist):
    """0 = no match. Higher is better. Title must match; artist must match when we know it."""
    wt, full = _norm(_clean_title(want_title)), _norm(got_title)
    gt = _norm(_clean_title(got_title))
    if not wt or not (gt == wt or (len(wt) >= 4 and wt in full) or (len(gt) >= 4 and gt in _norm(want_title))):
        return 0
    s = 2 if gt == wt else 1
    wa = _norm(want_artist)
    if wa:
        ga2 = _norm(got_artist)
        if ga2 and (wa in ga2 or ga2 in wa):
            s += 2
        elif ga2:
            return 0
    return s


def _length_ok(want_secs, got_secs):
    if not want_secs or not got_secs:
        return True
    return abs(float(want_secs) - float(got_secs)) <= DURATION_SLACK


def _has_sync(lrc):
    return len(re.findall(r"^\s*\[\d+:\d+(?:[.:]\d+)?\]", lrc or "", re.M)) >= 4


# ---------------------------------------------------------------- NetEase Cloud Music
def _netease(artist, track, secs):
    hdr = {"Referer": "https://music.163.com/", "Cookie": "appver=2.0.2; os=pc"}
    q = ("%s %s" % (artist, _clean_title(track))).strip()
    body = urllib.parse.urlencode({"s": q, "type": 1, "limit": 10, "offset": 0}).encode()
    res = _json("https://music.163.com/api/search/get/web?csrf_token=", dict(hdr, **{
        "Content-Type": "application/x-www-form-urlencoded"}), body)
    songs = ((res or {}).get("result") or {}).get("songs") or []
    best = None
    for s in songs:
        names = " ".join(a.get("name", "") for a in (s.get("artists") or s.get("ar") or []))
        sc = _score(track, artist, s.get("name"), names)
        dur = (s.get("duration") or s.get("dt") or 0) / 1000.0
        if sc and _length_ok(secs, dur):
            key = (sc, -abs((secs or dur) - dur))
            if best is None or key > best[0]:
                best = (key, s, names, dur)
    if not best:
        return None
    _, s, names, dur = best
    ly = _json("https://music.163.com/api/song/lyric?id=%s&lv=1&kv=1&tv=-1" % s.get("id"), hdr)
    lrc = ((ly or {}).get("lrc") or {}).get("lyric") or ""
    if not _has_sync(lrc):
        return None
    return {"lrc": lrc, "title": s.get("name"), "artist": names, "duration": dur}


# ---------------------------------------------------------------- QQ Music
def _qq(artist, track, secs):
    hdr = {"Referer": "https://y.qq.com/"}
    q = ("%s %s" % (artist, _clean_title(track))).strip()
    res = _json("https://c.y.qq.com/soso/fcgi-bin/client_search_cp?format=json&n=10&p=1&cr=1&g_tk=5381&t=0&w="
                + urllib.parse.quote(q), hdr)
    lst = (((res or {}).get("data") or {}).get("song") or {}).get("list") or []
    best = None
    for s in lst:
        names = " ".join(a.get("name", "") for a in (s.get("singer") or []))
        sc = _score(track, artist, s.get("songname") or s.get("name"), names)
        dur = float(s.get("interval") or 0)
        if sc and s.get("songmid") and _length_ok(secs, dur):
            key = (sc, -abs((secs or dur) - dur))
            if best is None or key > best[0]:
                best = (key, s, names, dur)
    if not best:
        return None
    _, s, names, dur = best
    ly = _json("https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg?format=json&nobase64=1&g_tk=5381&songmid="
               + urllib.parse.quote(s["songmid"]), {"Referer": "https://y.qq.com/portal/player.html"})
    lrc = html.unescape((ly or {}).get("lyric") or "")
    if not lrc and (ly or {}).get("lyric_b64"):
        lrc = html.unescape(base64.b64decode(ly["lyric_b64"]).decode("utf-8", "replace"))
    if not _has_sync(lrc):
        return None
    return {"lrc": lrc, "title": s.get("songname") or s.get("name"), "artist": names, "duration": dur}


# ---------------------------------------------------------------- KuGou
def _kugou(artist, track, secs):
    q = ("%s - %s" % (artist, _clean_title(track))).strip()
    url = ("https://lyrics.kugou.com/search?ver=1&man=yes&client=pc&hash=&keyword=%s&duration=%d"
           % (urllib.parse.quote(q), int((secs or 0) * 1000)))
    res = _json(url)
    cands = (res or {}).get("candidates") or []
    best = None
    for c in cands:
        sc = _score(track, artist, c.get("song"), c.get("singer"))
        dur = (c.get("duration") or 0) / 1000.0
        if sc and _length_ok(secs, dur):
            key = (sc, -abs((secs or dur) - dur))
            if best is None or key > best[0]:
                best = (key, c, dur)
    if not best:
        return None
    _, c, dur = best
    dl = _json("https://lyrics.kugou.com/download?ver=1&client=pc&fmt=lrc&charset=utf8&id=%s&accesskey=%s"
               % (urllib.parse.quote(str(c.get("id"))), urllib.parse.quote(str(c.get("accesskey")))))
    raw = (dl or {}).get("content") or ""
    lrc = base64.b64decode(raw).decode("utf-8", "replace") if raw else ""
    lrc = lrc.lstrip("\ufeff")
    if not _has_sync(lrc):
        return None
    return {"lrc": lrc, "title": c.get("song"), "artist": c.get("singer"), "duration": dur}


_FUNCS = {"netease": _netease, "qq": _qq, "kugou": _kugou}


# ---------------------------------------------------------------- cache + entry point
def find(source, artist, track, secs):
    if source not in _FUNCS:
        return {"ok": False, "error": "unknown source"}
    key = (source, _norm(artist), _norm(track), int(secs or 0) // 4)
    now = time.time()
    with _lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < CACHE_TTL:
            return hit[1]
    try:
        out = _FUNCS[source](artist, track, secs)
        res = dict(out, ok=True, source=source) if out else {"ok": False, "source": source, "error": "not found"}
    except Exception as e:  # network down, site changed its format, ...
        return {"ok": False, "source": source, "error": "%s: %s" % (type(e).__name__, e)}
    with _lock:
        _cache[key] = (now, res)
        if len(_cache) > CACHE_MAX:
            for k in sorted(_cache, key=lambda k: _cache[k][0])[:50]:
                _cache.pop(k, None)
    return res


def handle_get(h, parsed, srv):
    """Returns True when the request was handled here."""
    if parsed.path != "/lyrics/src":
        return False
    if not srv.session_lookup(h._token()):
        h._send_json(401, {"ok": False, "error": "log in to Vizah first", "code": "login", "auth": False})
        return True
    qs = parse_qs(parsed.query or "")
    one = lambda k: (qs.get(k, [""])[0] or "").strip()[:200]
    try:
        secs = max(0.0, min(3600.0, float(one("duration") or 0)))
    except ValueError:
        secs = 0.0
    artist, track = one("artist"), one("track")
    if not track:
        h._send_json(400, {"ok": False, "error": "track is required"})
        return True
    h._send_json(200, find(one("source").lower(), artist, track, secs))
    return True
