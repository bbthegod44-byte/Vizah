#!/usr/bin/env bash
# One-time setup for Vizah as an installable app in Termux. Safe to run again.
#   bash setup_pwa.sh
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="${VIZAH_DIR:-$HOME/vizah}"

say() { printf '\n\033[1m==> %s\033[0m\n' "$*"; }

# 1. packages -------------------------------------------------------------
if command -v pkg >/dev/null 2>&1; then
  say "Installing packages (python, android-tools, termux-api)"
  pkg update -y || true
  pkg install -y python android-tools termux-api || true
else
  echo "(not Termux - skipping pkg installs; make sure python3 is installed)"
fi
command -v python3 >/dev/null 2>&1 || { echo "python3 is required." >&2; exit 1; }

say "Installing ytmusicapi (YouTube Music playlists; optional)"
pip install --upgrade ytmusicapi || pip install --upgrade --break-system-packages ytmusicapi || echo "ytmusicapi install failed - YouTube Music playlists will be unavailable, everything else works."

# 2. put the app in Termux's home (shared storage can't hold private files / run reliably) ----
if [ "$SRC" != "$DEST" ]; then
  say "Copying Vizah to $DEST (your existing config.json / creds.txt are kept)"
  mkdir -p "$DEST"
  # never overwrite saved logins, accounts or messages that already live in DEST
  ( cd "$SRC" && tar cf - --exclude=./config.json --exclude=./creds.txt --exclude=./server.log \
      --exclude=./.server.pid --exclude=./games/fnf/* . ) | ( cd "$DEST" && tar xf - )
  # first install only: carry over config/creds if DEST has none
  for f in config.json creds.txt; do
    [ -f "$SRC/$f" ] && [ ! -f "$DEST/$f" ] && cp "$SRC/$f" "$DEST/$f"
  done
  [ -f "$DEST/creds.txt" ] && chmod 600 "$DEST/creds.txt" 2>/dev/null || true
fi
chmod +x "$DEST"/*.sh 2>/dev/null || true

# 3. optional launchers ---------------------------------------------------
say "Adding Termux:Widget shortcut and Termux:Boot autostart (only used if those apps are installed)"
mkdir -p "$HOME/.shortcuts" "$HOME/.termux/boot"
cat > "$HOME/.shortcuts/Vizah" <<SH
#!/usr/bin/env bash
bash "$DEST/launch.sh"
SH
cat > "$HOME/.termux/boot/vizah" <<SH
#!/usr/bin/env bash
termux-wake-lock
bash "$DEST/launch.sh" --no-open
SH
chmod +x "$HOME/.shortcuts/Vizah" "$HOME/.termux/boot/vizah"

# 4. run it + open it ------------------------------------------------------
say "Starting the server and opening Vizah"
bash "$DEST/launch.sh"

cat <<MSG

Done. Vizah is running at http://127.0.0.1:${PORT:-8000}/

Make it an app (one time):
  In Chrome, tap  ⋮  ->  "Install app"  (or tap the "Install" bar Vizah shows).
  Then open it from your home screen like any other app.

Next time:
  - The server has to be running. Start it with:   bash $DEST/launch.sh
  - Or tap the "Vizah" shortcut (Termux:Widget), or install Termux:Boot to start it on boot.
  - Stop it with:                                   bash $DEST/stop.sh
MSG
