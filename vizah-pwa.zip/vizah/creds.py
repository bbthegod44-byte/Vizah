"""creds.txt - the one private file for Vizah's secrets.

One `name=value` line per secret (lines starting with # are comments):

    yt_api_key=...            YouTube Data API key (YouTube section)
    ytm_cookie=...            YouTube Music login cookie (playlists)
    ytm_authuser=0            which Google account index the cookie belongs to
    ytm_user_agent=...        browser the cookie came from (optional)
    ytm_language=...          Accept-Language it was copied with (optional)
    pw.<username>=pbkdf2...   Vizah account passwords (salted PBKDF2 hashes, never plain text)

The server never serves this file (see Handler.translate_path in server.py) and keeps it
mode 600. Standard library only, so server.py and ytm_setup.py can both import it.
"""
import hashlib
import json
import os
import re
import tempfile
import threading
import time

CREDS_FILE = os.environ.get("VIZAH_CREDS") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "creds.txt")
DEFAULT_UA = "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0"
HEADER = ("# Vizah credentials - PRIVATE. Never share, upload or commit this file.\n"
          "# One name=value per line. Passwords are stored as salted hashes, not plain text.\n")

_lock = threading.RLock()
_KEY_RE = re.compile(r"^[A-Za-z0-9_.\-]{1,80}$")
_KNOWN = {"yt_api_key", "ytm_cookie", "ytm_authuser", "ytm_user_agent", "ytm_language",
          "spotify_client_id", "spotify_client_secret", "spotify_refresh_token",
          "spotify_user", "spotify_display_name", "spotify_photo", "spotify_redirect_uri",
          "playback_provider"}
# These belong to a Vizah account: stored as <name>.<account> (e.g. ytm_cookie.alice) so logging
# in as someone else never sees another account's YouTube or Spotify login. Without a current
# account (the command-line setup script) the plain names are used.
USER_KEYS = ("yt_api_key", "ytm_cookie", "ytm_authuser", "ytm_user_agent", "ytm_language",
             "spotify_client_id", "spotify_client_secret", "spotify_refresh_token",
             "spotify_user", "spotify_display_name", "spotify_photo", "spotify_redirect_uri",
             "playback_provider")
_tl = threading.local()


def set_user(name):
    """Which account the calling thread is working for (None = no account)."""
    _tl.user = (name or "").lower() or None


def get_user():
    return getattr(_tl, "user", None)


def _k(key, user=None):
    user = user if user is not None else get_user()
    return ("%s.%s" % (key, user)) if (user and key in USER_KEYS) else key


def _known(key):
    if key in _KNOWN or (key.startswith("pw.") and len(key) > 3):
        return True
    base, sep, who = key.partition(".")      # per-account copy, e.g. ytm_cookie.alice
    return bool(sep and who and base in USER_KEYS)


def _looks_like_cookie(line):
    t = line.strip()
    if t.lower().startswith("cookie:"):
        t = t.split(":", 1)[1].strip()
    return "=" in t and (";" in t or len(t) > 80), t


def _read():
    """Returns (entries, extra_lines). A bare cookie string (how this file started out) is
    adopted as ytm_cookie; anything else unrecognised is kept so nothing is ever lost."""
    try:
        with open(CREDS_FILE, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except FileNotFoundError:
        return {}, []
    entries, extra = {}, []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        k, sep, v = line.partition("=")
        k = k.strip()
        if sep and _KEY_RE.match(k) and _known(k):
            entries[k] = v.strip()
        else:
            extra.append(line)
    kept = []
    for line in extra:
        ok, cookie = _looks_like_cookie(line)
        if ok and "ytm_cookie" not in entries:
            entries["ytm_cookie"] = cookie
        else:
            kept.append(line)
    return entries, kept


def _write(entries, extra):
    lines = [HEADER]
    for k in sorted(entries):
        lines.append("%s=%s\n" % (k, entries[k]))
    if extra:
        lines.append("\n# unrecognised lines from the old file (kept, not used):\n")
        for e in extra:
            lines.append("# " + e + "\n")
    tmp = CREDS_FILE + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write("".join(lines))
    try:
        os.chmod(tmp, 0o600)
    except Exception:
        pass
    os.replace(tmp, CREDS_FILE)


def _clean(value):
    value = str(value).replace("\r", " ").replace("\n", " ").strip()
    return value


def get(key, default=""):
    with _lock:
        return _read()[0].get(_k(key), default)


def set(key, value):  # noqa: A001 - mirrors dict-style naming
    """Stores one value (an empty value removes it). Raises on a bad key or a write error."""
    if not _KEY_RE.match(key or "") or not _known(key):
        raise ValueError("unknown credential name")
    key = _k(key)
    if not _KEY_RE.match(key):
        raise ValueError("unknown credential name")
    value = _clean(value)
    with _lock:
        entries, extra = _read()
        if value:
            entries[key] = value
        else:
            entries.pop(key, None)
        _write(entries, extra)


def delete(key):
    set(key, "")


def has(key):
    return bool(get(key))


def migrate(legacy_ytm_json=None):
    """Run once at start-up: rewrite the file in the labelled format and pull in an older
    ~/.ytmusic_browser.json login if creds.txt has no YouTube Music cookie yet."""
    with _lock:
        entries, extra = _read()
        if "ytm_cookie" not in entries and legacy_ytm_json and os.path.exists(legacy_ytm_json):
            try:
                with open(legacy_ytm_json, "r", encoding="utf-8") as f:
                    old = json.load(f)
                cookie = _clean(old.get("Cookie") or old.get("cookie") or "")
                if cookie:
                    entries["ytm_cookie"] = cookie
                    entries["ytm_authuser"] = _clean(old.get("X-Goog-AuthUser") or "0")
                    if old.get("User-Agent"):
                        entries["ytm_user_agent"] = _clean(old["User-Agent"])
            except Exception:
                pass
        if os.path.exists(CREDS_FILE) or entries:
            _write(entries, extra)


def migrate_legacy(owner):
    """Moves the old shared YouTube logins (plain names) onto one account, so they stop being
    visible to everyone. Existing per-account values are never overwritten."""
    owner = (owner or "").lower()
    if not owner:
        return False
    moved = False
    with _lock:
        entries, extra = _read()
        for k in USER_KEYS:
            if k in entries:
                nk = "%s.%s" % (k, owner)
                if nk not in entries:
                    entries[nk] = entries[k]
                del entries[k]
                moved = True
        if moved:
            _write(entries, extra)
    return moved


def rename_user(old, new):
    """Keeps an account's YouTube login when the account is renamed."""
    old, new = (old or "").lower(), (new or "").lower()
    if not old or not new or old == new:
        return
    with _lock:
        entries, extra = _read()
        changed = False
        for k in USER_KEYS:
            ok_, nk = "%s.%s" % (k, old), "%s.%s" % (k, new)
            if ok_ in entries:
                entries[nk] = entries.pop(ok_)
                changed = True
        if changed:
            _write(entries, extra)


# ---------- YouTube Music login, built from the stored cookie ----------

def make_authorization(cookie, origin="https://music.youtube.com"):
    for name in ("__Secure-3PAPISID", "SAPISID", "__Secure-1PAPISID"):
        m = re.search(r"(?:^|;\s*)" + re.escape(name) + r"=([^;]+)", cookie)
        if m:
            ts = int(time.time())
            digest = hashlib.sha1(("%d %s %s" % (ts, m.group(1), origin)).encode()).hexdigest()
            return "SAPISIDHASH %d_%s" % (ts, digest)
    return ""


def ytm_headers():
    """The request headers ytmusicapi needs, or None when no cookie is stored."""
    cookie = get("ytm_cookie")
    if not cookie:
        return None
    origin = "https://music.youtube.com"
    h = {
        "User-Agent": get("ytm_user_agent") or DEFAULT_UA,
        "Accept": "*/*",
        "Accept-Language": get("ytm_language") or "en-US,en;q=0.5",
        "Content-Type": "application/json",
        "x-origin": origin,
        "origin": origin,
        "Cookie": cookie,
        "X-Goog-AuthUser": get("ytm_authuser") or "0",
    }
    auth = make_authorization(cookie, origin)
    if auth:
        h["Authorization"] = auth
    return h


IN_USE_MSG = ("That YouTube login is already connected to another Vizah account. "
              "Disconnect it there first, then connect it here.")


def cookie_fingerprint(cookie):
    """Stable, non-reversible id of a YouTube login (hash of its SAPISID value), or ''."""
    for name in ("__Secure-3PAPISID", "SAPISID", "__Secure-1PAPISID"):
        m = re.search(r"(?:^|;\s*)" + re.escape(name) + r"=([^;]+)", cookie or "")
        if m:
            return hashlib.sha256(m.group(1).encode()).hexdigest()
    return ""


def cookie_owner(cookie, exclude_user=None):
    """Name of ANOTHER Vizah account that already has this YouTube login saved, else None."""
    fp = cookie_fingerprint(cookie)
    if not fp:
        return None
    me = (exclude_user or "").lower()
    with _lock:
        entries, _extra = _read()
    for k, v in entries.items():
        base, sep, who = k.partition(".")
        if base == "ytm_cookie" and sep and who and who.lower() != me and cookie_fingerprint(v) == fp:
            return who
    return None


def save_ytm(cookie, authuser="0", user_agent="", language=""):
    if cookie_owner(cookie, get_user()):          # one YouTube login per Vizah account
        raise ValueError(IN_USE_MSG)
    set("ytm_cookie", cookie)
    set("ytm_authuser", str(authuser))
    set("ytm_user_agent", user_agent if user_agent and user_agent != DEFAULT_UA else "")
    set("ytm_language", language if language and language != "en-US,en;q=0.5" else "")


def open_ytmusic(YTMusic, headers):
    """YTMusic only takes a file path in every version, so the headers go into a private temp
    file that exists just long enough for the client to read them."""
    fd, path = tempfile.mkstemp(prefix="vizah_", suffix=".json")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(headers, f)
        return YTMusic(path)
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
