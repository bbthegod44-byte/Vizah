const api = globalThis.browser || globalThis.chrome;
const $ = (id) => document.getElementById(id);

function say(t) { $("s").textContent = t; }

async function run() {
  $("retry").hidden = true;
  say("Reading your login...");
  let list = [];
  try {
    list = await api.cookies.getAll({ domain: "youtube.com" });
  } catch (e) {
    say("Couldn't read cookies: " + (e && e.message ? e.message : e));
    $("retry").hidden = false;
    return;
  }
  // broad domains first so a music.youtube.com cookie with the same name wins
  list.sort((a, b) => a.domain.length - b.domain.length);
  const byName = {};
  for (const c of list) byName[c.name] = c.value;
  const names = Object.keys(byName);
  if (!names.some((n) => /^(__Secure-3PAPISID|SAPISID)$/.test(n))) {
    say("You're not signed in to YouTube in this browser. Open music.youtube.com, sign in, then click this again.");
    $("retry").hidden = false;
    return;
  }
  const cookie = names.map((n) => n + "=" + byName[n]).join("; ");
  const text = "cookie: " + cookie + "\nuser-agent: " + navigator.userAgent +
               "\naccept-language: " + (navigator.language || "en-US") + ",en;q=0.5";
  const b64 = btoa(unescape(encodeURIComponent(text))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  say("Sending to Vizah...");
  await api.tabs.create({ url: VIZAH.replace(/\/+$/, "") + "/#ytm=" + b64 });
  window.close();
}

$("retry").addEventListener("click", run);
run();
