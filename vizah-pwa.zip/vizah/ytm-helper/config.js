// Replaced by the Vizah server with its own address when you download the helper.
var VIZAH = "http://localhost:8000";
