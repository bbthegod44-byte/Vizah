#!/usr/bin/env bash
set -e

cd "$(dirname "$0")"
PORT="${PORT:-8000}"

echo "Running on http://0.0.0.0:$PORT"
python3 server.py
