"""Direct messages + public profiles for Vizah.

Self-contained on purpose: server.py only calls handle_get / handle_post (and on_rename),
and everything here is stored in its own file, so accounts, config and Last.fm data are
never touched.

Everything here is friends-only: you can message and view the profile of accounts that are
on your friends list (the friend system in server.py), plus your own profile.

Routes (all need a logged-in session):
  GET  /social/users?q=         your friends (name only; avatars are fetched separately)
  GET  /social/profile?u=NAME   profile of a friend (or yourself)
  GET  /social/avatar/NAME      a friend's avatar image (cached by the browser)
  GET  /social/artist-image?name=  a photo of an artist (Last.fm only returns grey placeholders for artists), looked up server-side
  GET  /social/listening[?u=NAME]  what your friends are listening to (from their Last.fm, cached ~30s)
  GET  /social/inbox            conversations, newest first, with unread counts
  GET  /social/messages?with=NAME&after=ID
  POST /social/send             {"to": NAME, "text": "..."}
  POST /social/read             {"with": NAME}
  POST /social/vizah            {"to": NAME}                 ask a friend to send you the song they are listening to
  POST /social/vizah/answer     {"with": NAME, "id": ID, "action": "send"|"decline"}
  POST /social/vizah/claim      {"id": ID}                   the asker's page claims a sent Vizah so it plays once
  POST /social/art              {"track": "...", "artist": "...", "art": URL}   the cover your player shows, used for your listening box when Last.fm has none
  POST /social/vizah/share      {"to": NAME, "id": VIDEO_ID, "track": "...", "artist": "...", "art": URL}
                                send a friend a song picked in the YouTube Music search bar (they tap Play)

Never exposed to other users: API keys, Last.fm API key, password data, YouTube data.
"""
import base64
import json
import os
import re
import threading
import time
from urllib.parse import parse_qs, quote, urlencode, urlparse
from urllib.request import Request, urlopen

MSG_FILE = os.environ.get("VIZAH_MESSAGES") or os.path.expanduser("~/.vizah_messages.json")
MSG_MAX = 2000          # characters per message
KEEP_PER_THREAD = 2000  # oldest messages beyond this are dropped
SEND_LIMIT = 30         # messages per minute per sender
_DATA_URL = re.compile(r"^data:(image/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$")

_lock = threading.RLock()
_db = None
_sent = {}  # sender -> [timestamps]


# ---------------------------------------------------------------- storage
def _load():
    global _db
    if _db is None:
        db = {}
        try:
            with open(MSG_FILE, "r", encoding="utf-8") as f:
                db = json.load(f)
        except Exception:
            db = {}
        if not isinstance(db, dict):
            db = {}
        db.setdefault("threads", {})  # "a|b" (sorted, lowercase) -> [message, ...]
        db.setdefault("read", {})     # "me|other" -> last message id I have read in that thread
        db.setdefault("seq", 0)
        _db = db
    return _db


def _save():
    tmp = MSG_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(_db, f)
    try:
        os.chmod(tmp, 0o600)
    except Exception:
        pass
    os.replace(tmp, MSG_FILE)


def _tkey(a, b):
    a, b = a.lower(), b.lower()
    return "|".join(sorted((a, b)))


def on_rename(old_key, new_key):
    """Keeps conversations attached to an account when its username changes."""
    if old_key == new_key:
        return
    with _lock:
        db = _load()
        threads = {}
        for k, msgs in db["threads"].items():
            a, b = k.split("|", 1)
            a2 = new_key if a == old_key else a
            b2 = new_key if b == old_key else b
            for m in msgs:
                if m.get("from") == old_key:
                    m["from"] = new_key
            threads.setdefault(_tkey(a2, b2), []).extend(msgs)
        for k in threads:
            threads[k].sort(key=lambda m: m["id"])
        db["threads"] = threads
        reads = {}
        for k, v in db["read"].items():
            a, b = k.split("|", 1)
            reads["%s|%s" % (new_key if a == old_key else a, new_key if b == old_key else b)] = v
        db["read"] = reads
        _save()


def on_delete(key):
    """Removes every conversation the deleted account was part of."""
    with _lock:
        db = _load()
        db["threads"] = {k: v for k, v in db["threads"].items() if key not in k.split("|", 1)}
        db["read"] = {k: v for k, v in db["read"].items() if key not in k.split("|", 1)}
        _save()


# ---------------------------------------------------------------- helpers
def _users(srv):
    with srv._auth_lock:
        return dict(srv._auth_load()["users"])


def _public_name(u):
    return u.get("name", "")


def _find(srv, name):
    return _users(srv).get((name or "").strip().lower())


def _friend_keys(srv, me_key):
    with srv._auth_lock:
        me = srv._auth_load()["users"].get(me_key) or {}
        f = me.get("friends")
        return set(f) if isinstance(f, list) else set()


def _find_friend(srv, me_key, name, allow_self=False):
    """The account called NAME, but only if it is a friend of ME (or ME, when allowed)."""
    key = (name or "").strip().lower()
    if allow_self and key == me_key:
        return _find(srv, key)
    if key not in _friend_keys(srv, me_key):
        return None
    return _find(srv, key)


PRESENCE_TTL = 90   # a tab counts as open for this long after its last ping (pages ping every 20s)
_presence = {}      # account key -> {tab id: last ping time}


def _ping(key, tab):
    now = time.time()
    with _lock:
        tabs = _presence.setdefault(key, {})
        for t in [t for t, ts in tabs.items() if now - ts > PRESENCE_TTL]:
            del tabs[t]
        if tab in tabs or len(tabs) < 20:
            tabs[tab] = now


def _bye(key, tab):
    with _lock:
        tabs = _presence.get(key)
        if tabs:
            tabs.pop(tab, None)
            if not tabs:
                _presence.pop(key, None)


def _online(srv, key):
    """Online = at least one open Vizah tab pinged recently, and the account still has a valid
    session. Closing the last tab sends a 'bye' so it flips to offline right away."""
    now = time.time()
    with _lock:
        if not any(now - ts <= PRESENCE_TTL for ts in _presence.get(key, {}).values()):
            return False
    with srv._auth_lock:
        return any(s.get("user") == key and s.get("exp", 0) > now
                   for s in srv._auth_load()["sessions"].values())


# ---------------------------------------------------------------- extra connections (social links)
# Stored per account as [{"k": site, "v": handle}]. Only the handle is saved; the link is always built
# HERE from a fixed template, so a profile can never point at javascript: or some other odd scheme.
_HANDLE_RE = re.compile(r"^[A-Za-z0-9._-]{1,50}$")
SOCIAL_SITES = {
    "instagram":  ("Instagram",  "https://www.instagram.com/{}"),
    "tiktok":     ("TikTok",     "https://www.tiktok.com/@{}"),
    "x":          ("X",          "https://x.com/{}"),
    "youtube":    ("YouTube",    "https://www.youtube.com/@{}"),
    "twitch":     ("Twitch",     "https://www.twitch.tv/{}"),
    "soundcloud": ("SoundCloud", "https://soundcloud.com/{}"),
    "bandcamp":   ("Bandcamp",   "https://{}.bandcamp.com"),
    "spotify":    ("Spotify",    "https://open.spotify.com/user/{}"),
    "github":     ("GitHub",     "https://github.com/{}"),
    "reddit":     ("Reddit",     "https://www.reddit.com/user/{}"),
    "bluesky":    ("Bluesky",    "https://bsky.app/profile/{}"),
    "threads":    ("Threads",    "https://www.threads.net/@{}"),
    "snapchat":   ("Snapchat",   "https://www.snapchat.com/add/{}"),
    "steam":      ("Steam",      "https://steamcommunity.com/id/{}"),
    "letterboxd": ("Letterboxd", "https://letterboxd.com/{}"),
    "facebook":   ("Facebook",   "https://www.facebook.com/{}"),
    "website":    ("Website",    None),   # a full https:// address
}


SOCIAL_MAX = len(SOCIAL_SITES)   # one connection per platform


def _clean_handle(site, raw):
    """Accepts '@name', 'name' or a pasted profile link; returns a safe handle / address, or ''."""
    if not isinstance(raw, str):
        return ""
    v = re.sub(r"[\x00-\x20\x7f]", "", raw)[:200]
    if not v:
        return ""
    if site == "website":
        if not re.match(r"^https?://", v, re.I):
            v = "https://" + v
        u = urlparse(v)
        if u.scheme.lower() not in ("http", "https") or not u.hostname or "." not in u.hostname:
            return ""
        return v[:200]
    if re.match(r"^(https?://)?[^/]+\.[^/]+/", v, re.I) or v.lower().startswith(("http://", "https://")):
        # pasted profile link: keep the last meaningful path piece (bandcamp keeps its subdomain)
        u = urlparse(v if "://" in v else "https://" + v)
        if site == "bandcamp" and u.hostname and u.hostname.lower().endswith(".bandcamp.com"):
            v = u.hostname.split(".")[0]
        else:
            parts = [x for x in u.path.split("/") if x]
            v = parts[-1] if parts else ""
    v = v.lstrip("@")
    return v if _HANDLE_RE.match(v) else ""


def clean_socials(raw):
    """Validate what the browser sends: known sites only, safe handles, one per platform."""
    out, seen = [], set()
    if not isinstance(raw, list):
        return out
    for it in raw:
        if not isinstance(it, dict):
            continue
        k = it.get("k")
        if not isinstance(k, str) or k not in SOCIAL_SITES:
            continue
        v = _clean_handle(k, it.get("v"))
        if not v or k in seen:
            continue
        seen.add(k)
        out.append({"k": k, "v": v})
        if len(out) >= SOCIAL_MAX:
            break
    return out


def _social_links(cfg):
    """What other people see: label, display name and a ready-made link for each saved connection."""
    links = []
    for it in clean_socials(cfg.get("socials")):
        label, tpl = SOCIAL_SITES[it["k"]]
        if it["k"] == "website":
            u = urlparse(it["v"])
            links.append({"k": "website", "label": label, "name": (u.hostname or "").replace("www.", ""), "url": it["v"]})
        else:
            links.append({"k": it["k"], "label": label, "name": it["v"], "url": tpl.format(quote(it["v"], safe="@._-"))})
    return links


def _profile(srv, u):
    cfg = u.get("config") or {}
    return {
        "name": u.get("name", ""),
        "joined": u.get("created", 0),
        "hasAvatar": bool(cfg.get("avatar")),
        "avatarCrop": cfg.get("avatarCrop", "") or "",
        "lastfm": cfg.get("user", "") or "",
        "bio": cfg.get("bio", "") if isinstance(cfg.get("bio"), str) else "",
        "socials": _social_links(cfg),
        "colors": [cfg.get("acc1", ""), cfg.get("acc2", ""), cfg.get("acc3", "")],
        "bg": [cfg.get("bg1", ""), cfg.get("bg2", ""), cfg.get("bg3", "")],
    }


def _unread(db, me, other):
    msgs = db["threads"].get(_tkey(me, other), [])
    last = db["read"].get("%s|%s" % (me, other), 0)
    return sum(1 for m in msgs if m["id"] > last and m["from"] != me)


# ---------------------------------------------------------------- listening status
_LISTEN_TTL = 30
_listen_cache = {}  # account key -> (fetched_at, status)


_LASTFM_NO_ART = "2a96cbd8b46e442fc41c2b86b821562f"   # Last.fm's grey "no cover" placeholder
_ART_HOSTS = ("last.fm", "fastly.net", "akamaized.net", "lastfm.net")
_ART_SIZES = {"small": 1, "medium": 2, "large": 3, "extralarge": 4, "mega": 5}


def _clean_art(url):
    """Only https cover art from Last.fm's image hosts is passed on to browsers."""
    if not isinstance(url, str):
        return ""
    url = url.strip()
    if not url or len(url) > 300 or _LASTFM_NO_ART in url or re.search(r"[\s\"'<>]", url):
        return ""
    try:
        u = urlparse(url)
    except Exception:
        return ""
    host = (u.hostname or "").lower()
    if u.scheme != "https" or not any(host == d or host.endswith("." + d) for d in _ART_HOSTS):
        return ""
    return url


def _pick_art(images):
    """Largest usable cover from a Last.fm 'image' list ([{'#text': url, 'size': 'large'}, ...])."""
    best, rank = "", 0
    for im in images if isinstance(images, list) else []:
        if not isinstance(im, dict):
            continue
        url = _clean_art(im.get("#text", ""))
        r = _ART_SIZES.get(im.get("size", ""), 0)
        if url and r >= rank:
            best, rank = url, r
    return best


def _lastfm_get(params, key):
    url = "https://ws.audioscrobbler.com/2.0/?" + urlencode(dict(params, api_key=key, format="json"))
    with urlopen(Request(url, headers={"User-Agent": "Vizah/1.0"}), timeout=4) as r:
        return json.loads(r.read(200000).decode("utf-8", "replace"))


def _fetch_listening(cfg):
    """Newest Last.fm scrobble for an account, with its cover art. The API key stays on the server."""
    user = (cfg.get("user") or "").strip()
    key = (cfg.get("apiKey") or "").strip()
    if not user or not key:
        return {"state": "none"}
    try:
        data = _lastfm_get({"method": "user.getrecenttracks", "user": user, "limit": 1}, key)
        tracks = (data.get("recenttracks") or {}).get("track") or []
        if isinstance(tracks, dict):
            tracks = [tracks]
        if not tracks:
            return {"state": "none"}
        t = tracks[0]
        playing = ((t.get("@attr") or {}).get("nowplaying") == "true")
        out = {
            "state": "playing" if playing else "recent",
            "track": str(t.get("name", ""))[:150],
            "artist": str((t.get("artist") or {}).get("#text", ""))[:150],
            "art": _pick_art(t.get("image")),
        }
        if not out["art"] and out["track"] and out["artist"]:
            # many scrobbles carry no cover: ask Last.fm for the track's album art instead
            try:
                info = _lastfm_get({"method": "track.getInfo", "track": out["track"], "artist": out["artist"]}, key)
                out["art"] = _pick_art(((info.get("track") or {}).get("album") or {}).get("image"))
            except Exception:
                pass
        if not playing:
            try:
                out["ts"] = int((t.get("date") or {}).get("uts", 0))
            except (TypeError, ValueError):
                out["ts"] = 0
        return out
    except Exception:
        return {"state": "unknown"}


_own_art = {}  # account key -> (track, artist, art url, time): the cover the owner's own player is showing
_OWN_ART_TTL = 6 * 3600


def _art_report(h, srv, me_key, me, data):
    """The player tells us the cover it is showing, for songs Last.fm has no artwork for."""
    track = str(data.get("track", "")).strip()[:150]
    artist = str(data.get("artist", "")).strip()[:150]
    art = _clean_share_art(data.get("art"))
    if not track or not art:
        h._send_json(200, {"ok": True, "kept": False})
        return
    with _lock:
        if len(_own_art) > 2000:
            _own_art.clear()
        _own_art[me_key] = (track.lower(), artist.lower(), art, time.time())
        _listen_cache.pop(me_key, None)   # next look-up picks the new cover up straight away
    h._send_json(200, {"ok": True, "kept": True})


def _with_own_art(key, st):
    """Fill in a missing cover from the owner's player, but only for the very same song."""
    if not isinstance(st, dict) or st.get("art") or not st.get("track"):
        return st
    with _lock:
        hit = _own_art.get(key)
    if not hit or time.time() - hit[3] > _OWN_ART_TTL:
        return st
    t, a = (st.get("track") or "").strip().lower(), (st.get("artist") or "").strip().lower()
    if hit[0] != t or (hit[1] and a and hit[1] != a and hit[1] not in a and a not in hit[1]):
        return st
    out = dict(st)
    out["art"] = hit[2]
    return out


_artist_img = {}   # normalised artist name -> (time, url or "")
_ARTIST_IMG_TTL = 7 * 86400
_ARTIST_IMG_MISS_TTL = 3600
_ARTIST_IMG_HOSTS = ("dzcdn.net", "deezer.com")


def _norm_name(s):
    return re.sub(r"[^a-z0-9]+", "", str(s).lower())


def _artist_image(name):
    """A picture of the artist from Deezer's public search (no key needed). Exact name matches only,
    so a similarly named act never gets the wrong face. Cached, and failures are cached for a while too."""
    name = str(name or "").strip()[:100]
    key = _norm_name(name)
    if not key:
        return ""
    now = time.time()
    with _lock:
        hit = _artist_img.get(key)
    if hit and now - hit[0] < (_ARTIST_IMG_TTL if hit[1] else _ARTIST_IMG_MISS_TTL):
        return hit[1]
    url, ok = "", False
    try:
        req = Request("https://api.deezer.com/search/artist?" + urlencode({"q": name, "limit": 8}),
                      headers={"User-Agent": "Vizah/1.0"})
        with urlopen(req, timeout=4) as r:
            data = json.loads(r.read(300000).decode("utf-8", "replace"))
        ok = True
        for a in (data.get("data") or []):
            if not isinstance(a, dict) or _norm_name(a.get("name", "")) != key:
                continue
            for field in ("picture_xl", "picture_big", "picture_medium"):
                cand = a.get(field)
                if not isinstance(cand, str) or "/artist//" in cand or len(cand) > 300 or re.search(r"[\s\"'<>]", cand):
                    continue
                u = urlparse(cand)
                host = (u.hostname or "").lower()
                if u.scheme == "https" and any(host == d or host.endswith("." + d) for d in _ARTIST_IMG_HOSTS):
                    url = cand
                    break
            if url:
                break
    except Exception:
        pass
    if ok:   # a network hiccup is not cached, so the next look retries
        with _lock:
            if len(_artist_img) > 3000:
                _artist_img.clear()
            _artist_img[key] = (now, url)
    return url


def _listening_for(u, viewer_is_owner):
    cfg = u.get("config") or {}
    if cfg.get("showListening") is False and not viewer_is_owner:
        return {"state": "hidden"}
    key = (u.get("name") or "").lower()
    now = time.time()
    with _lock:
        hit = _listen_cache.get(key)
    if hit and now - hit[0] < _LISTEN_TTL:
        return _with_own_art(key, hit[1])
    st = _fetch_listening(cfg)
    with _lock:
        _listen_cache[key] = (time.time(), st)
        if len(_listen_cache) > 2000:
            _listen_cache.clear()
    return _with_own_art(key, st)


# ---------------------------------------------------------------- Vizah (ask a friend to send you their song)
_VID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
# Spotify track ids are namespaced with "sp_" by spotify.py so they can't be mistaken for YouTube ids
_SP_ID_RE = re.compile(r"^sp_[A-Za-z0-9]{1,64}$")


def _song_id_ok(vid):
    """True for a YouTube video id or a Spotify track id (shared songs can come from either service)."""
    return isinstance(vid, str) and bool(_VID_RE.match(vid) or _SP_ID_RE.match(vid))
VIZAH_FRESH = 600   # a sent Vizah only auto-plays for the asker if it is this fresh (seconds)


def _pub(m, me_key):
    """A stored message as the browser sees it."""
    out = {"id": m["id"], "text": m["text"], "ts": m["ts"], "mine": m["from"] == me_key}
    vz = m.get("vz")
    if isinstance(vz, dict):
        out["vz"] = {k: vz.get(k) for k in ("k", "track", "artist", "art", "state", "vid", "ref") if k in vz}
    return out


def _rate_ok(me_key):
    now = time.time()
    recent = [t for t in _sent.get(me_key, []) if now - t < 60]
    if len(recent) >= SEND_LIMIT:
        return False
    recent.append(now)
    _sent[me_key] = recent
    return True


def _append(db, me_key, other_key, text, vz=None):
    db["seq"] += 1
    msg = {"id": db["seq"], "from": me_key, "text": text[:MSG_MAX], "ts": int(time.time())}
    if vz:
        msg["vz"] = vz
    thread = db["threads"].setdefault(_tkey(me_key, other_key), [])
    thread.append(msg)
    if len(thread) > KEEP_PER_THREAD:
        del thread[:len(thread) - KEEP_PER_THREAD]
    db["read"]["%s|%s" % (me_key, other_key)] = msg["id"]   # my own message counts as read
    return msg


def _song_line(track, artist):
    return track + (" \u2014 " + artist if artist else "")


def _resolve_song(srv, track, artist):
    """Finds the YouTube Music video id for TRACK by ARTIST ('' if none). It is opened in the YouTube Music app over adb."""
    q = ("%s %s" % (track, artist)).strip()[:100]
    try:
        r = srv.ytm_search(q)
        for x in (r.get("results") or []) if r.get("ok") else []:
            if _VID_RE.match(x.get("id") or ""):
                return x["id"]
    except Exception:
        pass
    try:
        r = srv.yt_search(q + " official audio")
        for x in (r.get("items") or []) if r.get("ok") else []:
            if _VID_RE.match(x.get("id") or ""):
                return x["id"]
    except Exception:
        pass
    return ""


def _vizah_ask(h, srv, me_key, me, data):
    u = _find_friend(srv, me_key, str(data.get("to", "")))
    if not u or u["name"].lower() == me_key:
        h._send_json(403, {"ok": False, "error": "You can only ask your friends"})
        return
    st = _listening_for(u, False)
    if st.get("state") == "hidden":
        h._send_json(200, {"ok": False, "error": "%s keeps their listening private" % u["name"]})
        return
    if st.get("state") not in ("playing", "recent") or not st.get("track"):
        h._send_json(200, {"ok": False, "error": "%s isn't sharing a song right now" % u["name"]})
        return
    if not _rate_ok(me_key):
        h._send_json(429, {"ok": False, "error": "Slow down a little"})
        return
    other_key = u["name"].lower()
    track, artist = st["track"], st.get("artist", "")
    with _lock:
        db = _load()
        # don't pile up: one open ask per song per friend
        for m in db["threads"].get(_tkey(me_key, other_key), [])[-40:]:
            vz = m.get("vz") or {}
            if m["from"] == me_key and vz.get("k") == "ask" and vz.get("state") == "open" \
                    and vz.get("track") == track and vz.get("artist") == artist:
                h._send_json(200, {"ok": False, "error": "You already asked %s for that one" % u["name"]})
                return
        msg = _append(db, me_key, other_key, "\U0001F3B5 Vizah: " + _song_line(track, artist),
                      {"k": "ask", "track": track, "artist": artist, "art": st.get("art", ""), "state": "open"})
        _save()
    h._send_json(200, {"ok": True, "message": _pub(msg, me_key)})


def _vizah_answer(h, srv, me_key, me, data):
    u = _find_friend(srv, me_key, str(data.get("with", "")))
    action = data.get("action")
    try:
        ask_id = int(data.get("id"))
    except (TypeError, ValueError):
        ask_id = 0
    if not u or action not in ("send", "decline") or not ask_id:
        h._send_json(400, {"ok": False, "error": "bad request"})
        return
    other_key = u["name"].lower()

    def find():
        for m in _load()["threads"].get(_tkey(me_key, other_key), []):
            if m["id"] == ask_id:
                return m
        return None

    with _lock:
        ask = find()
        vz = (ask or {}).get("vz") or {}
        if not ask or vz.get("k") != "ask" or ask["from"] == me_key:
            h._send_json(404, {"ok": False, "error": "That Vizah isn't there anymore"})
            return
        if vz.get("state") != "open":
            h._send_json(200, {"ok": False, "error": "Already answered", "state": vz.get("state")})
            return
        track, artist, art = vz.get("track", ""), vz.get("artist", ""), vz.get("art", "")

    if action == "decline":
        with _lock:
            ask = find()
            if not ask or (ask.get("vz") or {}).get("state") != "open":
                h._send_json(200, {"ok": False, "error": "Already answered"})
                return
            ask["vz"]["state"] = "declined"
            msg = _append(_load(), me_key, other_key, "Passed on the Vizah for " + _song_line(track, artist),
                          {"k": "declined", "ref": ask_id, "track": track, "artist": artist})
            _save()
        h._send_json(200, {"ok": True, "state": "declined", "message": _pub(msg, me_key)})
        return

    if not _rate_ok(me_key):
        h._send_json(429, {"ok": False, "error": "Slow down a little"})
        return
    vid = _resolve_song(srv, track, artist)      # network calls: done outside the lock
    if not vid:
        h._send_json(200, {"ok": False, "error": "Couldn't find a playable copy of that song"})
        return
    with _lock:
        ask = find()
        if not ask or (ask.get("vz") or {}).get("state") != "open":
            h._send_json(200, {"ok": False, "error": "Already answered"})
            return
        ask["vz"]["state"] = "sent"
        msg = _append(_load(), me_key, other_key, "\U0001F3B5 Sent a Vizah: " + _song_line(track, artist),
                      {"k": "sent", "ref": ask_id, "track": track, "artist": artist, "art": art, "vid": vid, "claimed": False})
        _save()
    h._send_json(200, {"ok": True, "state": "sent", "message": _pub(msg, me_key)})


def _vizah_claim(h, srv, me_key, me, data):
    """The asker's page calls this once per sent Vizah, so it auto-plays in exactly one tab, one time."""
    try:
        mid = int(data.get("id"))
    except (TypeError, ValueError):
        mid = 0
    with _lock:
        for k, msgs in _load()["threads"].items():
            if me_key not in k.split("|", 1):
                continue
            for m in msgs:
                vz = m.get("vz") or {}
                if m["id"] == mid and vz.get("k") == "sent" and m["from"] != me_key:
                    if vz.get("claimed"):
                        h._send_json(200, {"ok": False, "error": "Already played"})
                        return
                    vz["claimed"] = True
                    _save()
                    sender = _users(srv).get(m["from"]) or {}
                    h._send_json(200, {"ok": True, "song": {
                        "id": vz.get("vid", ""), "track": vz.get("track", ""), "artist": vz.get("artist", ""),
                        "art": vz.get("art", ""), "from": sender.get("name", m["from"])}})
                    return
    h._send_json(404, {"ok": False, "error": "Not found"})


_SHARE_ART_HOSTS = _ART_HOSTS + ("ytimg.com", "googleusercontent.com", "ggpht.com", "scdn.co")


def _clean_share_art(url):
    """Cover art for a shared song: https only, from Last.fm or YouTube's image hosts."""
    if not isinstance(url, str):
        return ""
    url = url.strip()
    if not url or len(url) > 400 or re.search(r"[\s\"'<>]", url):
        return ""
    try:
        u = urlparse(url)
    except Exception:
        return ""
    host = (u.hostname or "").lower()
    if u.scheme != "https" or not any(host == d or host.endswith("." + d) for d in _SHARE_ART_HOSTS):
        return ""
    return url


def _resolve_share_id(srv, me_key, track, artist):
    """A playable id for the song the sender is hearing right now: a Spotify id when the sender plays
    through Spotify, otherwise the YouTube id (the friend's own app looks it up by name if needed)."""
    try:
        prev = srv.creds.get_user()
        srv.creds.set_user(me_key)
        try:
            if srv.playback_provider() == "spotify" and srv.spotify is not None:
                r = srv.spotify.search(("%s %s" % (track, artist)).strip()[:100])
                for x in (r.get("results") or []) if r.get("ok") else []:
                    if _SP_ID_RE.match(x.get("id") or ""):
                        return x["id"]
        finally:
            srv.creds.set_user(prev)
    except Exception:
        pass
    return _resolve_song(srv, track, artist)


def _vizah_share(h, srv, me_key, me, data):
    """Send a friend a song chosen in the search bar, or (current: true) the song playing right now.
    It lands as a card they tap to play."""
    u = _find_friend(srv, me_key, str(data.get("to", "")))
    if not u or u["name"].lower() == me_key:
        h._send_json(403, {"ok": False, "error": "You can only send Vizahs to your friends"})
        return
    vid = data.get("id")
    track = data.get("track")
    artist = data.get("artist", "")
    # "current": the song playing right now has no id yet - it is looked up below (after the rate limit)
    current = data.get("current") is True
    has_id = isinstance(vid, str) and _song_id_ok(vid)
    if not isinstance(track, str) or not track.strip() or (not has_id and not current):
        h._send_json(400, {"ok": False, "error": "Pick a song first"})
        return
    track = " ".join(track.split())[:120]
    artist = " ".join(artist.split())[:120] if isinstance(artist, str) else ""
    art = _clean_share_art(data.get("art", ""))
    if not _rate_ok(me_key):
        h._send_json(429, {"ok": False, "error": "Slow down a little"})
        return
    if not has_id:
        vid = _resolve_share_id(srv, me_key, track, artist)      # network calls: done outside the lock
        if not vid:
            h._send_json(200, {"ok": False, "error": "Couldn't find a playable copy of that song"})
            return
    other_key = u["name"].lower()
    now = time.time()
    with _lock:
        db = _load()
        # don't pile up: the same song to the same friend within a minute is a double tap
        for m in db["threads"].get(_tkey(me_key, other_key), [])[-20:]:
            vz = m.get("vz") or {}
            if m["from"] == me_key and vz.get("k") == "share" and vz.get("vid") == vid and now - m["ts"] < 60:
                h._send_json(200, {"ok": False, "error": "You just sent %s that one" % u["name"]})
                return
        msg = _append(db, me_key, other_key, "\U0001F3B5 Sent a song: " + _song_line(track, artist),
                      {"k": "share", "track": track, "artist": artist, "art": art, "vid": vid})
        _save()
    h._send_json(200, {"ok": True, "to": u["name"], "message": _pub(msg, me_key)})


def _pending_vizahs(srv, db, me_key):
    """Sent Vizahs addressed to me that haven't auto-played yet (and are still fresh)."""
    out, now, allu = [], time.time(), _users(srv)
    for k, msgs in db["threads"].items():
        if me_key not in k.split("|", 1):
            continue
        for m in msgs[-30:]:
            vz = m.get("vz") or {}
            if vz.get("k") == "sent" and m["from"] != me_key and not vz.get("claimed") and now - m["ts"] <= VIZAH_FRESH:
                out.append({"id": m["id"], "from": (allu.get(m["from"]) or {}).get("name", m["from"]),
                            "track": vz.get("track", ""), "artist": vz.get("artist", ""),
                            "art": vz.get("art", ""), "vid": vz.get("vid", "")})
    return out[-5:]


# ---------------------------------------------------------------- routes
def handle_get(h, parsed, srv):
    """Returns True when the request was handled here."""
    path = parsed.path
    if not path.startswith("/social/"):
        return False
    me = srv.session_lookup(h._token())
    if not me:
        h._send_json(401, {"ok": False, "error": "log in to Vizah first", "code": "login", "auth": False})
        return True
    me_key = me.lower()
    qs = parse_qs(parsed.query or "")

    if path == "/social/artist-image":
        h._send_json(200, {"ok": True, "url": _artist_image((qs.get("name", [""])[0] or ""))})
        return True

    if path == "/social/users":
        q = (qs.get("q", [""])[0] or "").strip().lower()
        out = []
        allu = _users(srv)
        for key in _friend_keys(srv, me_key):
            u = allu.get(key)
            if not u or (q and q not in key):
                continue
            p = _profile(srv, u)
            out.append({"name": p["name"], "hasAvatar": p["hasAvatar"], "avatarCrop": p["avatarCrop"],
                        "online": _online(srv, key)})
        out.sort(key=lambda x: x["name"].lower())
        h._send_json(200, {"ok": True, "me": me, "users": out[:200]})
        return True

    if path == "/social/profile":
        u = _find_friend(srv, me_key, qs.get("u", [""])[0], allow_self=True)
        if not u:
            h._send_json(404, {"ok": False, "error": "You can only view profiles of your friends"})
            return True
        p = _profile(srv, u)
        p["online"] = _online(srv, u["name"].lower())
        p["isMe"] = u["name"].lower() == me_key
        if p["isMe"]:
            p["showListening"] = (u.get("config") or {}).get("showListening") is not False   # for the profile preview
        h._send_json(200, {"ok": True, "profile": p})
        return True

    if path.startswith("/social/avatar/"):
        from urllib.parse import unquote
        u = _find_friend(srv, me_key, unquote(path.split("/social/avatar/", 1)[1]), allow_self=True)
        av = ((u or {}).get("config") or {}).get("avatar", "")
        m = _DATA_URL.match(av or "")
        if not m:
            h.send_response(404)
            h.end_headers()
            return True
        raw = base64.b64decode(m.group(2))
        etag = '"%x-%x"' % (len(raw), hash(av) & 0xFFFFFFFF)
        if h.headers.get("If-None-Match") == etag:
            h.send_response(304)
            h.send_header("ETag", etag)
            h.end_headers()
            return True
        h.send_response(200)
        h.send_header("Content-Type", m.group(1))
        h.send_header("Content-Length", str(len(raw)))
        h.send_header("ETag", etag)
        h.end_headers()
        h.wfile.write(raw)
        return True

    if path == "/social/listening":
        one = (qs.get("u", [""])[0] or "").strip()
        allu = _users(srv)
        if one:
            u = _find_friend(srv, me_key, one, allow_self=True)
            if not u:
                h._send_json(404, {"ok": False, "error": "You can only view your friends"})
                return True
            targets = [u]
        else:
            targets = [allu[k] for k in _friend_keys(srv, me_key) if k in allu][:200]
        results = {}

        def work(u):
            try:
                results[u["name"].lower()] = _listening_for(u, u["name"].lower() == me_key)
            except Exception:
                results[u["name"].lower()] = {"state": "unknown"}

        threads = [threading.Thread(target=work, args=(u,), daemon=True) for u in targets]
        for t in threads:
            t.start()
        for t in threads:
            t.join(6)
        online = {u["name"].lower(): (u["name"].lower() == me_key or _online(srv, u["name"].lower())) for u in targets}
        h._send_json(200, {"ok": True, "status": dict(results), "online": online})
        return True

    if path == "/social/inbox":
        friends = _friend_keys(srv, me_key)
        with _lock:
            db = _load()
            convos = []
            for k, msgs in db["threads"].items():
                a, b = k.split("|", 1)
                if me_key not in (a, b) or not msgs:
                    continue
                other_key = b if a == me_key else a
                u = _users(srv).get(other_key)
                if not u or other_key not in friends:
                    continue
                last = msgs[-1]
                lv = last.get("vz") or {}
                convos.append({
                    "name": u["name"],
                    "hasAvatar": bool((u.get("config") or {}).get("avatar")),
                    "avatarCrop": (u.get("config") or {}).get("avatarCrop", "") or "",
                    "last": {"id": last["id"], "text": last["text"][:140], "ts": last["ts"], "mine": last["from"] == me_key,
                             "kind": lv.get("k", "") if isinstance(lv, dict) else "",
                             "track": (lv.get("track", "") if isinstance(lv, dict) else "")[:120],
                             "artist": (lv.get("artist", "") if isinstance(lv, dict) else "")[:120],
                             "art": (lv.get("art", "") if isinstance(lv, dict) else "") or "",
                             "state": lv.get("state", "") if isinstance(lv, dict) else "",
                             "vid": lv.get("vid", "") if isinstance(lv, dict) else ""},
                    "unread": _unread(db, me_key, other_key),
                })
            convos.sort(key=lambda c: c["last"]["ts"], reverse=True)
            total = sum(c["unread"] for c in convos)
            vizahs = _pending_vizahs(srv, db, me_key)
        # friend-request lists so the page can pop a notification the moment one arrives / is accepted
        try:
            ov = srv._friends_overview_base(me)
        except Exception:
            ov = {}
        h._send_json(200, {"ok": True, "conversations": convos, "unread": total, "vizahs": vizahs,
                           "requests": [e["name"] for e in ov.get("incoming", [])],
                           "outgoing": [e["name"] for e in ov.get("outgoing", [])],
                           "friends": [e["name"] for e in ov.get("friends", [])]})
        return True

    if path == "/social/messages":
        u = _find_friend(srv, me_key, qs.get("with", [""])[0])
        if not u:
            h._send_json(404, {"ok": False, "error": "You can only message your friends"})
            return True
        try:
            after = int(qs.get("after", ["0"])[0])
        except ValueError:
            after = 0
        other_key = u["name"].lower()
        with _lock:
            msgs = _load()["threads"].get(_tkey(me_key, other_key), [])
            new = [m for m in msgs if m["id"] > after][-200:]
        h._send_json(200, {"ok": True, "messages": [_pub(m, me_key) for m in new]})
        return True

    h._send_json(404, {"ok": False, "error": "not found"})
    return True


def handle_post(h, parsed, srv):
    path = parsed.path
    if path not in ("/social/send", "/social/read", "/social/ping", "/social/bye",
                    "/social/vizah", "/social/vizah/answer", "/social/vizah/claim", "/social/vizah/share", "/social/art"):
        return False
    if not h._same_origin():
        h._send_json(403, {"ok": False, "error": "cross-site request refused"})
        return True
    me = srv.session_lookup(h._token())
    if not me:
        h._send_json(401, {"ok": False, "error": "log in to Vizah first", "code": "login", "auth": False})
        return True
    me_key = me.lower()
    data = h._read_json(limit=20000)
    if data is None:
        h._send_json(400, {"ok": False, "error": "bad request"})
        return True

    if path in ("/social/ping", "/social/bye"):
        tab = str(data.get("tab", ""))[:40]
        if re.match(r"^[A-Za-z0-9_-]{4,40}$", tab):
            (_ping if path == "/social/ping" else _bye)(me_key, tab)
        h._send_json(200, {"ok": True})
        return True

    if path == "/social/art":
        _art_report(h, srv, me_key, me, data)
        return True

    if path in ("/social/vizah", "/social/vizah/answer", "/social/vizah/claim", "/social/vizah/share"):
        {"/social/vizah": _vizah_ask, "/social/vizah/answer": _vizah_answer,
         "/social/vizah/claim": _vizah_claim, "/social/vizah/share": _vizah_share}[path](h, srv, me_key, me, data)
        return True

    if path == "/social/send":
        u = _find_friend(srv, me_key, str(data.get("to", "")))
        text = data.get("text", "")
        if not u:
            h._send_json(403, {"ok": False, "error": "You can only message your friends"})
            return True
        if not isinstance(text, str) or not text.strip():
            h._send_json(400, {"ok": False, "error": "Write something first"})
            return True
        text = text.strip()[:MSG_MAX]
        other_key = u["name"].lower()
        if other_key == me_key:
            h._send_json(400, {"ok": False, "error": "You can't message yourself"})
            return True
        now = time.time()
        recent = [t for t in _sent.get(me_key, []) if now - t < 60]
        if len(recent) >= SEND_LIMIT:
            h._send_json(429, {"ok": False, "error": "Slow down a little"})
            return True
        recent.append(now)
        _sent[me_key] = recent
        with _lock:
            db = _load()
            db["seq"] += 1
            msg = {"id": db["seq"], "from": me_key, "text": text, "ts": int(now)}
            thread = db["threads"].setdefault(_tkey(me_key, other_key), [])
            thread.append(msg)
            if len(thread) > KEEP_PER_THREAD:
                del thread[:len(thread) - KEEP_PER_THREAD]
            db["read"]["%s|%s" % (me_key, other_key)] = msg["id"]  # my own message counts as read
            _save()
        h._send_json(200, {"ok": True, "message": {"id": msg["id"], "text": text, "ts": msg["ts"], "mine": True}})
        return True

    # /social/read
    u = _find_friend(srv, me_key, str(data.get("with", "")))
    if not u:
        h._send_json(404, {"ok": False, "error": "You can only message your friends"})
        return True
    other_key = u["name"].lower()
    with _lock:
        db = _load()
        msgs = db["threads"].get(_tkey(me_key, other_key), [])
        if msgs:
            db["read"]["%s|%s" % (me_key, other_key)] = msgs[-1]["id"]
            _save()
    h._send_json(200, {"ok": True})
    return True
