/* Vizah service worker.
   The app talks to a local server in Termux, so almost everything is live data.
   This worker only (a) makes the app installable and (b) shows a friendly page when the
   server isn't running. It never caches API, login or account responses. */
const VERSION = "vizah-pwa-v1";
const SHELL = ["/pwa/offline.html", "/pwa/icon-192.png", "/pwa/icon-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;

  // Page loads: always try the live server, fall back to the "start the server" page.
  if (req.mode === "navigate") {
    e.respondWith(
      fetch(req).catch(() => caches.match("/pwa/offline.html"))
    );
    return;
  }

  // Static PWA assets only: cache-first. Everything else goes straight to the network.
  if (url.pathname.startsWith("/pwa/")) {
    e.respondWith(caches.match(req).then((hit) => hit || fetch(req)));
  }
});
